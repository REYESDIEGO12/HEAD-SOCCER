package presentacion;

import dominio.*;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;

public class DOPOSoccerGUI extends JFrame implements ActionListener, KeyListener {

    private static final double PASO = 1.0 / 60;
    private static final Color AZUL = new Color(52, 130, 255);
    private static final Color ROJO = new Color(231, 76, 60);
    private static final Color AMARILLO = new Color(255, 196, 0);
    private static final Color FONDO = new Color(15, 30, 70);

    private Juego juego;
    private ArchivoProgreso progreso;
    private ArrayList<Personaje> personajes;
    private BufferedImage[] imagenes;
    private Color[] camisetas = {Color.WHITE, new Color(0, 140, 70), new Color(0, 150, 90), new Color(25, 60, 130)};

    private JPanel panelMenu;
    private JButton botonJugar;
    private JButton botonAbrir;
    private JButton botonSalir;

    private JPanel panelConfiguracion;
    private JRadioButton botonDosJugadores;
    private JRadioButton botonContraMaquina;
    private JTextField campoNombre1;
    private JTextField campoNombre2;
    private JComboBox<String> comboPersonaje1;
    private JComboBox<String> comboPersonaje2;
    private JComboBox<String> comboPerfil;
    private JComboBox<String> comboResolucion;
    private JComboBox<String> comboTipo;
    private JSpinner spinnerObjetivo;
    private JLabel etiquetaObjetivo;
    private JLabel etiquetaPerfil;
    private JLabel imagen1;
    private JLabel imagen2;
    private JLabel poder1;
    private JLabel poder2;
    private JButton botonEmpezar;
    private JButton botonVolver;

    private PanelJuego panelJuego;
    private JPanel panelPartido;
    private JButton botonPausa;
    private JButton botonGuardar;
    private JButton botonTerminar;
    private Timer reloj;
    private Partido partido;
    private Accion accion1;
    private Accion accion2;
    private boolean pausa;
    private boolean terminado;
    private boolean teclaPausa;
    private int cuenta;
    private int tick;
    private double acumulado;
    private long ultimo;

    public DOPOSoccerGUI() {
        super("DOPOSoccer 2026-2");
        juego = new Juego();
        progreso = new ArchivoProgreso();
        personajes = Personaje.catalogo();
        cargarImagenes();
        prepareElements();
        prepareActions();
    }

    private void prepareElements() {
        panelMenu = crearMenu();
        panelConfiguracion = crearConfiguracion();
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        mostrar(panelMenu);
    }

    private void prepareActions() {
        botonJugar.addActionListener(this);
        botonAbrir.addActionListener(this);
        botonSalir.addActionListener(this);
        botonEmpezar.addActionListener(this);
        botonVolver.addActionListener(this);
        botonDosJugadores.addActionListener(this);
        botonContraMaquina.addActionListener(this);
        comboTipo.addActionListener(this);
        comboPersonaje1.addActionListener(this);
        comboPersonaje2.addActionListener(this);
    }

    private void cargarImagenes() {
        String[] archivos = {"Corea_del_Sur", "Camerun", "Nigeria", "Estados_Unidos"};
        imagenes = new BufferedImage[personajes.size()];
        for (int i = 0; i < personajes.size(); i++) {
            imagenes[i] = cargarImagen(archivos[i]);
        }
    }

    private BufferedImage cargarImagen(String nombre) {
        String[] carpetas = {"resources/jugadores/", "DOPOSoccer/resources/jugadores/", "../resources/jugadores/",
                "../../resources/jugadores/", "../DOPOSoccer/resources/jugadores/", "../../DOPOSoccer/resources/jugadores/"};
        for (int i = 0; i < carpetas.length; i++) {
            File archivo = new File(carpetas[i] + nombre + ".png");
            if (archivo.exists()) {
                try {
                    return ImageIO.read(archivo);
                } catch (IOException e) {
                    RegistroErrores.registrar("No se pudo leer la imagen " + archivo.getPath(), e);
                }
            }
        }
        java.net.URL url = DOPOSoccerGUI.class.getResource("/resources/jugadores/" + nombre + ".png");
        if (url != null) {
            try {
                return ImageIO.read(url);
            } catch (IOException e) {
                RegistroErrores.registrar("No se pudo leer la imagen " + nombre, e);
            }
        }
        RegistroErrores.registrar("No se encontro la imagen " + nombre + ". Carpeta de trabajo: " + new File(".").getAbsolutePath(), new IOException("Imagen no encontrada"));
        return null;
    }

    private ImageIcon crearIcono(int indice, int tamano) {
        if (imagenes[indice] == null) {
            return null;
        }
        return new ImageIcon(imagenes[indice].getScaledInstance(tamano, tamano, Image.SCALE_SMOOTH));
    }

    private int indicePersonaje(Jugador jugador) {
        for (int i = 0; i < personajes.size(); i++) {
            if (personajes.get(i).getPais().equals(jugador.getPais())) {
                return i;
            }
        }
        return 0;
    }

    private void mostrar(JPanel panel) {
        setContentPane(panel);
        pack();
        setLocationRelativeTo(null);
        setVisible(true);
        revalidate();
        repaint();
    }

    private JButton crearBoton(String texto) {
        JButton boton = new JButton(texto);
        boton.setPreferredSize(new Dimension(260, 44));
        boton.setFont(new Font("Arial", Font.BOLD, 16));
        return boton;
    }

    private JLabel crearEtiqueta(String texto) {
        JLabel etiqueta = new JLabel(texto);
        etiqueta.setForeground(Color.WHITE);
        etiqueta.setFont(new Font("Arial", Font.BOLD, 14));
        return etiqueta;
    }

    private JPanel crearMenu() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(FONDO);
        panel.setBorder(BorderFactory.createEmptyBorder(30, 40, 30, 40));

        JLabel titulo = new JLabel("DOPOSOCCER", SwingConstants.CENTER);
        titulo.setFont(new Font("Arial", Font.BOLD, 60));
        titulo.setForeground(AMARILLO);
        panel.add(titulo, BorderLayout.NORTH);

        JPanel caras = new JPanel(new GridLayout(1, personajes.size()));
        caras.setOpaque(false);
        for (int i = 0; i < personajes.size(); i++) {
            JLabel cara = new JLabel(personajes.get(i).getPais(), crearIcono(i, 90), SwingConstants.CENTER);
            cara.setVerticalTextPosition(SwingConstants.BOTTOM);
            cara.setHorizontalTextPosition(SwingConstants.CENTER);
            cara.setForeground(Color.WHITE);
            cara.setFont(new Font("Arial", Font.BOLD, 14));
            caras.add(cara);
        }
        panel.add(caras, BorderLayout.CENTER);

        botonJugar = crearBoton("JUGAR");
        botonAbrir = crearBoton("ABRIR PARTIDA");
        botonSalir = crearBoton("SALIR");
        JPanel botones = new JPanel(new GridLayout(0, 1, 10, 10));
        botones.setOpaque(false);
        botones.add(botonJugar);
        botones.add(botonAbrir);
        botones.add(botonSalir);
        JPanel abajo = new JPanel();
        abajo.setOpaque(false);
        abajo.add(botones);
        panel.add(abajo, BorderLayout.SOUTH);
        return panel;
    }

    private JPanel crearConfiguracion() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBackground(FONDO);
        panel.setBorder(BorderFactory.createEmptyBorder(20, 30, 20, 30));

        JLabel titulo = new JLabel("CONFIGURACIÓN DEL PARTIDO", SwingConstants.CENTER);
        titulo.setFont(new Font("Arial", Font.BOLD, 28));
        titulo.setForeground(AMARILLO);

        botonDosJugadores = new JRadioButton("Jugador vs jugador", true);
        botonContraMaquina = new JRadioButton("Jugador vs máquina");
        botonDosJugadores.setOpaque(false);
        botonContraMaquina.setOpaque(false);
        botonDosJugadores.setForeground(Color.WHITE);
        botonContraMaquina.setForeground(Color.WHITE);
        ButtonGroup grupo = new ButtonGroup();
        grupo.add(botonDosJugadores);
        grupo.add(botonContraMaquina);
        JPanel modalidad = new JPanel();
        modalidad.setOpaque(false);
        modalidad.add(botonDosJugadores);
        modalidad.add(botonContraMaquina);

        JPanel arriba = new JPanel(new GridLayout(0, 1));
        arriba.setOpaque(false);
        arriba.add(titulo);
        arriba.add(modalidad);
        panel.add(arriba, BorderLayout.NORTH);

        campoNombre1 = new JTextField("Jugador 1");
        campoNombre2 = new JTextField("Jugador 2");
        comboPersonaje1 = new JComboBox<String>();
        comboPersonaje2 = new JComboBox<String>();
        for (int i = 0; i < personajes.size(); i++) {
            comboPersonaje1.addItem(personajes.get(i).getPais());
            comboPersonaje2.addItem(personajes.get(i).getPais());
        }
        comboPersonaje2.setSelectedIndex(1);
        imagen1 = new JLabel();
        imagen2 = new JLabel();
        poder1 = new JLabel();
        poder2 = new JLabel();
        poder1.setForeground(Color.WHITE);
        poder2.setForeground(Color.WHITE);
        comboPerfil = new JComboBox<String>(Maquina.perfiles());
        etiquetaPerfil = crearEtiqueta("Perfil de la máquina");
        etiquetaPerfil.setVisible(false);
        comboPerfil.setVisible(false);

        JPanel jugadores = new JPanel(new GridLayout(1, 2, 30, 0));
        jugadores.setOpaque(false);
        JPanel panelJugador1 = crearPanelJugador("Nombre del jugador 1", campoNombre1, comboPersonaje1, imagen1, poder1);
        JPanel panelJugador2 = crearPanelJugador("Nombre del jugador 2", campoNombre2, comboPersonaje2, imagen2, poder2);
        panelJugador2.add(etiquetaPerfil);
        panelJugador2.add(comboPerfil);
        jugadores.add(panelJugador1);
        jugadores.add(panelJugador2);
        panel.add(jugadores, BorderLayout.CENTER);

        comboResolucion = new JComboBox<String>(new String[]{"800x450", "1000x560", "1200x675"});
        comboTipo = new JComboBox<String>(new String[]{"Por goles", "Por tiempo"});
        spinnerObjetivo = new JSpinner(new SpinnerNumberModel(3, 1, 30, 1));
        etiquetaObjetivo = crearEtiqueta("Goles para ganar");
        JPanel opciones = new JPanel(new GridLayout(2, 3, 10, 4));
        opciones.setOpaque(false);
        opciones.add(crearEtiqueta("Resolución de la cancha"));
        opciones.add(crearEtiqueta("Tipo de partido"));
        opciones.add(etiquetaObjetivo);
        opciones.add(comboResolucion);
        opciones.add(comboTipo);
        opciones.add(spinnerObjetivo);

        botonVolver = crearBoton("VOLVER");
        botonEmpezar = crearBoton("EMPEZAR");
        JPanel botones = new JPanel();
        botones.setOpaque(false);
        botones.add(botonVolver);
        botones.add(botonEmpezar);

        JPanel abajo = new JPanel(new BorderLayout(0, 10));
        abajo.setOpaque(false);
        abajo.add(opciones, BorderLayout.CENTER);
        abajo.add(botones, BorderLayout.SOUTH);
        panel.add(abajo, BorderLayout.SOUTH);

        actualizarPersonajes();
        return panel;
    }

    private JPanel crearPanelJugador(String titulo, JTextField nombre, JComboBox<String> personaje, JLabel imagen, JLabel poder) {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setOpaque(false);
        JLabel etiqueta = crearEtiqueta(titulo);
        JLabel etiquetaPersonaje = crearEtiqueta("Personaje");
        etiqueta.setAlignmentX(Component.LEFT_ALIGNMENT);
        etiquetaPersonaje.setAlignmentX(Component.LEFT_ALIGNMENT);
        nombre.setAlignmentX(Component.LEFT_ALIGNMENT);
        personaje.setAlignmentX(Component.LEFT_ALIGNMENT);
        imagen.setAlignmentX(Component.LEFT_ALIGNMENT);
        poder.setAlignmentX(Component.LEFT_ALIGNMENT);
        panel.add(etiqueta);
        panel.add(nombre);
        panel.add(Box.createVerticalStrut(10));
        panel.add(etiquetaPersonaje);
        panel.add(personaje);
        panel.add(Box.createVerticalStrut(10));
        panel.add(imagen);
        panel.add(poder);
        panel.add(Box.createVerticalStrut(10));
        return panel;
    }

    private void actualizarPersonajes() {
        int indice1 = comboPersonaje1.getSelectedIndex();
        int indice2 = comboPersonaje2.getSelectedIndex();
        PoderEspecial poderUno = personajes.get(indice1).getPoder();
        PoderEspecial poderDos = personajes.get(indice2).getPoder();
        imagen1.setIcon(crearIcono(indice1, 80));
        imagen2.setIcon(crearIcono(indice2, 80));
        poder1.setText("<html><body style='width:250px'><b>" + poderUno.getNombre() + ":</b> " + poderUno.getDescripcion() + "</body></html>");
        poder2.setText("<html><body style='width:250px'><b>" + poderDos.getNombre() + ":</b> " + poderDos.getDescripcion() + "</body></html>");
    }

    private void actualizarModalidad() {
        boolean maquina = botonContraMaquina.isSelected();
        etiquetaPerfil.setVisible(maquina);
        comboPerfil.setVisible(maquina);
        campoNombre2.setEnabled(!maquina);
        if (maquina) {
            campoNombre2.setText("Máquina");
        } else {
            campoNombre2.setText("Jugador 2");
        }
    }

    private void actualizarTipo() {
        if (comboTipo.getSelectedIndex() == 0) {
            etiquetaObjetivo.setText("Goles para ganar");
            spinnerObjetivo.setValue(3);
        } else {
            etiquetaObjetivo.setText("Minutos del partido");
            spinnerObjetivo.setValue(2);
        }
    }

    public void actionPerformed(ActionEvent e) {
        Object origen = e.getSource();
        if (origen == reloj) {
            actualizarJuego();
        } else if (origen == botonJugar) {
            mostrar(panelConfiguracion);
        } else if (origen == botonAbrir) {
            abrirPartida();
        } else if (origen == botonSalir) {
            salir();
        } else if (origen == botonVolver) {
            mostrar(panelMenu);
        } else if (origen == botonEmpezar) {
            empezarPartido();
        } else if (origen == botonDosJugadores || origen == botonContraMaquina) {
            actualizarModalidad();
        } else if (origen == comboTipo) {
            actualizarTipo();
        } else if (origen == comboPersonaje1 || origen == comboPersonaje2) {
            actualizarPersonajes();
        } else if (origen == botonPausa) {
            alternarPausa();
        } else if (origen == botonGuardar) {
            guardarPartida();
        } else if (origen == botonTerminar) {
            terminarPartido();
        }
    }

    private void empezarPartido() {
        try {
            String nombre1 = campoNombre1.getText().trim();
            String nombre2 = campoNombre2.getText().trim();
            if (nombre1.isEmpty() || nombre2.isEmpty()) {
                throw new JuegoException("Los dos jugadores necesitan un nombre.");
            }
            if (nombre1.equalsIgnoreCase(nombre2)) {
                throw new JuegoException("Los dos jugadores no pueden tener el mismo nombre.");
            }
            Jugador jugador1 = new Jugador(nombre1, Personaje.buscar((String) comboPersonaje1.getSelectedItem()));
            Jugador jugador2 = new Jugador(nombre2, Personaje.buscar((String) comboPersonaje2.getSelectedItem()));
            if (botonContraMaquina.isSelected()) {
                jugador2.setMaquina(Maquina.crear((String) comboPerfil.getSelectedItem()));
            } else {
                progreso.cargarEn(jugador2);
            }
            progreso.cargarEn(jugador1);
            String[] medidas = ((String) comboResolucion.getSelectedItem()).split("x");
            int ancho = Integer.parseInt(medidas[0]);
            int alto = Integer.parseInt(medidas[1]);
            boolean porGoles = comboTipo.getSelectedIndex() == 0;
            int objetivo = (Integer) spinnerObjetivo.getValue();
            juego.crearPartido(jugador1, jugador2, ancho, alto, porGoles, objetivo);
            mostrarPartido(juego.getPartido(), true);
        } catch (JuegoException e) {
            mostrarError(e);
        }
    }

    private void abrirPartida() {
        JFileChooser selector = new JFileChooser(new File("."));
        selector.setFileFilter(new FileNameExtensionFilter("Partida de DOPOSoccer (*.dopo)", "dopo"));
        if (selector.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
            try {
                Partido abierto = ArchivoPartida.abrir(selector.getSelectedFile());
                juego.setPartido(abierto);
                mostrarPartido(abierto, false);
            } catch (JuegoException e) {
                mostrarError(e);
            }
        }
    }

    private void guardarPartida() {
        boolean estabaEnPausa = pausa;
        pausa = true;
        JFileChooser selector = new JFileChooser(new File("."));
        selector.setFileFilter(new FileNameExtensionFilter("Partida de DOPOSoccer (*.dopo)", "dopo"));
        if (selector.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
            File archivo = selector.getSelectedFile();
            if (!archivo.getName().endsWith(ArchivoPartida.EXTENSION)) {
                archivo = new File(archivo.getPath() + ArchivoPartida.EXTENSION);
            }
            try {
                ArchivoPartida.guardar(partido, archivo);
                JOptionPane.showMessageDialog(this, "Partida guardada en:\n" + archivo.getPath());
            } catch (JuegoException e) {
                mostrarError(e);
            }
        }
        pausa = estabaEnPausa;
        ultimo = System.nanoTime();
        panelJuego.requestFocusInWindow();
    }

    private void terminarPartido() {
        boolean estabaEnPausa = pausa;
        pausa = true;
        int respuesta = JOptionPane.showConfirmDialog(this,
                "¿Seguro que quieres terminar el partido?\nGana quien vaya anotando más goles.",
                "Terminar partido", JOptionPane.YES_NO_OPTION);
        if (respuesta == JOptionPane.YES_OPTION) {
            partido.terminarPartido();
            terminado = true;
            reloj.stop();
            finDePartido();
        } else {
            pausa = estabaEnPausa;
            ultimo = System.nanoTime();
            panelJuego.requestFocusInWindow();
        }
    }

    private void salir() {
        int respuesta = JOptionPane.showConfirmDialog(this, "¿Seguro que quieres salir de DOPOSoccer?", "Salir", JOptionPane.YES_NO_OPTION);
        if (respuesta == JOptionPane.YES_OPTION) {
            System.exit(0);
        }
    }

    private void mostrarError(JuegoException e) {
        RegistroErrores.registrar("Error mostrado al usuario", e);
        JOptionPane.showMessageDialog(this, e.getMessage(), "Algo salió mal", JOptionPane.ERROR_MESSAGE);
    }

    private void mostrarPartido(Partido nuevo, boolean conCuenta) {
        if (reloj != null) {
            reloj.stop();
        }
        partido = nuevo;
        accion1 = new Accion();
        accion2 = new Accion();
        terminado = false;
        teclaPausa = false;
        acumulado = 0;
        tick = 0;
        pausa = !conCuenta;
        if (conCuenta) {
            cuenta = 180;
        } else {
            cuenta = 0;
        }

        panelJuego = new PanelJuego();
        botonPausa = new JButton("Pausa (P)");
        botonGuardar = new JButton("Guardar partida");
        botonTerminar = new JButton("Terminar partido");
        botonPausa.setFocusable(false);
        botonGuardar.setFocusable(false);
        botonTerminar.setFocusable(false);
        botonPausa.addActionListener(this);
        botonGuardar.addActionListener(this);
        botonTerminar.addActionListener(this);
        JLabel controles = new JLabel("J1: A/D mover, W saltar, F patear, G poder     J2: flechas, L patear, K poder");
        controles.setForeground(Color.WHITE);
        JPanel barra = new JPanel();
        barra.setBackground(FONDO);
        barra.add(botonPausa);
        barra.add(botonGuardar);
        barra.add(botonTerminar);
        barra.add(controles);

        panelPartido = new JPanel(new BorderLayout());
        panelPartido.add(panelJuego, BorderLayout.CENTER);
        panelPartido.add(barra, BorderLayout.SOUTH);
        mostrar(panelPartido);

        ultimo = System.nanoTime();
        reloj = new Timer(10, this);
        reloj.start();
        panelJuego.requestFocusInWindow();
    }

    private void alternarPausa() {
        if (cuenta > 0 || terminado) {
            return;
        }
        pausa = !pausa;
        ultimo = System.nanoTime();
        panelJuego.requestFocusInWindow();
    }

    private void actualizarJuego() {
        long ahora = System.nanoTime();
        double pasado = (ahora - ultimo) / 1000000000.0;
        ultimo = ahora;
        if (pasado > 0.1) {
            pasado = 0.1;
        }
        if (!pausa) {
            acumulado = acumulado + pasado;
            while (acumulado >= PASO && !terminado) {
                avanzarUnTick();
                acumulado = acumulado - PASO;
            }
        }
        panelJuego.repaint();
    }

    private void avanzarUnTick() {
        tick++;
        if (cuenta > 0) {
            cuenta--;
            return;
        }
        partido.avanzar(accion1, accion2);
        if (partido.mostrarResultado()) {
            terminado = true;
            reloj.stop();
            finDePartido();
        }
    }

    private void finDePartido() {
        partido.otorgarPuntos();
        Jugador jugador1 = partido.getJugador1();
        Jugador jugador2 = partido.getJugador2();
        try {
            progreso.guardarDe(jugador1);
            if (!jugador2.esMaquina()) {
                progreso.guardarDe(jugador2);
            }
        } catch (JuegoException e) {
            mostrarError(e);
        }
        String titulo = "Empate";
        if (partido.getGanador() != null) {
            titulo = "Ganó " + partido.nombreGanador();
        }
        String mensaje = titulo + "\n\n"
                + jugador1.getNombre() + " " + jugador1.getGoles() + " - " + jugador2.getGoles() + " " + jugador2.getNombre() + "\n\n"
                + "Puntos obtenidos:\n"
                + jugador1.getNombre() + ": +" + partido.getPuntosGanados1() + " (total " + jugador1.getPuntos() + ")\n"
                + jugador2.getNombre() + ": +" + partido.getPuntosGanados2() + " (total " + jugador2.getPuntos() + ")";
        JOptionPane.showMessageDialog(this, mensaje, "Fin del partido", JOptionPane.INFORMATION_MESSAGE);
        mostrar(panelMenu);
    }

    public void keyPressed(KeyEvent e) {
        cambiarTecla(e.getKeyCode(), true);
    }

    public void keyReleased(KeyEvent e) {
        cambiarTecla(e.getKeyCode(), false);
    }

    public void keyTyped(KeyEvent e) {
    }

    private void cambiarTecla(int codigo, boolean abajo) {
        switch (codigo) {
            case KeyEvent.VK_A:
                accion1.setIzquierda(abajo);
                break;
            case KeyEvent.VK_D:
                accion1.setDerecha(abajo);
                break;
            case KeyEvent.VK_W:
                accion1.setSaltar(abajo);
                break;
            case KeyEvent.VK_F:
                accion1.setPatear(abajo);
                break;
            case KeyEvent.VK_G:
                accion1.setPoder(abajo);
                break;
            case KeyEvent.VK_LEFT:
                accion2.setIzquierda(abajo);
                break;
            case KeyEvent.VK_RIGHT:
                accion2.setDerecha(abajo);
                break;
            case KeyEvent.VK_UP:
                accion2.setSaltar(abajo);
                break;
            case KeyEvent.VK_L:
                accion2.setPatear(abajo);
                break;
            case KeyEvent.VK_K:
                accion2.setPoder(abajo);
                break;
            case KeyEvent.VK_P:
            case KeyEvent.VK_ESCAPE:
                if (abajo && !teclaPausa) {
                    alternarPausa();
                }
                teclaPausa = abajo;
                break;
        }
    }

    private class PanelJuego extends JPanel {

        public PanelJuego() {
            Cancha cancha = partido.getCancha();
            setPreferredSize(new Dimension(cancha.getAnchoPantalla(), cancha.getAltoPantalla()));
            setFocusable(true);
            addKeyListener(DOPOSoccerGUI.this);
        }

        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2 = (Graphics2D) g;
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.scale(getWidth() / 800.0, getHeight() / 450.0);

            dibujarFondo(g2);
            dibujarArco(g2, 0);
            dibujarArco(g2, Cancha.ANCHO - Cancha.ARCO_ANCHO);
            dibujarJugador(g2, partido.getJugador1(), AZUL);
            dibujarJugador(g2, partido.getJugador2(), ROJO);
            ArrayList<Balon> balones = partido.getTodosLosBalones();
            for (int i = 0; i < balones.size(); i++) {
                dibujarBalon(g2, balones.get(i));
            }
            dibujarPanelJugador(g2, partido.getJugador1(), 10, AZUL);
            dibujarPanelJugador(g2, partido.getJugador2(), 490, ROJO);
            dibujarMarcador(g2);
            dibujarMensajes(g2);
        }
    }

    private void dibujarTextoCentrado(Graphics2D g2, String texto, int centroX, int y) {
        FontMetrics medidas = g2.getFontMetrics();
        g2.drawString(texto, centroX - medidas.stringWidth(texto) / 2, y);
    }

    private void dibujarFondo(Graphics2D g2) {
        g2.setColor(new Color(10, 20, 50));
        g2.fillRect(0, 0, 800, 450);
        g2.setColor(new Color(35, 40, 70));
        g2.fillRect(0, 110, 800, 212);
        g2.setColor(new Color(255, 250, 200));
        for (int i = 0; i < 4; i++) {
            g2.fillOval(80 + i * 207, 25, 30, 16);
        }

        String[] anuncios = {"DOPO", "ECI", "SOCCER", "JAVA", "POO", "DOPO", "GOL", "ECI"};
        Color[] coloresVallas = {new Color(30, 90, 200), new Color(200, 40, 50), new Color(30, 150, 90), new Color(235, 170, 20)};
        g2.setFont(new Font("Arial", Font.BOLD, 17));
        for (int i = 0; i < anuncios.length; i++) {
            g2.setColor(coloresVallas[i % 4]);
            g2.fillRect(i * 100, 322, 100, 30);
            g2.setColor(Color.WHITE);
            dibujarTextoCentrado(g2, anuncios[i], i * 100 + 50, 344);
        }

        for (int i = 0; i < 10; i++) {
            if (i % 2 == 0) {
                g2.setColor(new Color(38, 148, 62));
            } else {
                g2.setColor(new Color(48, 170, 74));
            }
            g2.fillRect(i * 80, 352, 80, 98);
        }
        g2.setColor(Color.WHITE);
        g2.setStroke(new BasicStroke(2));
        g2.drawLine(400, 354, 400, 450);
        g2.drawOval(320, 372, 160, 50);
        g2.drawRect(-2, 366, 125, 62);
        g2.drawRect(677, 366, 125, 62);
        g2.drawLine(0, 354, 800, 354);
    }

    private void dibujarArco(Graphics2D g2, int x) {
        g2.setColor(new Color(0, 0, 0, 90));
        g2.fillRect(x, Cancha.TRAVESANO_Y, Cancha.ARCO_ANCHO, Cancha.ARCO_ALTO);
        g2.setColor(new Color(255, 255, 255, 120));
        g2.setStroke(new BasicStroke(1));
        for (int i = 0; i <= Cancha.ARCO_ANCHO; i += 9) {
            g2.drawLine(x + i, Cancha.TRAVESANO_Y, x + i, Cancha.SUELO);
        }
        for (int i = Cancha.TRAVESANO_Y; i <= Cancha.SUELO; i += 9) {
            g2.drawLine(x, i, x + Cancha.ARCO_ANCHO, i);
        }
        g2.setColor(Color.WHITE);
        g2.fillRect(x, Cancha.TRAVESANO_Y, Cancha.ARCO_ANCHO, Cancha.TRAVESANO_GROSOR);
        if (x == 0) {
            g2.fillRect(Cancha.ARCO_ANCHO - 4, Cancha.TRAVESANO_Y, 4, Cancha.ARCO_ALTO);
        } else {
            g2.fillRect(x, Cancha.TRAVESANO_Y, 4, Cancha.ARCO_ALTO);
        }
    }

    private Color colorPoder(PoderEspecial poder) {
        String nombre = poder.getNombre();
        if (nombre.equals("Aura Azul")) {
            return new Color(60, 140, 255);
        }
        if (nombre.equals("Rayo")) {
            return new Color(255, 225, 40);
        }
        if (nombre.equals("Tornado")) {
            return new Color(200, 215, 230);
        }
        return new Color(190, 90, 255);
    }

    private void dibujarJugador(Graphics2D g2, Jugador jugador, Color colorEtiqueta) {
        int x = (int) jugador.getX();
        int y = (int) jugador.getY();
        int direccion = jugador.getDireccion();
        int indice = indicePersonaje(jugador);

        if (jugador.isPoderActivo()) {
            Color color = colorPoder(jugador.getPersonaje().getPoder());
            g2.setColor(new Color(color.getRed(), color.getGreen(), color.getBlue(), 110));
            g2.fillOval(x - 48, y - 100, 96, 108);
        }

        g2.setColor(new Color(0, 0, 0, 70));
        g2.fillOval(x - 25, Cancha.SUELO - 4, 50, 10);

        g2.setColor(camisetas[indice]);
        g2.fillRect(x - 14, y - 26, 28, 16);
        g2.setColor(Color.WHITE);
        g2.fillRect(x - 14, y - 10, 28, 8);
        g2.setColor(colorEtiqueta);
        g2.fillOval(x - direccion * 10 - 14, y - 8, 28, 12);
        g2.fillOval((int) jugador.getPieX() - 14, (int) jugador.getPieY() - 2, 28, 12);

        if (imagenes[indice] != null) {
            g2.drawImage(imagenes[indice], x - 28, y - 80, 56, 56, null);
        } else {
            g2.setColor(camisetas[indice]);
            g2.fillOval(x - 28, y - 80, 56, 56);
            g2.setColor(Color.BLACK);
            g2.drawOval(x - 28, y - 80, 56, 56);
        }

        g2.setFont(new Font("Arial", Font.BOLD, 11));
        g2.setColor(colorEtiqueta);
        g2.fillRect(x - 35, y - 104, 70, 16);
        g2.setColor(Color.WHITE);
        dibujarTextoCentrado(g2, jugador.getNombre(), x, y - 92);

        String estado = "";
        if (jugador.estaAturdido()) {
            estado = "ATURDIDO";
        } else if (jugador.getEfecto() != Efecto.NINGUNO) {
            estado = jugador.getEfecto().getNombre().toUpperCase();
        }
        if (!estado.equals("")) {
            g2.setFont(new Font("Arial", Font.BOLD, 13));
            g2.setColor(Color.YELLOW);
            dibujarTextoCentrado(g2, estado, x, y - 110);
        }
    }

    private void dibujarBalon(Graphics2D g2, Balon balon) {
        int x = (int) balon.getX();
        int y = (int) balon.getY();
        int radio = (int) balon.getRadio();

        g2.setColor(new Color(0, 0, 0, 70));
        g2.fillOval(x - radio, Cancha.SUELO - 3, radio * 2, 8);

        PoderEspecial tiro = balon.getTiro();
        if (tiro != null && !tiro.generaSenuelos()) {
            Color color = colorPoder(tiro);
            g2.setColor(new Color(color.getRed(), color.getGreen(), color.getBlue(), 130));
            g2.fillOval(x - radio - 10, y - radio - 10, radio * 2 + 20, radio * 2 + 20);
        }

        g2.setColor(Color.WHITE);
        g2.fillOval(x - radio, y - radio, radio * 2, radio * 2);
        g2.setColor(Color.BLACK);
        g2.setStroke(new BasicStroke(1.5f));
        g2.drawOval(x - radio, y - radio, radio * 2, radio * 2);
        for (int i = 0; i < 3; i++) {
            double angulo = balon.getAngulo() + i * 2 * Math.PI / 3;
            int puntaX = (int) (x + Math.cos(angulo) * radio);
            int puntaY = (int) (y + Math.sin(angulo) * radio);
            g2.drawLine(x, y, puntaX, puntaY);
        }
        g2.fillOval(x - 3, y - 3, 6, 6);
    }

    private void dibujarPanelJugador(Graphics2D g2, Jugador jugador, int x, Color color) {
        g2.setColor(new Color(0, 0, 40, 210));
        g2.fillRect(x, 8, 300, 60);
        g2.setColor(color);
        g2.setStroke(new BasicStroke(2));
        g2.drawRect(x, 8, 300, 60);

        int indice = indicePersonaje(jugador);
        int xCara = x + 6;
        int xBarras = x + 58;
        if (x > 400) {
            xCara = x + 250;
            xBarras = x + 10;
        }
        if (imagenes[indice] != null) {
            g2.drawImage(imagenes[indice], xCara, 16, 44, 44, null);
        }

        g2.setFont(new Font("Arial", Font.BOLD, 12));
        g2.setColor(Color.WHITE);
        g2.drawString(jugador.getNombre() + " - " + jugador.getPais(), xBarras, 24);

        double vida = (double) jugador.getVida() / jugador.getVidaMax();
        g2.setColor(Color.DARK_GRAY);
        g2.fillRect(xBarras, 29, 232, 15);
        if (vida > 0.5) {
            g2.setColor(new Color(46, 204, 113));
        } else if (vida > 0.25) {
            g2.setColor(Color.ORANGE);
        } else {
            g2.setColor(ROJO);
        }
        g2.fillRect(xBarras, 29, (int) (232 * vida), 15);
        g2.setColor(Color.WHITE);
        g2.setFont(new Font("Arial", Font.BOLD, 10));
        dibujarTextoCentrado(g2, jugador.getVida() + " / " + jugador.getVidaMax(), xBarras + 116, 41);

        g2.setColor(Color.DARK_GRAY);
        g2.fillRect(xBarras, 48, 232, 12);
        g2.setColor(AMARILLO);
        g2.fillRect(xBarras, 48, (int) (232 * jugador.getBarraPoder() / 100), 12);
        g2.setColor(Color.BLACK);
        g2.setFont(new Font("Arial", Font.BOLD, 9));
        String textoPoder = "PODER";
        if (jugador.isPoderActivo()) {
            textoPoder = "AURA ACTIVA";
        } else if (jugador.getBarraPoder() >= 100) {
            textoPoder = "PODER LISTO";
        }
        dibujarTextoCentrado(g2, textoPoder, xBarras + 116, 58);
    }

    private void dibujarMarcador(Graphics2D g2) {
        g2.setColor(new Color(0, 0, 40, 210));
        g2.fillRect(320, 8, 160, 60);
        g2.setColor(Color.WHITE);
        g2.drawRect(320, 8, 160, 60);
        g2.setFont(new Font("Arial", Font.BOLD, 30));
        dibujarTextoCentrado(g2, partido.getJugador1().getGoles() + " - " + partido.getJugador2().getGoles(), 400, 42);

        String texto;
        if (partido.isMuerteSubita()) {
            texto = "MUERTE SÚBITA";
        } else if (partido.isPorGoles()) {
            texto = "A " + partido.getGolesParaGanar() + " GOLES";
        } else {
            int segundos = partido.getSegundosRestantes();
            texto = String.format("%02d:%02d", segundos / 60, segundos % 60);
        }
        g2.setColor(AMARILLO);
        g2.setFont(new Font("Arial", Font.BOLD, 14));
        dibujarTextoCentrado(g2, texto, 400, 61);
    }

    private void dibujarMensajes(Graphics2D g2) {
        if (cuenta > 0) {
            g2.setColor(AMARILLO);
            g2.setFont(new Font("Arial", Font.BOLD, 90));
            dibujarTextoCentrado(g2, String.valueOf(cuenta / 60 + 1), 400, 240);
        } else if (partido.getTicksMensaje() > 0) {
            g2.setColor(AMARILLO);
            g2.setFont(new Font("Arial", Font.BOLD, 40));
            dibujarTextoCentrado(g2, partido.getMensaje(), 400, 200);
        }
        if (pausa && cuenta == 0) {
            g2.setColor(new Color(0, 0, 0, 150));
            g2.fillRect(0, 0, 800, 450);
            g2.setColor(Color.WHITE);
            g2.setFont(new Font("Arial", Font.BOLD, 56));
            dibujarTextoCentrado(g2, "PAUSA", 400, 215);
            g2.setFont(new Font("Arial", Font.PLAIN, 18));
            dibujarTextoCentrado(g2, "Pulsa P o Esc para continuar", 400, 250);
        }
    }

    public static void main(String[] args) {
        new DOPOSoccerGUI();
    }
}
