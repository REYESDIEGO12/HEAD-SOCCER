# DOPOSoccer - Versión 3

## Estructura
- `src/dominio`: reglas del juego, archivos de partida/progreso y log de errores
- `src/presentacion`: `DOPOSoccerGUI.java` (toda la interfaz en un solo archivo)
- `test/dominio`: pruebas de unidad (JUnit 4)
- `lib`: junit y hamcrest
- `docs`: boceto y diagramas

## Compilar y ejecutar (desde esta carpeta)
Windows (PowerShell):

    mkdir out
    javac -encoding UTF-8 -d out (Get-ChildItem -Recurse src -Filter *.java).FullName
    java -cp out presentacion.DOPOSoccerGUI

Pruebas:

    mkdir outt
    javac -encoding UTF-8 -cp "out;lib/junit-4.13.2.jar;lib/hamcrest-core-1.3.jar" -d outt (Get-ChildItem -Recurse test -Filter *.java).FullName
    java -cp "out;outt;lib/junit-4.13.2.jar;lib/hamcrest-core-1.3.jar" org.junit.runner.JUnitCore dominio.JugadorTest dominio.BalonTest dominio.PartidoTest dominio.MaquinaTest dominio.PersistenciaTest

Controles: J1 A/D mover, W saltar, F patear, G poder. J2 flechas, L patear, K poder. Pausa: P o Esc.
