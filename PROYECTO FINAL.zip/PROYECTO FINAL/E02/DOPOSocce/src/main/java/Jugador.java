public class Jugador {
    private String personaje;
    private int goles;
    private int vida;
    private int vidaMax;
    private double barraPoder;
    private boolean poderActivo;
    private int speed;
    private int kick;
    private int jump;
    private int survival;
    private int puntos;
    private int x;
    private int y;
    private boolean enElAire;
    private long aturdidoHasta;

    public Jugador(String personaje) {
        this.personaje = personaje;
        speed = 1;
        kick = 1;
        jump = 1;
        survival = 1;
        vidaMax = calcularVidaMax();
        vida = vidaMax;
        goles = 0;
        barraPoder = 0;
        poderActivo = false;
        puntos = 0;
    }

    public int calcularVidaMax() {
        return (int) Math.round(100 * (1 + 0.10 * (survival - 1)));
    }

    public int calcularDanoPatada() {
        return (int) Math.round(10 * (1 + 0.10 * (kick - 1)));
    }

    public int calcularDanoPoder(PoderEspecial poder) {
        return poder.calcularDano(kick);
    }

    public void recibirDano(int dano) {
        vida -= dano;
        if (vida < 0) vida = 0;
        if (vida == 0) {
            aturdidoHasta = System.currentTimeMillis() + 3000;
        }
    }

    public boolean estaAturdido() {
        if (aturdidoHasta == 0) return false;
        if (System.currentTimeMillis() >= aturdidoHasta) {
            aturdidoHasta = 0;
            vida = vidaMax;
            return false;
        }
        return true;
    }

    public void recibirGol() {
        barraPoder = Math.min(100, barraPoder + 25);
    }

    public boolean activarPoder() throws JuegoException {
        if (poderActivo) throw new JuegoException("El poder ya esta activo.");
        if (barraPoder < 100) throw new JuegoException("La barra de poder no esta llena.");
        barraPoder = 0;
        poderActivo = true;
        return true;
    }

    public void usarPoder() {
        poderActivo = false;
    }

    public void agregarPuntos(int cantidad) { puntos += cantidad; }

    public boolean mejorarEstadistica(String estadistica) throws JuegoException {
        int costo = 500;
        if (puntos < costo) throw new JuegoException("No tiene suficientes puntos. Se necesitan 500.");
        if (estadistica.equalsIgnoreCase("speed") && speed < 10) { speed++; }
        else if (estadistica.equalsIgnoreCase("kick") && kick < 10) { kick++; }
        else if (estadistica.equalsIgnoreCase("jump") && jump < 10) { jump++; }
        else if (estadistica.equalsIgnoreCase("survival") && survival < 10) { survival++; vidaMax = calcularVidaMax(); vida = vidaMax; }
        else throw new JuegoException("Estadistica no valida o ya esta en 10.");
        puntos -= costo;
        return true;
    }

    public void reiniciarVida() { vida = vidaMax; }
    public void setPosicion(int x, int y) { this.x = x; this.y = y; }
    public String getPersonaje() { return personaje; }
    public int getGoles() { return goles; }
    public void sumarGol() { goles++; }
    public int getVida() { return vida; }
    public int getVidaMax() { return vidaMax; }
    public double getBarraPoder() { return barraPoder; }
    public boolean isPoderActivo() { return poderActivo; }
    public int getSpeed() { return speed; }
    public int getKick() { return kick; }
    public int getJump() { return jump; }
    public int getSurvival() { return survival; }
    public int getPuntos() { return puntos; }
    public int getX() { return x; }
    public int getY() { return y; }
    public boolean isEnElAire() { return enElAire; }
    public void setEnElAire(boolean valor) { enElAire = valor; }
}
