import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class PanelJuegos extends JPanel {
    private final Partido partido;
    private final Jugador p1;
    private final Jugador p2;
    private boolean izquierda, derecha, a, d;
    private boolean saltar1, saltar2;
    private int velocidadSalto1, velocidadSalto2;
    private boolean pausa;
    private String mensaje = "";
    private int tiempoMensaje = 0;
    private int ultimoGol = 0;

    public PanelJuegos(Partido partido) {
        this.partido = partido;
        p1 = partido.getJugador1();
        p2 = partido.getJugador2();
        setPreferredSize(new Dimension(partido.getCancha().getAncho(), partido.getCancha().getAlto()));
        setFocusable(true);
        p1.setPosicion(100, partido.getCancha().getAlto() - 90);
        p2.setPosicion(partido.getCancha().getAncho() - 150, partido.getCancha().getAlto() - 90);
        configurarTeclas();
    }

    private void configurarTeclas() {
        // Se usan Key Bindings para que las teclas respondan aunque el foco cambie.
        agregarTecla("A", KeyEvent.VK_A, () -> izquierda = true, () -> izquierda = false);
        agregarTecla("D", KeyEvent.VK_D, () -> derecha = true, () -> derecha = false);
        agregarTecla("W", KeyEvent.VK_W, () -> saltar1 = true, () -> {});
        agregarTecla("F", KeyEvent.VK_F, () -> partido.getBalon().patear(1), () -> {});
        agregarTecla("G", KeyEvent.VK_G, () -> activarPoder(p1), () -> {});
        agregarTecla("LEFT", KeyEvent.VK_LEFT, () -> a = true, () -> a = false);
        agregarTecla("RIGHT", KeyEvent.VK_RIGHT, () -> d = true, () -> d = false);
        agregarTecla("UP", KeyEvent.VK_UP, () -> saltar2 = true, () -> {});
        agregarTecla("L", KeyEvent.VK_L, () -> partido.getBalon().patear(-1), () -> {});
        agregarTecla("K", KeyEvent.VK_K, () -> activarPoder(p2), () -> {});
        agregarTecla("P", KeyEvent.VK_P, this::pausar, () -> {});
    }

    private void agregarTecla(String nombre, int codigo, Runnable presionar, Runnable soltar) {
        getInputMap(WHEN_IN_FOCUSED_WINDOW).put(KeyStroke.getKeyStroke(codigo, 0, false), nombre + "_P");
        getActionMap().put(nombre + "_P", new AbstractAction() {
            public void actionPerformed(ActionEvent e) { presionar.run(); }
        });
        getInputMap(WHEN_IN_FOCUSED_WINDOW).put(KeyStroke.getKeyStroke(codigo, 0, true), nombre + "_S");
        getActionMap().put(nombre + "_S", new AbstractAction() {
            public void actionPerformed(ActionEvent e) { soltar.run(); }
        });
    }

    public void actualizar() {
        if (pausa || partido.estaTerminado()) return;
        int ancho = getWidth();
        int suelo = getHeight() - 90;
        if (!p1.estaAturdido()) {
            if (izquierda) p1.setPosicion(Math.max(10, p1.getX() - 5), p1.getY());
            if (derecha) p1.setPosicion(Math.min(ancho - 60, p1.getX() + 5), p1.getY());
            if (saltar1 && p1.getY() >= suelo) velocidadSalto1 = -13;
        }
        if (!p2.estaAturdido()) {
            if (a) p2.setPosicion(Math.max(10, p2.getX() - 5), p2.getY());
            if (d) p2.setPosicion(Math.min(ancho - 60, p2.getX() + 5), p2.getY());
            if (saltar2 && p2.getY() >= suelo) velocidadSalto2 = -13;
        }
        saltar1 = false;
        saltar2 = false;

        // Movimiento vertical sencillo: salto y gravedad para los dos jugadores.
        if (p1.getY() < suelo || velocidadSalto1 < 0) {
            p1.setPosicion(p1.getX(), Math.min(suelo, p1.getY() + velocidadSalto1));
            velocidadSalto1 += 1;
        }
        if (p2.getY() < suelo || velocidadSalto2 < 0) {
            p2.setPosicion(p2.getX(), Math.min(suelo, p2.getY() + velocidadSalto2));
            velocidadSalto2 += 1;
        }
        if (p1.getY() >= suelo) { p1.setPosicion(p1.getX(), suelo); velocidadSalto1 = 0; }
        if (p2.getY() >= suelo) { p2.setPosicion(p2.getX(), suelo); velocidadSalto2 = 0; }

        partido.getBalon().actualizar(ancho, getHeight());
        revisarGol();
        if (tiempoMensaje > 0) tiempoMensaje--;
        repaint();
    }

    private void revisarGol() {
        Balon balon = partido.getBalon();
        int x = balon.getX();
        int y = balon.getY();
        int alto = getHeight();
        // El balón debe cruzar la línea de gol dentro de la abertura del arco.
        if (ultimoGol > 0) { ultimoGol--; return; }
        if (y >= alto - 90 && y <= alto - 20) {
            if (x <= 45) {
                partido.registrarGol(2);
                mensaje = "¡GOL DE " + p2.getPersonaje().toUpperCase() + "!";
                reiniciarDespuesGol();
            } else if (x >= getWidth() - 45) {
                partido.registrarGol(1);
                mensaje = "¡GOL DE " + p1.getPersonaje().toUpperCase() + "!";
                reiniciarDespuesGol();
            }
        }
    }

    private void reiniciarDespuesGol() {
        tiempoMensaje = 55;
        ultimoGol = 55;
        int suelo = getHeight() - 90;
        p1.setPosicion(100, suelo);
        p2.setPosicion(getWidth() - 150, suelo);
        velocidadSalto1 = 0;
        velocidadSalto2 = 0;
        partido.getBalon().reiniciar(getWidth() / 2, getHeight() - 110);
    }

    public void pausar() { pausa = !pausa; repaint(); }

    @Override protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        int w = getWidth(), h = getHeight();
        g.setColor(new Color(120, 170, 225)); g.fillRect(0, 0, w, h);
        g.setColor(new Color(40, 205, 105)); g.fillRect(0, h - 110, w, 110);
        g.setColor(Color.WHITE); g.drawLine(w / 2, h - 110, w / 2, h); g.drawOval(w / 2 - 50, h - 95, 100, 100);
        g.drawRect(0, h - 80, 60, 60); g.drawRect(w - 60, h - 80, 60, 60);
        dibujarJugador(g, p1, new Color(40, 90, 190));
        dibujarJugador(g, p2, new Color(190, 70, 70));
        g.setColor(Color.WHITE); g.fillOval(partido.getBalon().getX() - 10, partido.getBalon().getY() - 10, 20, 20);
        g.setColor(Color.DARK_GRAY); g.drawOval(partido.getBalon().getX() - 10, partido.getBalon().getY() - 10, 20, 20);
        g.setColor(Color.WHITE); g.setFont(new Font("Arial", Font.BOLD, 22));
        g.drawString(p1.getPersonaje() + "  " + p1.getGoles() + " - " + p2.getGoles() + "  " + p2.getPersonaje(), 20, 30);
        g.setFont(new Font("Arial", Font.PLAIN, 14));
        g.drawString("P1: A/D mover, W saltar, F patear, G poder", 20, 52);
        g.drawString("P2: ←/→ mover, ↑ saltar, L patear, K poder", 20, 70);
        if (tiempoMensaje > 0) {
            g.setFont(new Font("Arial", Font.BOLD, 42)); g.setColor(Color.YELLOW);
            g.drawString(mensaje, w / 2 - 180, h / 2 - 20);
        }
        if (pausa) { g.setColor(new Color(0,0,0,130)); g.fillRect(0,0,w,h); g.setColor(Color.WHITE); g.setFont(new Font("Arial", Font.BOLD, 40)); g.drawString("PAUSA", w/2-70, h/2); }
        if (partido.estaTerminado()) { g.setColor(new Color(0,0,0,160)); g.fillRect(0,0,w,h); g.setColor(Color.WHITE); g.setFont(new Font("Arial", Font.BOLD, 30)); g.drawString("Ganador: " + partido.ganador(), w/2-120, h/2); }
    }

    private void dibujarJugador(Graphics g, Jugador p, Color color) {
        g.setColor(color); g.fillOval(p.getX(), p.getY() - 40, 50, 50); g.fillRect(p.getX()+8, p.getY(), 34, 35);
        if (p.isPoderActivo()) { g.setColor(Color.YELLOW); g.drawOval(p.getX()-8, p.getY()-48, 66, 92); }
        g.setColor(Color.BLACK); g.drawString("HP " + p.getVida(), p.getX(), p.getY()-48);
    }
    private void activarPoder(Jugador jugador) {
        try { jugador.activarPoder(); }
        catch (JuegoException ex) { Toolkit.getDefaultToolkit().beep(); }
    }
}
