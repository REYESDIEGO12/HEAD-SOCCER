import javax.swing.*;
import java.awt.*;

public class ControladorJuegos {
    private final JFrame ventana;
    private final Juego juego;

    public ControladorJuegos() {
        juego = new Juego();
        ventana = new JFrame("DOPOSoccer v1.0");
        ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    public void mostrarMenu() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(new Color(50, 190, 175));
        GridBagConstraints c = new GridBagConstraints(); c.insets = new Insets(10,10,10,10);
        JLabel titulo = new JLabel("DOPOSOCCER"); titulo.setFont(new Font("Arial", Font.BOLD, 34));
        c.gridx=0;c.gridy=0;panel.add(titulo,c);
        JButton iniciar = new JButton("INICIAR"); JButton salir = new JButton("SALIR");
        c.gridy=1; panel.add(iniciar,c); c.gridy=2; panel.add(salir,c);
        iniciar.addActionListener(e -> configurar()); salir.addActionListener(e -> System.exit(0));
        ventana.setContentPane(panel); ventana.setSize(700,450); ventana.setLocationRelativeTo(null); ventana.setVisible(true);
    }

    private void configurar() {
        JPanel p = new JPanel(new GridLayout(0,2,8,8));
        JComboBox<String> resolucion = new JComboBox<>(new String[]{"800x450","1000x560","1200x675"});
        JComboBox<String> personaje1 = new JComboBox<>(new String[]{"Corea del Sur","Camerun","Nigeria","Estados Unidos"});
        JComboBox<String> personaje2 = new JComboBox<>(new String[]{"Corea del Sur","Camerun","Nigeria","Estados Unidos"});
        JComboBox<String> tipo = new JComboBox<>(new String[]{"Por goles","Por tiempo"});
        JTextField objetivo = new JTextField("3");
        p.add(new JLabel("Resolucion:")); p.add(resolucion); p.add(new JLabel("Jugador 1:")); p.add(personaje1); p.add(new JLabel("Jugador 2:")); p.add(personaje2); p.add(new JLabel("Tipo de partido:")); p.add(tipo); p.add(new JLabel("Goles/minutos:")); p.add(objetivo);
        int r = JOptionPane.showConfirmDialog(ventana,p,"Configuracion del juego",JOptionPane.OK_CANCEL_OPTION);
        if(r != JOptionPane.OK_OPTION) return;
        try {
            String[] partes = resolucion.getSelectedItem().toString().split("x");
            boolean porGoles = tipo.getSelectedIndex()==0;
            int valor = Integer.parseInt(objetivo.getText());
            juego.crearPartido(personaje1.getSelectedItem().toString(), personaje2.getSelectedItem().toString(), Integer.parseInt(partes[0]), Integer.parseInt(partes[1]), porGoles, valor);
            iniciarPartido();
        } catch (Exception ex) { JOptionPane.showMessageDialog(ventana, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE); }
    }

    private void iniciarPartido() {
        PanelJuegos panel = new PanelJuegos(juego.getPartido());
        ventana.setContentPane(panel); ventana.pack(); ventana.setLocationRelativeTo(null); ventana.setVisible(true);
        panel.requestFocusInWindow();
        new Timer(30, e -> panel.actualizar()).start();
    }

    public static void main(String[] args) { SwingUtilities.invokeLater(() -> new ControladorJuegos().mostrarMenu()); }
}
