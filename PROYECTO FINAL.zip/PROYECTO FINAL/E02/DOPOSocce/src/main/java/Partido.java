public class Partido {
    private Jugador jugador1;
    private Jugador jugador2;
    private Balon balon;
    private Cancha cancha;
    private boolean porGoles;
    private int golesParaGanar;
    private int segundos;
    private boolean terminado;

    public Partido(Jugador jugador1, Jugador jugador2, Cancha cancha, boolean porGoles, int objetivo) {
        this.jugador1 = jugador1;
        this.jugador2 = jugador2;
        this.cancha = cancha;
        this.porGoles = porGoles;
        if (porGoles) golesParaGanar = objetivo;
        else segundos = objetivo;
        balon = new Balon(cancha.getAncho() / 2, cancha.getAlto() - 70);
    }

    public void registrarGol(int numeroJugador) {
        if (terminado) return;
        if (numeroJugador == 1) {
            jugador1.sumarGol();
            jugador2.recibirGol();
        } else {
            jugador2.sumarGol();
            jugador1.recibirGol();
        }
        if (porGoles && (jugador1.getGoles() >= golesParaGanar || jugador2.getGoles() >= golesParaGanar)) {
            terminado = true;
        }
    }

    public String ganador() {
        if (jugador1.getGoles() > jugador2.getGoles()) return jugador1.getPersonaje();
        if (jugador2.getGoles() > jugador1.getGoles()) return jugador2.getPersonaje();
        return "Empate";
    }

    public void terminarPorTiempo() { terminado = true; }
    public boolean estaTerminado() { return terminado; }
    public Jugador getJugador1() { return jugador1; }
    public Jugador getJugador2() { return jugador2; }
    public Balon getBalon() { return balon; }
    public Cancha getCancha() { return cancha; }
    public boolean isPorGoles() { return porGoles; }
    public int getGolesParaGanar() { return golesParaGanar; }
    public int getSegundos() { return segundos; }
}
