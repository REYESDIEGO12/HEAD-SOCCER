public class Balon {
    private int x;
    private int y;
    private int velocidadX;
    private int velocidadY;
    private final int radio = 12;

    public Balon(int x, int y) {
        this.x = x;
        this.y = y;
    }

    public void actualizar(int ancho, int alto) {
        x += velocidadX;
        y += velocidadY;
        velocidadY += 1;
        if (y >= alto - 55) {
            y = alto - 55;
            velocidadY = -Math.abs(velocidadY) / 2;
        }
        // El balón puede salir por los lados para que el panel detecte un gol.
    }

    public void reiniciar(int nuevoX, int nuevoY) {
        x = nuevoX;
        y = nuevoY;
        velocidadX = 0;
        velocidadY = 0;
    }

    public void patear(int direccion) {
        velocidadX = 7 * direccion;
        velocidadY = -5;
    }

    public int getX() { return x; }
    public int getY() { return y; }
    public int getRadio() { return radio; }
}
