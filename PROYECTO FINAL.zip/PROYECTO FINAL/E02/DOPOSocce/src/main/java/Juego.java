public class Juego {
    private Partido partido;

    public void crearPartido(String personaje1, String personaje2, int ancho, int alto, boolean porGoles, int objetivo) throws JuegoException {
        if (personaje1 == null || personaje2 == null || personaje1.isBlank() || personaje2.isBlank()) {
            throw new JuegoException("Debe seleccionar los dos personajes.");
        }
        if (ancho <= 0 || alto <= 0) throw new JuegoException("La resolucion no es valida.");
        if (objetivo <= 0) throw new JuegoException("El objetivo debe ser mayor que cero.");
        partido = new Partido(new Jugador(personaje1), new Jugador(personaje2), new Cancha(ancho, alto), porGoles, objetivo);
    }

    public Partido getPartido() { return partido; }
}
