public class PoderEspecial {
    private String nombre;
    private double duracion;
    private int danoTiro;
    private String efecto;

    public PoderEspecial(String nombre, double duracion, int danoTiro, String efecto) {
        this.nombre = nombre;
        this.duracion = duracion;
        this.danoTiro = danoTiro;
        this.efecto = efecto;
    }

    public String getNombre() { return nombre; }
    public double getDuracion() { return duracion; }
    public int getDanoTiro() { return danoTiro; }
    public String getEfecto() { return efecto; }

    public int calcularDano(int kick) {
        double multiplicador = 1 + 0.10 * (kick - 1);
        return (int) Math.round(danoTiro * multiplicador);
    }
}
