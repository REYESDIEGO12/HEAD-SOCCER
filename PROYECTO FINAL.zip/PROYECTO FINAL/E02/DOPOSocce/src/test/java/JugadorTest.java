import org.junit.Test;
import static org.junit.Assert.*;

public class JugadorTest {
    @Test public void vidaSegunSurvival() {
        Jugador jugador = new Jugador("Camerun");
        assertEquals(100, jugador.getVidaMax());
    }

    @Test public void danoPatadaSegunKick() {
        Jugador jugador = new Jugador("Nigeria");
        assertEquals(10, jugador.calcularDanoPatada());
    }

    @Test public void golAumentaBarra() {
        Jugador jugador = new Jugador("Corea del Sur");
        jugador.recibirGol();
        assertEquals(25.0, jugador.getBarraPoder(), 0.01);
    }

    @Test public void poderNoSePuedeActivarSinBarra() {
        Jugador jugador = new Jugador("Estados Unidos");
        try {
            jugador.activarPoder();
            fail("Debia lanzar excepcion");
        } catch (JuegoException e) {
            assertEquals("La barra de poder no esta llena.", e.getMessage());
        }
    }
}
