import org.junit.Test;
import static org.junit.Assert.*;

public class PartidoTest {
    @Test public void registraGol() {
        Partido partido = new Partido(new Jugador("Corea del Sur"), new Jugador("Nigeria"), new Cancha(800,450), true, 3);
        partido.registrarGol(1);
        assertEquals(1, partido.getJugador1().getGoles());
        assertEquals(25.0, partido.getJugador2().getBarraPoder(), 0.01);
    }

    @Test public void ganaAlLlegarAGoles() {
        Partido partido = new Partido(new Jugador("Corea del Sur"), new Jugador("Nigeria"), new Cancha(800,450), true, 1);
        partido.registrarGol(1);
        assertTrue(partido.estaTerminado());
        assertEquals("Corea del Sur", partido.ganador());
    }
}
