package presentacion;

import dominio.Cancha;
import dominio.Personaje;

import javax.swing.*;
import java.awt.*;
import java.awt.geom.Ellipse2D;
import java.util.ArrayList;

public class PanelMenu extends JPanel {
    private final Timer animacion;
    private int tick;

    public PanelMenu(ControladorJuego controlador) {
        setLayout(new GridBagLayout());
        setPreferredSize(new Dimension(900, 600));
        GridBagConstraints c = new GridBagConstraints();
        c.gridx = 0;
        c.insets = new Insets(7, 0, 7, 0);

        c.gridy = 0;
        c.insets = new Insets(260, 0, 7, 0);
        add(boton("JUGAR", Estilo.VERDE, controlador::mostrarConfiguracion), c);
        c.insets = new Insets(7, 0, 7, 0);
        c.gridy = 1;
        add(boton("ABRIR PARTIDA", new Color(155, 89, 182), controlador::abrirPartida), c);
        c.gridy = 2;
        add(boton("SALIR", Estilo.ROJO, controlador::salir), c);

        animacion = new Timer(30, e -> { tick++; repaint(); });
        animacion.start();
    }

    private BotonJuego boton(String texto, Color color, Runnable accion) {
        BotonJuego b = new BotonJuego(texto, color);
        b.addActionListener(e -> accion.run());
        return b;
    }

    public void detener() { animacion.stop(); }

    protected void paintComponent(Graphics g0) {
        super.paintComponent(g0);
        Graphics2D g = (Graphics2D) g0.create();
        Estilo.calidad(g);
        int w = getWidth();
        int h = getHeight();
        Estilo.fondoDegradado(g, w, h);

        for (int i = 0; i < 24; i++) {
            double x = (i * 137 + tick * (0.3 + (i % 5) * 0.1)) % (w + 40) - 20;
            double y = (i * 71 + 40) % (h - 100);
            g.setColor(new Color(255, 255, 255, 25 + (i % 4) * 8));
            double r = 2 + i % 4;
            g.fill(new Ellipse2D.Double(x, y, r, r));
        }

        g.setPaint(new GradientPaint(0, h - 150, new Color(34, 139, 60), 0, h, new Color(20, 90, 40)));
        g.fillRect(0, h - 150, w, 150);
        g.setColor(new Color(255, 255, 255, 120));
        g.setStroke(new BasicStroke(3f));
        g.drawLine(0, h - 150, w, h - 150);
        g.drawOval(w / 2 - 90, h - 100, 180, 60);

        Estilo.textoCentrado(g, "DOPOSOCCER", w / 2.0, 120, Estilo.fuente(Font.BOLD, 76), Estilo.ACENTO);

        ArrayList<Personaje> lista = Personaje.catalogo();
        for (int i = 0; i < lista.size(); i++) {
            double px = w / 2.0 - 330 + i * 220 + 50;
            double py = 215 + 6 * Math.sin(tick * 0.08 + i);
            Dibujante.cabeza(g, px, py, 28, lista.get(i).getPais(), i % 2 == 0 ? 1 : -1, false);
            Estilo.textoCentrado(g, lista.get(i).getPais(), px, py + 50, Estilo.fuente(Font.BOLD, 13), Color.WHITE);
        }

        double bx = w / 2.0 + 330;
        double by = h - 80 - Math.abs(Math.sin(tick * 0.09)) * 90;
        g.setColor(new Color(0, 0, 0, 70));
        g.fillOval((int) bx - 14, h - 76, 28, 8);
        g.setColor(Color.WHITE);
        g.fill(new Ellipse2D.Double(bx - 15, by - 15, 30, 30));
        g.setColor(new Color(40, 40, 50));
        g.setStroke(new BasicStroke(2f));
        g.draw(new Ellipse2D.Double(bx - 15, by - 15, 30, 30));
        g.dispose();
    }
}
