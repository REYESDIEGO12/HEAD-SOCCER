package presentacion;

import dominio.*;
import persistencia.ArchivoPartida;
import persistencia.ArchivoProgreso;
import persistencia.RegistroErrores;

import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.*;
import java.io.File;

public class ControladorJuego {
    private final JFrame ventana = new JFrame("DOPOSoccer 2026-2");
    private final Juego juego = new Juego();
    private final ArchivoProgreso progreso = new ArchivoProgreso();
    private PanelCancha panelCancha;
    private PanelMenu panelMenu;

    public ControladorJuego() {
        ventana.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        ventana.addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent e) { salir(); }
        });
    }

    private void mostrar(JComponent panel) {
        if (panelMenu != null) { panelMenu.detener(); panelMenu = null; }
        if (panelCancha != null) { panelCancha.detener(); panelCancha = null; }
        ventana.setContentPane(panel);
        ventana.pack();
        ventana.setLocationRelativeTo(null);
        ventana.setVisible(true);
        ventana.revalidate();
        ventana.repaint();
    }

    public void mostrarMenu() {
        panelMenu = null;
        PanelMenu nuevo = new PanelMenu(this);
        mostrar(nuevo);
        panelMenu = nuevo;
    }

    public void mostrarConfiguracion() { mostrar(new PanelConfiguracion(this)); }
    public void mostrarMejoras() { mostrar(new PanelMejoras(this, progreso)); }

    public void iniciarPartido(Jugador j1, Jugador j2, int ancho, int alto, boolean porGoles, int objetivo) {
        try {

            if (!j1.esMaquina()) progreso.cargarEn(j1);
            if (!j2.esMaquina()) progreso.cargarEn(j2);
            juego.crearPartido(j1, j2, ancho, alto, porGoles, objetivo);
            mostrarPartido(juego.getPartido(), true);
        } catch (JuegoException e) {
            mostrarError(e);
        }
    }

    private void mostrarPartido(Partido partido, boolean conCuenta) {
        PanelCancha cancha = new PanelCancha(partido, conCuenta, this::finDePartido);

        JPanel barra = new JPanel(new FlowLayout(FlowLayout.CENTER, 12, 6));
        barra.setBackground(Estilo.FONDO_OSCURO);
        JButton pausa = botonBarra("⏸ Pausa (P)");
        JButton guardar = botonBarra("💾 Guardar partida");
        JButton terminar = botonBarra("⏹ Terminar partido");
        JLabel controles = new JLabel("J1: A/D mover · W saltar · F patear · G poder      J2: ←/→ mover · ↑ saltar · L patear · K poder");
        controles.setForeground(Estilo.TEXTO_SUAVE);
        controles.setFont(Estilo.fuente(Font.PLAIN, 12));
        pausa.addActionListener(e -> cancha.alternarPausa());
        guardar.addActionListener(e -> guardarPartida(cancha));
        terminar.addActionListener(e -> terminarPartido(cancha));
        barra.add(pausa);
        barra.add(guardar);
        barra.add(terminar);
        barra.add(controles);

        JPanel contenedor = new JPanel(new BorderLayout());
        contenedor.add(cancha, BorderLayout.CENTER);
        contenedor.add(barra, BorderLayout.SOUTH);
        mostrar(contenedor);
        panelCancha = cancha;
        cancha.requestFocusInWindow();
    }

    private JButton botonBarra(String texto) {
        JButton b = new JButton(texto);
        b.setFocusable(false);
        return b;
    }

    private void guardarPartida(PanelCancha cancha) {
        boolean estabaEnPausa = cancha.estaEnPausa();
        cancha.pausar();
        JFileChooser selector = new JFileChooser(new File("."));
        selector.setDialogTitle("Guardar partida");
        selector.setFileFilter(new FileNameExtensionFilter("Partida de DOPOSoccer (*.dopo)", "dopo"));
        if (selector.showSaveDialog(ventana) == JFileChooser.APPROVE_OPTION) {
            File archivo = selector.getSelectedFile();
            if (!archivo.getName().toLowerCase().endsWith(ArchivoPartida.EXTENSION)) {
                archivo = new File(archivo.getPath() + ArchivoPartida.EXTENSION);
            }
            try {
                ArchivoPartida.guardar(cancha.getPartido(), archivo);
                JOptionPane.showMessageDialog(ventana, "Partida guardada en:\n" + archivo.getPath(), "Partida guardada", JOptionPane.INFORMATION_MESSAGE);
            } catch (JuegoException e) {
                mostrarError(e);
            }
        }
        if (!estabaEnPausa) cancha.alternarPausa();
        cancha.requestFocusInWindow();
    }

    public void abrirPartida() {
        JFileChooser selector = new JFileChooser(new File("."));
        selector.setDialogTitle("Abrir partida");
        selector.setFileFilter(new FileNameExtensionFilter("Partida de DOPOSoccer (*.dopo)", "dopo"));
        if (selector.showOpenDialog(ventana) != JFileChooser.APPROVE_OPTION) return;
        try {
            Partido partido = ArchivoPartida.abrir(selector.getSelectedFile());
            juego.setPartido(partido);
            mostrarPartido(partido, false);
        } catch (JuegoException e) {
            mostrarError(e);
        }
    }

    private void terminarPartido(PanelCancha cancha) {
        boolean estabaEnPausa = cancha.estaEnPausa();
        cancha.pausar();
        int r = JOptionPane.showConfirmDialog(ventana, "¿Seguro que quieres terminar el partido?\nGana quien vaya anotando más goles.",
                "Terminar partido", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
        if (r == JOptionPane.YES_OPTION) {
            cancha.terminarAhora();
        } else {
            if (!estabaEnPausa) cancha.alternarPausa();
            cancha.requestFocusInWindow();
        }
    }

    private void finDePartido() {
        Partido partido = juego.getPartido();
        partido.otorgarPuntos();
        try {
            if (!partido.getJugador1().esMaquina()) progreso.guardarDe(partido.getJugador1());
            if (!partido.getJugador2().esMaquina()) progreso.guardarDe(partido.getJugador2());
        } catch (JuegoException e) {
            mostrarError(e);
        }
        Jugador j1 = partido.getJugador1();
        Jugador j2 = partido.getJugador2();
        String titulo = partido.getGanador() == null ? "¡Empate!" : "¡Ganó " + partido.nombreGanador() + "!";
        String mensaje = "<html><div style='width:300px'><h2>" + titulo + "</h2>"
                + "<p style='font-size:15px'>" + j1.getNombre() + " " + j1.getGoles() + " - " + j2.getGoles() + " " + j2.getNombre() + "</p><br>"
                + "<b>Puntos obtenidos</b><br>"
                + j1.getNombre() + ": +" + partido.getPuntosGanados1() + " (total " + j1.getPuntos() + ")<br>"
                + j2.getNombre() + ": +" + partido.getPuntosGanados2() + " (total " + j2.getPuntos() + ")</div></html>";
        Object[] opciones = {"Mejorar estadísticas", "Menú principal"};
        int r = JOptionPane.showOptionDialog(ventana, mensaje, "Fin del partido", JOptionPane.DEFAULT_OPTION,
                JOptionPane.INFORMATION_MESSAGE, null, opciones, opciones[1]);
        if (r == 0) mostrarMejoras();
        else mostrarMenu();
    }

    public void mostrarError(JuegoException e) {
        RegistroErrores.registrar("Error mostrado al usuario", e);
        JOptionPane.showMessageDialog(ventana, e.getMessage(), "Algo salió mal", JOptionPane.ERROR_MESSAGE);
    }

    public void salir() {
        int r = JOptionPane.showConfirmDialog(ventana, "¿Seguro que quieres salir de DOPOSoccer?", "Salir", JOptionPane.YES_NO_OPTION);
        if (r == JOptionPane.YES_OPTION) System.exit(0);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new ControladorJuego().mostrarMenu());
    }
}
