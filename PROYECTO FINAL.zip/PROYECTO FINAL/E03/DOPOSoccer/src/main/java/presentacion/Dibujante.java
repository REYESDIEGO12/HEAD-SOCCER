package presentacion;

import dominio.*;

import java.awt.*;
import java.awt.geom.*;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.Random;

public class Dibujante {

    public static Color[] colores(String pais) {
        if (pais.startsWith("Corea")) {
            return new Color[]{new Color(245, 245, 250), new Color(205, 46, 58), new Color(0, 71, 160), new Color(255, 224, 189), new Color(25, 25, 30)};
        }
        if (pais.startsWith("Camer")) {
            return new Color[]{new Color(0, 140, 70), new Color(206, 17, 38), new Color(252, 209, 22), new Color(141, 85, 36), new Color(20, 20, 20)};
        }
        if (pais.startsWith("Nigeria")) {
            return new Color[]{new Color(0, 150, 90), new Color(255, 255, 255), new Color(255, 255, 255), new Color(104, 66, 38), new Color(15, 15, 15)};
        }
        if (pais.startsWith("Estados")) {
            return new Color[]{new Color(25, 60, 130), new Color(190, 30, 70), new Color(255, 255, 255), new Color(236, 194, 140), new Color(110, 68, 30)};
        }
        return new Color[]{Color.GRAY, Color.DARK_GRAY, Color.LIGHT_GRAY, new Color(230, 200, 170), Color.BLACK};
    }

    public static Color colorPoder(PoderEspecial poder) {
        String n = poder.getNombre();
        if (n.equals("Aura Azul")) return new Color(60, 140, 255);
        if (n.equals("Rayo")) return new Color(255, 225, 40);
        if (n.equals("Tornado")) return new Color(200, 215, 230);
        if (n.equals("Ilusión")) return new Color(190, 90, 255);
        return new Color(255, 140, 0);
    }

    public static void cabeza(Graphics2D g, double cx, double cy, double r, String pais, int dir, boolean mareado) {
        Color[] c = colores(pais);
        Ellipse2D cara = new Ellipse2D.Double(cx - r, cy - r, 2 * r, 2 * r);
        g.setPaint(new RadialGradientPaint(new Point2D.Double(cx - r * 0.3, cy - r * 0.35), (float) (r * 1.5),
                new float[]{0f, 1f}, new Color[]{c[3].brighter(), c[3].darker()}));
        g.fill(cara);

        Shape clipAntes = g.getClip();
        g.clip(cara);
        g.setColor(c[4]);
        g.fill(new Ellipse2D.Double(cx - r * 1.1, cy - r * 1.4, r * 2.2, r * 1.05));
        g.setColor(c[2]);
        g.fill(new Rectangle2D.Double(cx - r, cy - r * 0.40, 2 * r, r * 0.20));
        g.setColor(c[1]);
        g.fill(new Rectangle2D.Double(cx - r, cy - r * 0.20, 2 * r, r * 0.07));
        g.setClip(clipAntes);
        g.setColor(new Color(0, 0, 0, 110));
        g.setStroke(new BasicStroke((float) Math.max(1.2, r * 0.07)));
        g.draw(cara);

        double centroCara = cx + dir * r * 0.18;
        double ey = cy + r * 0.08;
        for (int lado = -1; lado <= 1; lado += 2) {
            double ex = centroCara + lado * r * 0.30;
            if (mareado) {
                g.setColor(new Color(40, 20, 20));
                g.setStroke(new BasicStroke((float) (r * 0.08)));
                double k = r * 0.12;
                g.draw(new Line2D.Double(ex - k, ey - k, ex + k, ey + k));
                g.draw(new Line2D.Double(ex - k, ey + k, ex + k, ey - k));
            } else {
                g.setColor(Color.WHITE);
                g.fill(new Ellipse2D.Double(ex - r * 0.17, ey - r * 0.2, r * 0.34, r * 0.4));
                g.setColor(new Color(20, 20, 30));
                g.fill(new Ellipse2D.Double(ex + dir * r * 0.05 - r * 0.08, ey - r * 0.1, r * 0.16, r * 0.2));
                g.setColor(Color.BLACK);
                g.setStroke(new BasicStroke((float) (r * 0.09), BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
                double lejos = ex + lado * r * 0.2;
                double cerca = ex - lado * r * 0.2;
                g.draw(new Line2D.Double(lejos, ey - r * 0.36, cerca, ey - r * 0.22));
            }
        }
        g.setColor(new Color(90, 30, 30));
        g.setStroke(new BasicStroke((float) (r * 0.08), BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        if (mareado) {
            g.fill(new Ellipse2D.Double(centroCara - r * 0.1, cy + r * 0.42, r * 0.2, r * 0.2));
        } else {
            g.draw(new Arc2D.Double(centroCara - r * 0.22, cy + r * 0.30, r * 0.44, r * 0.30, 200, 140, Arc2D.OPEN));
        }
    }

    public static void jugador(Graphics2D g, Jugador j, Color etiqueta, int tick, int destello) {
        double x = j.getX();
        double y = j.getY();
        int dir = j.getDireccion();
        Color[] c = colores(j.getPais());
        boolean noqueado = j.estaAturdido() || j.getEfecto() == Efecto.INCONSCIENTE;

        double altura = Cancha.SUELO - y;
        double esc = Math.max(0.35, 1 - altura / 260.0);
        g.setColor(new Color(0, 0, 0, (int) (90 * esc)));
        g.fill(new Ellipse2D.Double(x - 34 * esc, Cancha.SUELO - 4, 68 * esc, 13 * esc));

        if (j.isPoderActivo()) aura(g, x, y - 44, colorPoder(j.getPersonaje().getPoder()), tick);

        AffineTransform original = g.getTransform();
        if (noqueado) g.rotate(Math.toRadians(-dir * 20), x, y);

        Color piel = c[3];
        g.setStroke(new BasicStroke(9f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        g.setColor(piel.darker());
        g.draw(new Line2D.Double(x - dir * 9, y - 12, x - dir * 9, y - 5));
        g.setColor(piel);
        double pieX = x + dir * 9;
        double pieY = y - 5;
        if (j.estaPateando()) { pieX = j.getPieX(); pieY = j.getPieY() + 6; }
        g.draw(new Line2D.Double(x + dir * 6, y - 14, pieX, pieY));
        g.setColor(new Color(30, 30, 38));
        g.fill(new Ellipse2D.Double(x - dir * 9 - 10, y - 7, 20, 9));
        AffineTransform antesBotin = g.getTransform();
        if (j.estaPateando()) g.rotate(-dir * 0.5 * Math.sin(Math.PI * j.getProgresoPatada()), pieX, pieY);
        g.setColor(new Color(30, 30, 38));
        g.fill(new RoundRectangle2D.Double(pieX - 9 + dir * 3, pieY - 4, 22, 11, 8, 8));
        g.setColor(c[1]);
        g.fill(new Rectangle2D.Double(pieX - 3 + dir * 3, pieY - 4, 5, 11));
        g.setTransform(antesBotin);

        g.setColor(c[0].darker().darker());
        g.fill(new RoundRectangle2D.Double(x - 14, y - 24, 28, 14, 6, 6));
        g.setPaint(new GradientPaint((float) (x - 16), 0, c[0].brighter(), (float) (x + 16), 0, c[0].darker()));
        g.fill(new RoundRectangle2D.Double(x - 16, y - 40, 32, 22, 10, 10));
        g.setColor(c[1]);
        g.fill(new Rectangle2D.Double(x - 16, y - 31, 32, 5));
        g.setColor(piel);
        g.fill(new Ellipse2D.Double(x - 22, y - 34, 9, 9));
        g.fill(new Ellipse2D.Double(x + 13, y - 34, 9, 9));

        cabeza(g, x, y - 52, Jugador.RADIO_CABEZA, j.getPais(), dir, noqueado);

        g.setTransform(original);

        if (destello > 0) {
            g.setColor(new Color(255, 255, 255, Math.min(200, destello * 22)));
            g.fill(new Ellipse2D.Double(x - 30, y - 84, 60, 86));
        }
        efectos(g, j, tick);

        g.setFont(Estilo.fuente(Font.BOLD, 11));
        FontMetrics fm = g.getFontMetrics();
        String nombre = j.getNombre();
        if (nombre.length() > 12) nombre = nombre.substring(0, 12);
        int ancho = fm.stringWidth(nombre) + 12;
        double ty = y - 106;
        g.setColor(new Color(etiqueta.getRed(), etiqueta.getGreen(), etiqueta.getBlue(), 220));
        g.fill(new RoundRectangle2D.Double(x - ancho / 2.0, ty, ancho, 16, 10, 10));
        Path2D flecha = new Path2D.Double();
        flecha.moveTo(x - 5, ty + 15);
        flecha.lineTo(x + 5, ty + 15);
        flecha.lineTo(x, ty + 22);
        flecha.closePath();
        g.fill(flecha);
        g.setColor(Color.WHITE);
        g.drawString(nombre, (float) (x - fm.stringWidth(nombre) / 2.0), (float) (ty + 12));
    }

    public static void aura(Graphics2D g, double cx, double cy, Color color, int tick) {
        double r = 66 + 5 * Math.sin(tick * 0.18);
        Color centro = new Color(color.getRed(), color.getGreen(), color.getBlue(), 230);
        Color medio = new Color(color.getRed(), color.getGreen(), color.getBlue(), 120);
        Color fuera = new Color(color.getRed(), color.getGreen(), color.getBlue(), 0);
        g.setPaint(new RadialGradientPaint(new Point2D.Double(cx, cy), (float) r,
                new float[]{0f, 0.6f, 1f}, new Color[]{centro, medio, fuera}));
        g.fill(new Ellipse2D.Double(cx - r, cy - r, 2 * r, 2 * r));
        g.setColor(new Color(color.getRed(), color.getGreen(), color.getBlue(), 200));
        g.setStroke(new BasicStroke(2.5f));
        g.draw(new Ellipse2D.Double(cx - r * 0.62, cy - r * 0.62, r * 1.24, r * 1.24));
        g.setColor(new Color(255, 255, 255, 200));
        for (int i = 0; i < 6; i++) {
            double fase = (tick * 0.03 + i / 6.0) % 1.0;
            double ang = i * 1.05 + tick * 0.04;
            double px = cx + Math.cos(ang) * 36;
            double py = cy + 46 - fase * 100;
            g.fill(new Ellipse2D.Double(px - 2, py - 2, 4, 4));
        }
    }

    public static void efectos(Graphics2D g, Jugador j, int tick) {
        double x = j.getX();
        double y = j.getY();
        Efecto e = j.getEfecto();
        if (e == Efecto.ELECTROCUTADO) {
            Random azar = new Random(tick / 2 + (long) (x * 7));
            g.setColor(new Color(255, 240, 90));
            g.setStroke(new BasicStroke(2.4f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
            for (int rayo = 0; rayo < 4; rayo++) {
                double px = x + (azar.nextDouble() - 0.5) * 50;
                double py = y - 90 + azar.nextDouble() * 20;
                for (int seg = 0; seg < 5; seg++) {
                    double nx = px + (azar.nextDouble() - 0.5) * 22;
                    double ny = py + 15 + azar.nextDouble() * 8;
                    g.draw(new Line2D.Double(px, py, nx, ny));
                    px = nx;
                    py = ny;
                }
            }
        }
        if (e == Efecto.EMPUJE) {
            int s = j.getVx() >= 0 ? 1 : -1;
            g.setStroke(new BasicStroke(3f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
            for (int i = 0; i < 5; i++) {
                g.setColor(new Color(110, 175, 255, 200 - i * 25));
                double ly = y - 20 - i * 16;
                g.draw(new Line2D.Double(x - s * (34 + i * 4), ly, x - s * (70 + i * 6), ly));
            }
        }
        if (j.estaAturdido() || e == Efecto.INCONSCIENTE) {
            for (int i = 0; i < 3; i++) {
                double ang = tick * 0.12 + i * 2.09;
                estrella(g, x + Math.cos(ang) * 30, y - 90 + Math.sin(ang) * 8, 7, new Color(255, 220, 40));
            }
        }
        if (e == Efecto.CONFUNDIDO) {
            g.setFont(Estilo.fuente(Font.BOLD, 26));
            g.setColor(new Color(200, 110, 255));
            for (int i = 0; i < 2; i++) {
                double bx = x - 24 + i * 38;
                double by = y - 98 + Math.sin(tick * 0.2 + i * 2) * 5;
                g.drawString("?", (float) bx, (float) by);
            }
        }
    }

    public static void estrella(Graphics2D g, double cx, double cy, double r, Color color) {
        Path2D p = new Path2D.Double();
        for (int i = 0; i < 10; i++) {
            double ang = -Math.PI / 2 + i * Math.PI / 5;
            double rr = (i % 2 == 0) ? r : r * 0.45;
            double px = cx + Math.cos(ang) * rr;
            double py = cy + Math.sin(ang) * rr;
            if (i == 0) p.moveTo(px, py);
            else p.lineTo(px, py);
        }
        p.closePath();
        g.setColor(color);
        g.fill(p);
    }

    public static void balon(Graphics2D g, Balon b) {
        double r = b.getRadio();
        double altura = Cancha.SUELO - (b.getY() + r);
        double esc = Math.max(0.3, 1 - altura / 320.0);
        g.setColor(new Color(0, 0, 0, (int) (95 * esc)));
        g.fill(new Ellipse2D.Double(b.getX() - r * 1.3 * esc, Cancha.SUELO - 2, r * 2.6 * esc, 8 * esc));

        AffineTransform antes = g.getTransform();
        g.translate(b.getX(), b.getY());
        double aplastar = b.getImpacto() * 0.22;
        if (b.enSuelo()) g.scale(1 + aplastar, 1 - aplastar);
        else g.scale(1 - aplastar * 0.4, 1 + aplastar * 0.4);
        g.rotate(b.getAngulo());

        Ellipse2D bola = new Ellipse2D.Double(-r, -r, 2 * r, 2 * r);
        g.setPaint(new RadialGradientPaint(new Point2D.Double(-r * 0.35, -r * 0.4), (float) (r * 1.7),
                new float[]{0f, 0.6f, 1f}, new Color[]{Color.WHITE, new Color(232, 234, 240), new Color(140, 148, 165)}));
        g.fill(bola);

        Shape clipAntes = g.getClip();
        g.clip(bola);
        g.setColor(new Color(30, 30, 40));
        Path2D pentagono = new Path2D.Double();
        for (int i = 0; i < 5; i++) {
            double ang = -Math.PI / 2 + i * 2 * Math.PI / 5;
            double px = Math.cos(ang) * r * 0.40;
            double py = Math.sin(ang) * r * 0.40;
            if (i == 0) pentagono.moveTo(px, py);
            else pentagono.lineTo(px, py);
        }
        pentagono.closePath();
        g.fill(pentagono);
        g.setStroke(new BasicStroke(1.1f));
        for (int i = 0; i < 5; i++) {
            double ang = -Math.PI / 2 + i * 2 * Math.PI / 5;
            g.draw(new Line2D.Double(Math.cos(ang) * r * 0.40, Math.sin(ang) * r * 0.40, Math.cos(ang) * r * 0.85, Math.sin(ang) * r * 0.85));
            double px = Math.cos(ang) * r * 1.02;
            double py = Math.sin(ang) * r * 1.02;
            g.fill(new Ellipse2D.Double(px - r * 0.27, py - r * 0.27, r * 0.54, r * 0.54));
        }
        g.setClip(clipAntes);
        g.setColor(new Color(55, 60, 75));
        g.setStroke(new BasicStroke(1.4f));
        g.draw(bola);
        g.setTransform(antes);
    }

    public static void tiroDePoder(Graphics2D g, Balon b, ArrayList<double[]> estela, int tick) {
        PoderEspecial poder = b.getTiro();
        if (poder == null || poder.generaSenuelos()) return;
        Color color = colorPoder(poder);
        for (int i = 0; i < estela.size(); i++) {
            double[] p = estela.get(i);
            double f = (i + 1.0) / estela.size();
            g.setColor(new Color(color.getRed(), color.getGreen(), color.getBlue(), (int) (130 * f)));
            double rr = b.getRadio() * (0.5 + 0.7 * f);
            g.fill(new Ellipse2D.Double(p[0] - rr, p[1] - rr, rr * 2, rr * 2));
        }
        double r = 34 + 3 * Math.sin(tick * 0.5);
        g.setPaint(new RadialGradientPaint(new Point2D.Double(b.getX(), b.getY()), (float) r, new float[]{0f, 1f},
                new Color[]{new Color(color.getRed(), color.getGreen(), color.getBlue(), 190), new Color(color.getRed(), color.getGreen(), color.getBlue(), 0)}));
        g.fill(new Ellipse2D.Double(b.getX() - r, b.getY() - r, 2 * r, 2 * r));

        if (poder.getNombre().equals("Rayo")) {
            Random azar = new Random(tick);
            g.setColor(new Color(255, 250, 150));
            g.setStroke(new BasicStroke(2f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
            for (int i = 0; i < 4; i++) {
                double ang = azar.nextDouble() * Math.PI * 2;
                double px = b.getX() + Math.cos(ang) * 14;
                double py = b.getY() + Math.sin(ang) * 14;
                for (int s = 0; s < 3; s++) {
                    double nx = px + Math.cos(ang) * 9 + (azar.nextDouble() - 0.5) * 10;
                    double ny = py + Math.sin(ang) * 9 + (azar.nextDouble() - 0.5) * 10;
                    g.draw(new Line2D.Double(px, py, nx, ny));
                    px = nx;
                    py = ny;
                }
            }
        }
        if (poder.getNombre().equals("Tornado")) {
            g.setStroke(new BasicStroke(2.4f));
            for (int i = 0; i < 4; i++) {
                double ancho = 18 + i * 9;
                double yy = b.getY() - 6 - i * 9;
                g.setColor(new Color(215, 225, 240, 190 - i * 35));
                double ang = tick * 0.6 + i;
                g.draw(new Arc2D.Double(b.getX() - ancho / 2 + Math.sin(ang) * 3, yy - 4, ancho, 9, ang * 40, 230, Arc2D.OPEN));
            }
        }
    }

    public static BufferedImage crearFondo(int ancho, int alto) {
        BufferedImage imagen = new BufferedImage(ancho, alto, BufferedImage.TYPE_INT_RGB);
        Graphics2D g = imagen.createGraphics();
        Estilo.calidad(g);
        g.scale(ancho / (double) Cancha.ANCHO, alto / (double) Cancha.ALTO);

        g.setPaint(new GradientPaint(0, 0, new Color(6, 10, 32), 0, 150, new Color(32, 62, 125)));
        g.fillRect(0, 0, Cancha.ANCHO, 200);

        for (int i = 0; i < 4; i++) {
            double fx = 90 + i * 207;
            g.setPaint(new RadialGradientPaint(new Point2D.Double(fx, 34), 70f, new float[]{0f, 1f},
                    new Color[]{new Color(255, 250, 220, 190), new Color(255, 250, 220, 0)}));
            g.fill(new Ellipse2D.Double(fx - 70, -36, 140, 140));
            g.setColor(new Color(255, 255, 240));
            g.fill(new Ellipse2D.Double(fx - 13, 26, 26, 14));
        }

        g.setPaint(new GradientPaint(0, 85, new Color(38, 44, 70), 0, 320, new Color(18, 22, 40)));
        g.fill(new Rectangle2D.Double(0, 110, Cancha.ANCHO, 212));

        String[] anuncios = {"DOPO", "ECI", "SOCCER", "JAVA", "POO", "DOPO", "GOL", "ECI"};
        Color[] coloresVallas = {new Color(30, 90, 200), new Color(200, 40, 50), new Color(30, 150, 90), new Color(235, 170, 20)};
        for (int i = 0; i < anuncios.length; i++) {
            double vx = i * 100;
            g.setPaint(new GradientPaint(0, 322, coloresVallas[i % 4].brighter(), 0, 350, coloresVallas[i % 4].darker()));
            g.fill(new Rectangle2D.Double(vx, 322, 100, 30));
            g.setColor(new Color(255, 255, 255, 90));
            g.draw(new Rectangle2D.Double(vx, 322, 100, 30));
            Estilo.textoCentrado(g, anuncios[i], vx + 50, 344, Estilo.fuente(Font.BOLD, 17), Color.WHITE);
        }

        for (int i = 0; i < 10; i++) {
            Color a = (i % 2 == 0) ? new Color(38, 148, 62) : new Color(48, 170, 74);
            g.setPaint(new GradientPaint(0, 352, a, 0, Cancha.ALTO, a.darker()));
            g.fill(new Rectangle2D.Double(i * 80, 352, 80, Cancha.ALTO - 352));
        }
        g.setColor(new Color(255, 255, 255, 190));
        g.setStroke(new BasicStroke(2.5f));
        g.draw(new Line2D.Double(Cancha.ANCHO / 2.0, 354, Cancha.ANCHO / 2.0, Cancha.ALTO));
        g.draw(new Ellipse2D.Double(Cancha.ANCHO / 2.0 - 80, 372, 160, 50));
        g.draw(new Rectangle2D.Double(-2, 366, 125, 62));
        g.draw(new Rectangle2D.Double(Cancha.ANCHO - 123, 366, 127, 62));
        g.draw(new Line2D.Double(0, 354, Cancha.ANCHO, 354));

        g.setPaint(new RadialGradientPaint(new Point2D.Double(Cancha.ANCHO / 2.0, Cancha.ALTO / 2.0), 520f,
                new float[]{0.55f, 1f}, new Color[]{new Color(0, 0, 0, 0), new Color(0, 0, 0, 120)}));
        g.fillRect(0, 0, Cancha.ANCHO, Cancha.ALTO);
        g.dispose();
        return imagen;
    }

    public static void arcoAtras(Graphics2D g, boolean izquierdo) {
        double x0 = izquierdo ? 0 : Cancha.ANCHO - Cancha.ARCO_ANCHO;
        double top = Cancha.TRAVESANO_Y;
        g.setColor(new Color(0, 0, 0, 85));
        g.fill(new Rectangle2D.Double(x0, top, Cancha.ARCO_ANCHO, Cancha.ARCO_ALTO));
        g.setColor(new Color(235, 238, 245));
        g.setStroke(new BasicStroke(5f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        double frente = izquierdo ? Cancha.ARCO_ANCHO : Cancha.ANCHO - Cancha.ARCO_ANCHO;
        g.draw(new Line2D.Double(frente, top, frente, Cancha.SUELO));
        g.fill(new RoundRectangle2D.Double(x0, top, Cancha.ARCO_ANCHO, Cancha.TRAVESANO_GROSOR, 6, 6));
    }

    public static void arcoRed(Graphics2D g, boolean izquierdo, int sacudida) {
        double x0 = izquierdo ? 0 : Cancha.ANCHO - Cancha.ARCO_ANCHO;
        double top = Cancha.TRAVESANO_Y + Cancha.TRAVESANO_GROSOR;
        g.setColor(new Color(255, 255, 255, 105));
        g.setStroke(new BasicStroke(1f));
        double onda = sacudida * 0.15 * Math.sin(sacudida);
        for (double i = 0; i <= Cancha.ARCO_ANCHO; i += 9) {
            g.draw(new Line2D.Double(x0 + i + onda, top, x0 + i, Cancha.SUELO));
        }
        for (double yy = top; yy <= Cancha.SUELO; yy += 9) {
            g.draw(new Line2D.Double(x0, yy, x0 + Cancha.ARCO_ANCHO + onda, yy));
        }
    }

    public static void marcador(Graphics2D g, Partido p, int tick) {
        double x = 310;
        g.setColor(new Color(8, 12, 28, 215));
        g.fill(new RoundRectangle2D.Double(x, 8, 180, 60, 16, 16));
        g.setColor(new Color(255, 255, 255, 60));
        g.setStroke(new BasicStroke(1.5f));
        g.draw(new RoundRectangle2D.Double(x, 8, 180, 60, 16, 16));
        String marcador = p.getJugador1().getGoles() + "  -  " + p.getJugador2().getGoles();
        Estilo.textoCentrado(g, marcador, x + 90, 44, Estilo.fuente(Font.BOLD, 32), Color.WHITE);

        String info;
        Color color = Estilo.ACENTO;
        if (p.isMuerteSubita()) {
            info = "MUERTE SÚBITA";
            color = (tick / 15 % 2 == 0) ? Estilo.ROJO : Color.WHITE;
        } else if (p.isPorGoles()) {
            info = "A " + p.getGolesParaGanar() + " GOLES";
        } else {
            int s = p.getSegundosRestantes();
            info = String.format("%02d:%02d", s / 60, s % 60);
            if (s <= 10) color = Estilo.ROJO;
        }
        Estilo.textoCentrado(g, info, x + 90, 62, Estilo.fuente(Font.BOLD, 14), color);
    }

    public static void panelJugador(Graphics2D g, Jugador j, boolean izquierdo, Color etiqueta, int tick) {
        double x = izquierdo ? 10 : Cancha.ANCHO - 300;
        double w = 290;
        g.setColor(new Color(8, 12, 28, 215));
        g.fill(new RoundRectangle2D.Double(x, 8, w, 60, 16, 16));
        g.setColor(etiqueta);
        g.setStroke(new BasicStroke(2f));
        g.draw(new RoundRectangle2D.Double(x, 8, w, 60, 16, 16));

        double ax = izquierdo ? x + 32 : x + w - 32;
        Shape clipAntes = g.getClip();
        g.setColor(new Color(255, 255, 255, 30));
        g.fill(new Ellipse2D.Double(ax - 23, 15, 46, 46));
        g.clip(new Ellipse2D.Double(ax - 23, 15, 46, 46));
        cabeza(g, ax, 40, 22, j.getPais(), izquierdo ? 1 : -1, j.estaAturdido());
        g.setClip(clipAntes);
        g.setColor(etiqueta);
        g.setStroke(new BasicStroke(2f));
        g.draw(new Ellipse2D.Double(ax - 23, 15, 46, 46));

        double bx = izquierdo ? x + 64 : x + 10;
        double bw = 216;
        g.setFont(Estilo.fuente(Font.BOLD, 12));
        String texto = j.getNombre() + "  ·  " + j.getPais();
        FontMetrics fm = g.getFontMetrics();
        float tx = izquierdo ? (float) bx : (float) (bx + bw - fm.stringWidth(texto));
        g.setColor(Color.WHITE);
        g.drawString(texto, tx, 24);

        double ratio = (double) j.getVida() / j.getVidaMax();
        g.setColor(new Color(255, 255, 255, 35));
        g.fill(new RoundRectangle2D.Double(bx, 29, bw, 15, 8, 8));
        Color colorVida = ratio > 0.5 ? Estilo.mezclar(new Color(241, 196, 15), Estilo.VERDE, (ratio - 0.5) * 2)
                : Estilo.mezclar(Estilo.ROJO, new Color(241, 196, 15), ratio * 2);
        double llenoV = bw * ratio;
        double inicioV = izquierdo ? bx : bx + bw - llenoV;
        if (llenoV > 0) {
            g.setPaint(new GradientPaint(0, 29, colorVida.brighter(), 0, 44, colorVida.darker()));
            g.fill(new RoundRectangle2D.Double(inicioV, 29, llenoV, 15, 8, 8));
        }
        Estilo.textoCentrado(g, j.getVida() + " / " + j.getVidaMax(), bx + bw / 2, 41, Estilo.fuente(Font.BOLD, 10), Color.WHITE);

        double r2 = j.getBarraPoder() / 100.0;
        g.setColor(new Color(255, 255, 255, 35));
        g.fill(new RoundRectangle2D.Double(bx, 48, bw, 9, 6, 6));
        boolean listo = j.getBarraPoder() >= 100;
        Color colorPoder = j.isPoderActivo() ? Dibujante.colorPoder(j.getPersonaje().getPoder()) : new Color(255, 190, 0);
        if (listo && !j.isPoderActivo() && tick / 8 % 2 == 0) colorPoder = new Color(255, 245, 150);
        double llenoP = bw * r2;
        double inicioP = izquierdo ? bx : bx + bw - llenoP;
        if (llenoP > 0) {
            g.setColor(colorPoder);
            g.fill(new RoundRectangle2D.Double(inicioP, 48, llenoP, 9, 6, 6));
        }
        String estado = j.isPoderActivo() ? "AURA ACTIVA: " + j.getPersonaje().getPoder().getNombre().toUpperCase()
                : (listo ? "¡PODER LISTO!" : "PODER");
        Estilo.textoCentrado(g, estado, bx + bw / 2, 55.5, Estilo.fuente(Font.BOLD, 8), Color.WHITE);

        String alterado = null;
        Color colorAlt = Color.WHITE;
        if (j.estaAturdido()) {
            alterado = String.format("ATURDIDO %.1f s", j.getTicksAturdido() / 60.0);
            colorAlt = new Color(255, 220, 40);
        } else if (j.getEfecto() != Efecto.NINGUNO) {
            alterado = String.format("%s %.1f s", j.getEfecto().getNombre().toUpperCase(), j.getTicksEfecto() / 60.0);
            colorAlt = Estilo.mezclar(Color.WHITE, Estilo.ACENTO, 0.6);
        }
        if (alterado != null) {
            g.setFont(Estilo.fuente(Font.BOLD, 11));
            FontMetrics fm3 = g.getFontMetrics();
            double aw = fm3.stringWidth(alterado) + 16;
            double axx = izquierdo ? x : x + w - aw;
            g.setColor(new Color(8, 12, 28, 210));
            g.fill(new RoundRectangle2D.Double(axx, 74, aw, 18, 10, 10));
            g.setColor(colorAlt);
            g.drawString(alterado, (float) (axx + 8), 87);
        }
    }
}
