package presentacion;

import dominio.*;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.awt.geom.AffineTransform;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.Random;

public class PanelCancha extends JPanel {
    private static final double PASO = 1.0 / 60;

    private static class Particula {
        double x, y, vx, vy, tamano;
        int vida, vidaMax;
        Color color;
        String texto;
    }

    private final Partido partido;
    private final Accion accion1 = new Accion();
    private final Accion accion2 = new Accion();
    private final Runnable alTerminar;
    private final Timer reloj;
    private final ArrayList<Particula> particulas = new ArrayList<Particula>();
    private final ArrayList<double[]> estela = new ArrayList<double[]>();
    private final Random azar = new Random();
    private BufferedImage fondo;

    private boolean pausa;
    private boolean terminoAvisado;
    private int cuenta;
    private int tickVisual;
    private int sacudida;
    private int sacudidaRed;
    private boolean redIzquierda;
    private long ultimo = System.nanoTime();
    private double acumulado;

    private int golesPrev1, golesPrev2, vidaPrev1, vidaPrev2;
    private int destello1, destello2;

    public PanelCancha(Partido partido, boolean conCuenta, Runnable alTerminar) {
        this.partido = partido;
        this.alTerminar = alTerminar;
        this.cuenta = conCuenta ? 180 : 0;
        this.pausa = !conCuenta;
        Cancha c = partido.getCancha();
        setPreferredSize(new Dimension(c.getAnchoPantalla(), c.getAltoPantalla()));
        setFocusable(true);
        golesPrev1 = partido.getJugador1().getGoles();
        golesPrev2 = partido.getJugador2().getGoles();
        vidaPrev1 = partido.getJugador1().getVida();
        vidaPrev2 = partido.getJugador2().getVida();
        configurarTeclas();
        reloj = new Timer(15, e -> bucle());
        reloj.start();
    }

    private void configurarTeclas() {
        tecla("A", KeyEvent.VK_A, v -> accion1.setIzquierda(v));
        tecla("D", KeyEvent.VK_D, v -> accion1.setDerecha(v));
        tecla("W", KeyEvent.VK_W, v -> accion1.setSaltar(v));
        tecla("F", KeyEvent.VK_F, v -> accion1.setPatear(v));
        tecla("G", KeyEvent.VK_G, v -> accion1.setPoder(v));
        tecla("LEFT", KeyEvent.VK_LEFT, v -> accion2.setIzquierda(v));
        tecla("RIGHT", KeyEvent.VK_RIGHT, v -> accion2.setDerecha(v));
        tecla("UP", KeyEvent.VK_UP, v -> accion2.setSaltar(v));
        tecla("L", KeyEvent.VK_L, v -> accion2.setPatear(v));
        tecla("K", KeyEvent.VK_K, v -> accion2.setPoder(v));
        tecla("P", KeyEvent.VK_P, v -> { if (v) alternarPausa(); });
        tecla("ESC", KeyEvent.VK_ESCAPE, v -> { if (v) alternarPausa(); });
    }

    private void tecla(String nombre, int codigo, java.util.function.Consumer<Boolean> efecto) {
        getInputMap(WHEN_IN_FOCUSED_WINDOW).put(KeyStroke.getKeyStroke(codigo, 0, false), nombre + "_P");
        getActionMap().put(nombre + "_P", new AbstractAction() {
            public void actionPerformed(ActionEvent e) { efecto.accept(true); }
        });
        getInputMap(WHEN_IN_FOCUSED_WINDOW).put(KeyStroke.getKeyStroke(codigo, 0, true), nombre + "_S");
        getActionMap().put(nombre + "_S", new AbstractAction() {
            public void actionPerformed(ActionEvent e) { efecto.accept(false); }
        });
    }

    private void bucle() {
        long ahora = System.nanoTime();
        double dt = (ahora - ultimo) / 1e9;
        ultimo = ahora;
        if (dt > 0.1) dt = 0.1;
        tickVisual++;
        if (!pausa) {
            acumulado += dt;
            while (acumulado >= PASO) {
                unTick();
                acumulado -= PASO;
            }
        }
        repaint();
    }

    private void unTick() {
        if (cuenta > 0) { cuenta--; return; }
        partido.avanzar(accion1, accion2);
        detectarEventos();
        actualizarParticulas();
        if (sacudida > 0) sacudida--;
        if (sacudidaRed > 0) sacudidaRed--;
        if (destello1 > 0) destello1--;
        if (destello2 > 0) destello2--;

        Balon b = partido.getBalon();
        if (b.getTiro() != null) {
            estela.add(new double[]{b.getX(), b.getY()});
            if (estela.size() > 12) estela.remove(0);
        } else {
            estela.clear();
        }
        if (partido.mostrarResultado() && !terminoAvisado) {
            terminoAvisado = true;
            terminarVisual();
        }
    }

    private void terminarVisual() {
        reloj.stop();
        SwingUtilities.invokeLater(alTerminar);
    }

    private void detectarEventos() {
        Jugador j1 = partido.getJugador1();
        Jugador j2 = partido.getJugador2();
        if (j1.getGoles() > golesPrev1) explosionGol(true);
        if (j2.getGoles() > golesPrev2) explosionGol(false);
        golesPrev1 = j1.getGoles();
        golesPrev2 = j2.getGoles();

        if (j1.getVida() < vidaPrev1) { dano(j1, vidaPrev1 - j1.getVida()); destello1 = 8; }
        if (j2.getVida() < vidaPrev2) { dano(j2, vidaPrev2 - j2.getVida()); destello2 = 8; }
        vidaPrev1 = j1.getVida();
        vidaPrev2 = j2.getVida();
    }

    private void explosionGol(boolean anotoJugador1) {
        sacudida = 25;
        sacudidaRed = 40;
        redIzquierda = !anotoJugador1;
        double x = anotoJugador1 ? Cancha.ANCHO - 40 : 40;
        Color[] colores = {Estilo.ACENTO, Estilo.ROJO, Estilo.AZUL, Estilo.VERDE, Color.WHITE};
        for (int i = 0; i < 90; i++) {
            Particula p = new Particula();
            p.x = x;
            p.y = Cancha.SUELO - 60;
            double ang = -Math.PI / 2 + (azar.nextDouble() - 0.5) * 2.2 + (anotoJugador1 ? -0.5 : 0.5);
            double v = 3 + azar.nextDouble() * 8;
            p.vx = Math.cos(ang) * v;
            p.vy = Math.sin(ang) * v;
            p.tamano = 3 + azar.nextDouble() * 3;
            p.vidaMax = p.vida = 70 + azar.nextInt(50);
            p.color = colores[azar.nextInt(colores.length)];
            particulas.add(p);
        }
    }

    private void dano(Jugador j, int cantidad) {
        sacudida = Math.max(sacudida, 10);
        Particula texto = new Particula();
        texto.x = j.getX();
        texto.y = j.getY() - 120;
        texto.vy = -1.4;
        texto.vidaMax = texto.vida = 55;
        texto.texto = "-" + cantidad;
        texto.color = cantidad >= 20 ? Estilo.ROJO : Estilo.ACENTO;
        texto.tamano = cantidad >= 20 ? 26 : 18;
        particulas.add(texto);
        for (int i = 0; i < 12; i++) {
            Particula p = new Particula();
            p.x = j.getX();
            p.y = j.getY() - 50;
            double ang = azar.nextDouble() * Math.PI * 2;
            p.vx = Math.cos(ang) * 4;
            p.vy = Math.sin(ang) * 4 - 1;
            p.tamano = 3;
            p.vidaMax = p.vida = 20 + azar.nextInt(10);
            p.color = new Color(255, 230, 120);
            particulas.add(p);
        }
    }

    private void actualizarParticulas() {
        for (int i = particulas.size() - 1; i >= 0; i--) {
            Particula p = particulas.get(i);
            p.x += p.vx;
            p.y += p.vy;
            if (p.texto == null) p.vy += 0.18;
            p.vida--;
            if (p.vida <= 0) particulas.remove(i);
        }
    }

    public void alternarPausa() {
        if (cuenta > 0 || partido.estaTerminado()) return;
        pausa = !pausa;
        ultimo = System.nanoTime();
        repaint();
    }

    public void pausar() { if (cuenta == 0) pausa = true; }
    public boolean estaEnPausa() { return pausa; }
    public void detener() { reloj.stop(); }
    public Partido getPartido() { return partido; }

    public void terminarAhora() {
        partido.terminarPartido();
        if (!terminoAvisado) {
            terminoAvisado = true;
            terminarVisual();
        }
    }

    protected void paintComponent(Graphics g0) {
        super.paintComponent(g0);
        Graphics2D g = (Graphics2D) g0.create();
        Estilo.calidad(g);
        int w = getWidth();
        int h = getHeight();
        if (fondo == null || fondo.getWidth() != w || fondo.getHeight() != h) {
            fondo = Dibujante.crearFondo(w, h);
        }
        g.drawImage(fondo, 0, 0, null);
        g.scale(w / (double) Cancha.ANCHO, h / (double) Cancha.ALTO);

        if (sacudida > 0) {
            g.translate((azar.nextDouble() - 0.5) * sacudida * 0.4, (azar.nextDouble() - 0.5) * sacudida * 0.4);
        }

        Dibujante.arcoAtras(g, true);
        Dibujante.arcoAtras(g, false);

        Jugador j1 = partido.getJugador1();
        Jugador j2 = partido.getJugador2();
        Dibujante.jugador(g, j1, Estilo.AZUL, tickVisual, destello1);
        Dibujante.jugador(g, j2, Estilo.ROJO, tickVisual, destello2);

        for (Balon b : partido.getTodosLosBalones()) Dibujante.balon(g, b);
        Dibujante.tiroDePoder(g, partido.getBalon(), estela, tickVisual);

        Dibujante.arcoRed(g, true, redIzquierda ? sacudidaRed : 0);
        Dibujante.arcoRed(g, false, redIzquierda ? 0 : sacudidaRed);

        dibujarParticulas(g);
        Dibujante.panelJugador(g, j1, true, Estilo.AZUL, tickVisual);
        Dibujante.panelJugador(g, j2, false, Estilo.ROJO, tickVisual);
        Dibujante.marcador(g, partido, tickVisual);
        dibujarMensajes(g);
        g.dispose();
    }

    private void dibujarParticulas(Graphics2D g) {
        for (Particula p : particulas) {
            float alfa = Math.max(0f, Math.min(1f, p.vida / (float) p.vidaMax));
            Color c = new Color(p.color.getRed(), p.color.getGreen(), p.color.getBlue(), (int) (255 * alfa));
            g.setColor(c);
            if (p.texto != null) {
                Estilo.textoCentrado(g, p.texto, p.x, p.y, Estilo.fuente(Font.BOLD, (int) p.tamano), c);
            } else {
                g.fill(new Rectangle2D.Double(p.x, p.y, p.tamano, p.tamano * 0.6));
            }
        }
    }

    private void dibujarMensajes(Graphics2D g) {
        double cx = Cancha.ANCHO / 2.0;
        if (cuenta > 0) {
            int segundos = cuenta / 60 + 1;
            double pulso = 1 + 0.35 * ((cuenta % 60) / 60.0);
            AffineTransform t = g.getTransform();
            g.translate(cx, 210);
            g.scale(pulso, pulso);
            Estilo.textoCentrado(g, String.valueOf(segundos), 0, 30, Estilo.fuente(Font.BOLD, 90), Estilo.ACENTO);
            g.setTransform(t);
            Estilo.textoCentrado(g, "¡Prepárense!", cx, 280, Estilo.fuente(Font.BOLD, 22), Color.WHITE);
        }
        if (partido.getTicksMensaje() > 0 && cuenta == 0) {
            int t = partido.getTicksMensaje();
            double escala = 1 + 0.35 * Math.max(0, (t - (Partido.TICKS_CELEBRACION - 14)) / 14.0);
            AffineTransform tr = g.getTransform();
            g.translate(cx, 190);
            g.scale(escala, escala);
            Estilo.textoCentrado(g, partido.getMensaje(), 0, 0, Estilo.fuente(Font.BOLD, 40), Estilo.ACENTO);
            g.setTransform(tr);
        }
        if (pausa && cuenta == 0 && !partido.estaTerminado()) {
            g.setColor(new Color(0, 0, 0, 150));
            g.fillRect(0, 0, Cancha.ANCHO, Cancha.ALTO);
            Estilo.textoCentrado(g, "PAUSA", cx, 215, Estilo.fuente(Font.BOLD, 56), Color.WHITE);
            Estilo.textoCentrado(g, "Pulsa P o Esc para continuar", cx, 250, Estilo.fuente(Font.PLAIN, 18), Estilo.TEXTO_SUAVE);
        }
    }
}
