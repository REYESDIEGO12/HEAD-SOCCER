package presentacion;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class BotonJuego extends JButton {
    private final Color color;
    private boolean encima;

    public BotonJuego(String texto, Color color) {
        super(texto);
        this.color = color;
        setContentAreaFilled(false);
        setBorderPainted(false);
        setFocusPainted(false);
        setForeground(Color.WHITE);
        setFont(Estilo.fuente(Font.BOLD, 16));
        setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        setPreferredSize(new Dimension(260, 46));
        addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) { encima = true; repaint(); }
            public void mouseExited(MouseEvent e) { encima = false; repaint(); }
        });
    }

    protected void paintComponent(Graphics g0) {
        Graphics2D g = (Graphics2D) g0.create();
        Estilo.calidad(g);
        Color base = isEnabled() ? color : Color.GRAY;
        if (encima && isEnabled()) base = base.brighter();
        int w = getWidth();
        int h = getHeight();
        g.setColor(new Color(0, 0, 0, 70));
        g.fillRoundRect(2, 4, w - 4, h - 4, 18, 18);
        g.setPaint(new GradientPaint(0, 0, base.brighter(), 0, h, base.darker()));
        g.fillRoundRect(0, 0, w - 4, h - 4, 18, 18);
        g.setColor(new Color(255, 255, 255, 70));
        g.drawRoundRect(0, 0, w - 5, h - 5, 18, 18);
        g.dispose();
        super.paintComponent(g0);
    }
}
