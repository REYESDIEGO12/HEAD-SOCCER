package presentacion;

import java.awt.*;

public class Estilo {
    public static final Color FONDO_OSCURO = new Color(9, 16, 36);
    public static final Color FONDO_CLARO = new Color(28, 62, 120);
    public static final Color ACENTO = new Color(255, 196, 0);
    public static final Color VERDE = new Color(46, 204, 113);
    public static final Color ROJO = new Color(231, 76, 60);
    public static final Color AZUL = new Color(52, 130, 255);
    public static final Color TEXTO_SUAVE = new Color(170, 188, 215);
    public static final Color TARJETA = new Color(244, 247, 252);

    public static Font fuente(int estilo, int tamano) {
        return new Font("SansSerif", estilo, tamano);
    }

    public static void calidad(Graphics2D g) {
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        g.setRenderingHint(RenderingHints.KEY_STROKE_CONTROL, RenderingHints.VALUE_STROKE_PURE);
        g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
    }

    public static void fondoDegradado(Graphics2D g, int ancho, int alto) {
        g.setPaint(new GradientPaint(0, 0, FONDO_OSCURO, 0, alto, FONDO_CLARO));
        g.fillRect(0, 0, ancho, alto);
    }

    public static void textoCentrado(Graphics2D g, String texto, double centroX, double y, Font fuente, Color color) {
        g.setFont(fuente);
        FontMetrics fm = g.getFontMetrics();
        float x = (float) (centroX - fm.stringWidth(texto) / 2.0);
        g.setColor(new Color(0, 0, 0, 120));
        g.drawString(texto, x + 2, (float) y + 2);
        g.setColor(color);
        g.drawString(texto, x, (float) y);
    }

    public static Color mezclar(Color a, Color b, double t) {
        t = Math.max(0, Math.min(1, t));
        return new Color((int) (a.getRed() + (b.getRed() - a.getRed()) * t),
                (int) (a.getGreen() + (b.getGreen() - a.getGreen()) * t),
                (int) (a.getBlue() + (b.getBlue() - a.getBlue()) * t));
    }
}
