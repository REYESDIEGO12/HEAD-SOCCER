package presentacion;

import dominio.*;
import persistencia.ArchivoProgreso;

import javax.swing.*;
import java.awt.*;

public class PanelMejoras extends JPanel {
    private static final String[] ESTADISTICAS = {"speed", "kick", "jump", "survival"};
    private static final String[] TITULOS = {"Speed (velocidad)", "Kick (daño de patada)", "Jump (salto)", "Survival (vida)"};

    private final ControladorJuego controlador;
    private final ArchivoProgreso progreso;
    private final JComboBox<String> nombres = new JComboBox<String>();
    private final JLabel puntos = new JLabel();
    private final JLabel[] valores = new JLabel[4];
    private final JLabel[] detalles = new JLabel[4];
    private final BotonJuego[] botones = new BotonJuego[4];
    private final JPanel barras = new JPanel(new GridBagLayout());
    private Jugador jugador;

    public PanelMejoras(ControladorJuego controlador, ArchivoProgreso progreso) {
        this.controlador = controlador;
        this.progreso = progreso;
        setLayout(new GridBagLayout());
        setPreferredSize(new Dimension(900, 600));

        JPanel tarjeta = new JPanel(new GridBagLayout());
        tarjeta.setBackground(Estilo.TARJETA);
        tarjeta.setBorder(BorderFactory.createEmptyBorder(20, 30, 20, 30));
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(6, 6, 6, 6);
        c.fill = GridBagConstraints.HORIZONTAL;

        JLabel titulo = new JLabel("MEJORAR ESTADÍSTICAS");
        titulo.setFont(Estilo.fuente(Font.BOLD, 22));
        titulo.setForeground(Estilo.FONDO_OSCURO);
        c.gridx = 0; c.gridy = 0; c.gridwidth = 4;
        tarjeta.add(titulo, c);

        nombres.setEditable(true);
        for (String n : progreso.nombresGuardados()) nombres.addItem(n);
        JButton cargar = new JButton("Cargar jugador");
        c.gridwidth = 1; c.gridy = 1; c.gridx = 0;
        tarjeta.add(etiqueta("Jugador"), c);
        c.gridx = 1; c.gridwidth = 2; tarjeta.add(nombres, c);
        c.gridx = 3; c.gridwidth = 1; tarjeta.add(cargar, c);
        cargar.addActionListener(e -> cargarJugador());

        puntos.setFont(Estilo.fuente(Font.BOLD, 20));
        puntos.setForeground(new Color(200, 140, 0));
        c.gridy = 2; c.gridx = 0; c.gridwidth = 4;
        tarjeta.add(puntos, c);

        c.gridwidth = 1;
        for (int i = 0; i < 4; i++) {
            final String estadistica = ESTADISTICAS[i];
            c.gridy = 3 + i;
            c.gridx = 0; tarjeta.add(etiqueta(TITULOS[i]), c);
            valores[i] = new JLabel();
            valores[i].setFont(Estilo.fuente(Font.BOLD, 16));
            c.gridx = 1; tarjeta.add(valores[i], c);
            detalles[i] = new JLabel();
            detalles[i].setForeground(new Color(90, 100, 125));
            c.gridx = 2; tarjeta.add(detalles[i], c);
            botones[i] = new BotonJuego("MEJORAR", Estilo.VERDE);
            botones[i].setPreferredSize(new Dimension(150, 38));
            botones[i].addActionListener(e -> mejorar(estadistica));
            c.gridx = 3; tarjeta.add(botones[i], c);
        }

        JLabel regla = new JLabel("<html>Cada punto de mejora cuesta el doble del anterior (500, 1000, 2000...).<br>"
                + "Ganas 100 puntos si ganas un partido y 25 si pierdes. Las estadísticas van de 1 a 10.</html>");
        regla.setForeground(new Color(90, 100, 125));
        c.gridy = 7; c.gridx = 0; c.gridwidth = 4;
        tarjeta.add(regla, c);

        BotonJuego volver = new BotonJuego("VOLVER", new Color(120, 130, 150));
        volver.addActionListener(e -> controlador.mostrarMenu());
        c.gridy = 8; c.fill = GridBagConstraints.NONE;
        tarjeta.add(volver, c);

        add(tarjeta, new GridBagConstraints());

        if (nombres.getItemCount() > 0) cargarJugador();
        else refrescar();
    }

    private JLabel etiqueta(String texto) {
        JLabel l = new JLabel(texto);
        l.setFont(Estilo.fuente(Font.BOLD, 14));
        l.setForeground(new Color(40, 50, 75));
        return l;
    }

    private void cargarJugador() {
        try {
            String nombre = ((String) nombres.getEditor().getItem()).trim();
            if (nombre.isEmpty()) throw new JuegoException("Escribe el nombre del jugador que quieres mejorar.");
            jugador = new Jugador(nombre, Personaje.catalogo().get(0));
            progreso.cargarEn(jugador);
            refrescar();
        } catch (JuegoException e) {
            controlador.mostrarError(e);
        }
    }

    private void mejorar(String estadistica) {
        if (jugador == null) return;
        try {
            jugador.mejorarEstadistica(estadistica);
            progreso.guardarDe(jugador);
            refrescar();
        } catch (JuegoException e) {
            controlador.mostrarError(e);
        }
    }

    private void refrescar() {
        if (jugador == null) {
            puntos.setText("Escribe un nombre y pulsa \"Cargar jugador\"");
            for (BotonJuego b : botones) b.setEnabled(false);
            return;
        }
        puntos.setText(jugador.getNombre() + "  ·  " + jugador.getPuntos() + " puntos");
        int[] niveles = {jugador.getSpeed(), jugador.getKick(), jugador.getJump(), jugador.getSurvival()};
        String[] detalle = {
            String.format("%.1f px/tick", jugador.getVelocidadMovimiento()),
            "patada " + jugador.calcularDanoPatada() + " de daño",
            String.format("%.1f de impulso", jugador.getVelocidadSalto()),
            "vida " + jugador.getVidaMax()
        };
        for (int i = 0; i < 4; i++) {
            valores[i].setText(niveles[i] + " / " + Jugador.MAX_ESTADISTICA);
            detalles[i].setText(detalle[i]);
            try {
                int costo = jugador.getCostoMejora(ESTADISTICAS[i]);
                botones[i].setText("MEJORAR (" + costo + ")");
                botones[i].setEnabled(jugador.getPuntos() >= costo);
            } catch (JuegoException e) {
                botones[i].setText("MÁXIMO");
                botones[i].setEnabled(false);
            }
        }
    }

    protected void paintComponent(Graphics g0) {
        Graphics2D g = (Graphics2D) g0.create();
        Estilo.fondoDegradado(g, getWidth(), getHeight());
        g.dispose();
    }
}
