package presentacion;

import dominio.*;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

public class PanelConfiguracion extends JPanel {
    private static final String[] RESOLUCIONES = {"800x450", "1000x560", "1200x675"};

    private static class VistaPersonaje extends JPanel {
        private String pais = "Corea del Sur";
        private final boolean derecha;

        VistaPersonaje(boolean derecha) {
            this.derecha = derecha;
            setOpaque(false);
            setPreferredSize(new Dimension(90, 90));
        }

        void setPais(String pais) { this.pais = pais; repaint(); }

        protected void paintComponent(Graphics g0) {
            Graphics2D g = (Graphics2D) g0.create();
            Estilo.calidad(g);
            g.setColor(new Color(0, 0, 0, 25));
            g.fillOval(8, 8, 74, 74);
            Dibujante.cabeza(g, 45, 45, 32, pais, derecha ? -1 : 1, false);
            g.dispose();
        }
    }

    private final ControladorJuego controlador;
    private final JRadioButton jugadorVsJugador = new JRadioButton("Jugador vs jugador", true);
    private final JRadioButton jugadorVsMaquina = new JRadioButton("Jugador vs máquina");
    private final JTextField nombre1 = new JTextField("Jugador 1");
    private final JTextField nombre2 = new JTextField("Jugador 2");
    private final JComboBox<String> perfil = new JComboBox<String>(Maquina.perfiles());
    private final JComboBox<String> personaje1 = new JComboBox<String>();
    private final JComboBox<String> personaje2 = new JComboBox<String>();
    private final JComboBox<String> resolucion = new JComboBox<String>(RESOLUCIONES);
    private final JComboBox<String> tipo = new JComboBox<String>(new String[]{"Por goles", "Por tiempo"});
    private final JSpinner objetivo = new JSpinner(new SpinnerNumberModel(3, 1, 30, 1));
    private final JLabel etiquetaObjetivo = new JLabel("Goles para ganar:");
    private final JLabel etiquetaNombre2 = new JLabel("Nombre del jugador 2");
    private final JLabel etiquetaPerfil = new JLabel("Perfil de la máquina");
    private final JLabel descripcion1 = new JLabel(" ");
    private final JLabel descripcion2 = new JLabel(" ");
    private final VistaPersonaje vista1 = new VistaPersonaje(false);
    private final VistaPersonaje vista2 = new VistaPersonaje(true);

    public PanelConfiguracion(ControladorJuego controlador) {
        this.controlador = controlador;
        setLayout(new GridBagLayout());
        setPreferredSize(new Dimension(900, 600));

        for (Personaje p : Personaje.catalogo()) {
            personaje1.addItem(p.getPais());
            personaje2.addItem(p.getPais());
        }
        personaje2.setSelectedIndex(1);

        JPanel tarjeta = new JPanel(new GridBagLayout());
        tarjeta.setBackground(Estilo.TARJETA);
        tarjeta.setBorder(BorderFactory.createEmptyBorder(18, 26, 18, 26));
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(5, 6, 5, 6);
        c.fill = GridBagConstraints.HORIZONTAL;

        JLabel titulo = new JLabel("CONFIGURACIÓN DEL PARTIDO");
        titulo.setFont(Estilo.fuente(Font.BOLD, 22));
        titulo.setForeground(Estilo.FONDO_OSCURO);
        c.gridx = 0; c.gridy = 0; c.gridwidth = 4;
        tarjeta.add(titulo, c);

        ButtonGroup grupo = new ButtonGroup();
        grupo.add(jugadorVsJugador);
        grupo.add(jugadorVsMaquina);
        JPanel modalidad = new JPanel(new FlowLayout(FlowLayout.LEFT, 14, 0));
        modalidad.setOpaque(false);
        modalidad.add(jugadorVsJugador);
        modalidad.add(jugadorVsMaquina);
        jugadorVsJugador.setOpaque(false);
        jugadorVsMaquina.setOpaque(false);
        c.gridy = 1; c.gridx = 0; c.gridwidth = 1;
        tarjeta.add(etiqueta("Modalidad"), c);
        c.gridx = 1; c.gridwidth = 3;
        tarjeta.add(modalidad, c);

        c.gridwidth = 1;
        c.gridy = 2; c.gridx = 0; tarjeta.add(etiqueta("Nombre del jugador 1"), c);
        c.gridx = 1; tarjeta.add(nombre1, c);
        c.gridx = 2; tarjeta.add(etiqueta("Personaje"), c);
        c.gridx = 3; tarjeta.add(personaje1, c);

        c.gridy = 3; c.gridx = 0; tarjeta.add(new JLabel(" "), c);
        c.gridx = 1; c.gridwidth = 1; tarjeta.add(vista1, c);
        c.gridx = 2; c.gridwidth = 2; tarjeta.add(descripcion1, c);

        c.gridwidth = 1;
        c.gridy = 4; c.gridx = 0; tarjeta.add(etiquetaNombre2, c);
        c.gridx = 1; tarjeta.add(nombre2, c);
        c.gridx = 2; tarjeta.add(etiqueta("Personaje"), c);
        c.gridx = 3; tarjeta.add(personaje2, c);

        c.gridy = 5; c.gridx = 0; tarjeta.add(etiquetaPerfil, c);
        c.gridx = 1; tarjeta.add(perfil, c);
        c.gridx = 2; c.gridwidth = 2; tarjeta.add(descripcion2, c);
        c.gridwidth = 1;

        c.gridy = 6; c.gridx = 1; tarjeta.add(vista2, c);

        c.gridy = 7; c.gridx = 0; tarjeta.add(etiqueta("Resolución de la cancha"), c);
        c.gridx = 1; tarjeta.add(resolucion, c);
        c.gridx = 2; tarjeta.add(etiqueta("Tipo de partido"), c);
        c.gridx = 3; tarjeta.add(tipo, c);

        c.gridy = 8; c.gridx = 2; tarjeta.add(etiquetaObjetivo, c);
        c.gridx = 3; tarjeta.add(objetivo, c);

        JPanel botones = new JPanel(new FlowLayout(FlowLayout.CENTER, 16, 0));
        botones.setOpaque(false);
        BotonJuego empezar = new BotonJuego("¡EMPEZAR!", Estilo.VERDE);
        BotonJuego volver = new BotonJuego("VOLVER", new Color(120, 130, 150));
        empezar.addActionListener(e -> empezar());
        volver.addActionListener(e -> controlador.mostrarMenu());
        botones.add(volver);
        botones.add(empezar);
        c.gridy = 9; c.gridx = 0; c.gridwidth = 4;
        c.insets = new Insets(16, 6, 0, 6);
        tarjeta.add(botones, c);

        GridBagConstraints centro = new GridBagConstraints();
        add(tarjeta, centro);

        jugadorVsMaquina.addActionListener(e -> actualizarModalidad());
        jugadorVsJugador.addActionListener(e -> actualizarModalidad());
        tipo.addActionListener(e -> actualizarTipo());
        personaje1.addActionListener(e -> actualizarPersonajes());
        personaje2.addActionListener(e -> actualizarPersonajes());
        actualizarModalidad();
        actualizarTipo();
        actualizarPersonajes();
    }

    private JLabel etiqueta(String texto) {
        JLabel l = new JLabel(texto);
        l.setFont(Estilo.fuente(Font.BOLD, 13));
        l.setForeground(new Color(40, 50, 75));
        return l;
    }

    private void actualizarModalidad() {
        boolean maquina = jugadorVsMaquina.isSelected();
        nombre2.setEnabled(!maquina);
        etiquetaPerfil.setVisible(maquina);
        perfil.setVisible(maquina);
        if (maquina) nombre2.setText("Máquina");
        else if (nombre2.getText().equals("Máquina")) nombre2.setText("Jugador 2");
    }

    private void actualizarTipo() {
        boolean porGoles = tipo.getSelectedIndex() == 0;
        etiquetaObjetivo.setText(porGoles ? "Goles para ganar:" : "Minutos del partido:");
        objetivo.setValue(porGoles ? 3 : 2);
    }

    private void actualizarPersonajes() {
        try {
            Personaje p1 = Personaje.buscar((String) personaje1.getSelectedItem());
            Personaje p2 = Personaje.buscar((String) personaje2.getSelectedItem());
            vista1.setPais(p1.getPais());
            vista2.setPais(p2.getPais());
            descripcion1.setText("<html><b>" + p1.getPoder().getNombre() + ":</b> " + p1.getPoder().getDescripcion() + "</html>");
            descripcion2.setText("<html><b>" + p2.getPoder().getNombre() + ":</b> " + p2.getPoder().getDescripcion() + "</html>");
        } catch (JuegoException e) {
            controlador.mostrarError(e);
        }
    }

    private void empezar() {
        try {
            String n1 = nombre1.getText().trim();
            String n2 = nombre2.getText().trim();
            if (n1.isEmpty()) throw new JuegoException("El jugador 1 necesita un nombre.");
            if (n2.isEmpty()) throw new JuegoException("El jugador 2 necesita un nombre.");
            if (n1.equalsIgnoreCase(n2)) throw new JuegoException("Los dos jugadores no pueden tener el mismo nombre.");
            Jugador j1 = new Jugador(n1, Personaje.buscar((String) personaje1.getSelectedItem()));
            Jugador j2 = new Jugador(n2, Personaje.buscar((String) personaje2.getSelectedItem()));
            if (jugadorVsMaquina.isSelected()) j2.setMaquina(Maquina.crear((String) perfil.getSelectedItem()));
            String[] partes = ((String) resolucion.getSelectedItem()).split("x");
            controlador.iniciarPartido(j1, j2, Integer.parseInt(partes[0]), Integer.parseInt(partes[1]),
                    tipo.getSelectedIndex() == 0, (Integer) objetivo.getValue());
        } catch (JuegoException e) {
            controlador.mostrarError(e);
        }
    }

    protected void paintComponent(Graphics g0) {
        Graphics2D g = (Graphics2D) g0.create();
        Estilo.fondoDegradado(g, getWidth(), getHeight());
        g.dispose();
    }
}
