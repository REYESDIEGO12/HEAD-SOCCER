package dominio;

public enum Efecto {
    NINGUNO("Ninguno"),
    EMPUJE("Empujado"),
    ELECTROCUTADO("Electrocutado"),
    INCONSCIENTE("Inconsciente"),
    CONFUNDIDO("Confundido");

    private final String nombre;

    Efecto(String nombre) {
        this.nombre = nombre;
    }

    public String getNombre() {
        return nombre;
    }
}
