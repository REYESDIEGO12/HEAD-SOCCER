package dominio;

import java.io.Serializable;
import java.util.ArrayList;

public abstract class PoderEspecial implements Serializable {
    private String nombre;
    private double duracion;
    private int danoTiro;
    private Efecto efecto;
    private String descripcion;

    public PoderEspecial(String nombre, double duracion, int danoTiro, Efecto efecto, String descripcion) {
        this.nombre = nombre;
        this.duracion = duracion;
        this.danoTiro = danoTiro;
        this.efecto = efecto;
        this.descripcion = descripcion;
    }

    public abstract void lanzar(Balon balon, int direccion);

    public int calcularDano(int kick) {
        double multiplicador = 1 + 0.10 * (kick - 1);
        return (int) Math.round(danoTiro * multiplicador);
    }

    public void aplicarEfecto(Jugador rival, int direccion) {
        rival.recibirEfecto(efecto, getTicksDuracion());
    }

    public ArrayList<Balon> crearSenuelos(Balon real) {
        return new ArrayList<Balon>();
    }

    public boolean generaSenuelos() { return false; }
    public double getFactorGravedad() { return 1.0; }
    public double getReboteSuelo() { return Balon.REBOTE_SUELO; }
    public double getImpulsoRebote() { return 0; }
    public boolean seDetieneAlChocar() { return false; }
    public int getTicksVuelo() { return 150; }

    public int getTicksDuracion() { return (int) Math.round(duracion * 60); }
    public String getNombre() { return nombre; }
    public double getDuracion() { return duracion; }
    public int getDanoTiro() { return danoTiro; }
    public Efecto getEfecto() { return efecto; }
    public String getDescripcion() { return descripcion; }
}
