package dominio;

public class MaquinaDefensiva extends Maquina {

    public String getNombre() { return "Defensiva"; }

    public Accion decidir(Partido partido, Jugador yo, Jugador rival) {
        Accion accion = new Accion();
        Balon balon = balonDeInteres(partido, yo);
        int dir = yo.getDireccion();

        double casa = dir == 1 ? 120 : Cancha.ANCHO - 120;
        if (distanciaAMiArco(yo, balon) < 470) {
            double destino = predecirX(balon, 12) - dir * 40;
            destino = Math.max(60, Math.min(Cancha.ANCHO - 60, destino));
            irHacia(accion, yo, destino);
        } else {
            irHacia(accion, yo, casa);
        }

        if (balonAlAlcance(yo, balon)) accion.setPatear(true);
        if (Math.abs(balon.getX() - yo.getX()) < 50 && balon.getY() < yo.getY() - 90 && balon.getVy() > -2) {
            accion.setSaltar(true);
        }
        if (yo.puedeActivarPoder() && distanciaAMiArco(yo, balon) < 300) accion.setPoder(true);
        return accion;
    }
}
