package dominio;

import java.io.Serializable;

public class Accion implements Serializable {
    private boolean izquierda;
    private boolean derecha;
    private boolean saltar;
    private boolean patear;
    private boolean poder;

    public boolean isIzquierda() { return izquierda; }
    public boolean isDerecha() { return derecha; }
    public boolean isSaltar() { return saltar; }
    public boolean isPatear() { return patear; }
    public boolean isPoder() { return poder; }

    public void setIzquierda(boolean valor) { izquierda = valor; }
    public void setDerecha(boolean valor) { derecha = valor; }
    public void setSaltar(boolean valor) { saltar = valor; }
    public void setPatear(boolean valor) { patear = valor; }
    public void setPoder(boolean valor) { poder = valor; }
}
