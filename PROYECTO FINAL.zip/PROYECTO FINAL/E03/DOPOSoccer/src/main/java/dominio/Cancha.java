package dominio;

import java.io.Serializable;

public class Cancha implements Serializable {
    public static final int ANCHO = 800;
    public static final int ALTO = 450;
    public static final int SUELO = 385;
    public static final int ARCO_ANCHO = 72;
    public static final int ARCO_ALTO = 150;
    public static final int LINEA_GOL = 40;
    public static final int TRAVESANO_Y = SUELO - ARCO_ALTO;
    public static final int TRAVESANO_GROSOR = 10;

    private final int anchoPantalla;
    private final int altoPantalla;

    public Cancha(int anchoPantalla, int altoPantalla) {
        this.anchoPantalla = anchoPantalla;
        this.altoPantalla = altoPantalla;
    }

    public int getAnchoPantalla() { return anchoPantalla; }
    public int getAltoPantalla() { return altoPantalla; }
}
