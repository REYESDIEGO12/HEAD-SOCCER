package dominio;

public class PoderRayo extends PoderEspecial {

    public PoderRayo() {
        super("Rayo", 3, 60, Efecto.ELECTROCUTADO, "Tiro electrico. El rival no salta y va al 50% de velocidad (3 s).");
    }

    public void lanzar(Balon balon, int direccion) {
        balon.setVelocidad(direccion * 17, 0);
    }

    public double getFactorGravedad() { return 0; }
    public boolean seDetieneAlChocar() { return true; }
    public int getTicksVuelo() { return 100; }
}
