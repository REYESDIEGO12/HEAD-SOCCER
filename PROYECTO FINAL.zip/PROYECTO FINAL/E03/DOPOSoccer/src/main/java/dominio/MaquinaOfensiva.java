package dominio;

public class MaquinaOfensiva extends Maquina {

    public String getNombre() { return "Ofensiva"; }

    public Accion decidir(Partido partido, Jugador yo, Jugador rival) {
        Accion accion = new Accion();
        Balon balon = balonDeInteres(partido, yo);
        int dir = yo.getDireccion();

        boolean balonAdelante = dir * (balon.getX() - yo.getX()) > 0;
        if (!balonAdelante || Math.abs(balon.getX() - yo.getX()) > 120) {
            irHacia(accion, yo, predecirX(balon, 10) - dir * 50);
        } else {
            irHacia(accion, yo, balon.getX() + dir * 10);
        }

        if (balonAlAlcance(yo, balon)) accion.setPatear(true);
        if (Math.abs(balon.getX() - yo.getX()) < 50 && balon.getY() < yo.getY() - 90 && balon.getVy() > -2) {
            accion.setSaltar(true);
        }
        if (Math.abs(rival.getX() - yo.getX()) < 70 && !rival.estaAturdido() && azar.nextInt(20) == 0) {
            accion.setPatear(true);
        }
        if (yo.puedeActivarPoder()) accion.setPoder(true);
        return accion;
    }
}
