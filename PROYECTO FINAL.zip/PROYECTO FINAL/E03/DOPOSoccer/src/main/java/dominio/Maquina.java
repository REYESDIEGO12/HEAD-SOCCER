package dominio;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Random;

public abstract class Maquina implements Serializable {
    protected Random azar = new Random();

    public abstract String getNombre();

    public abstract Accion decidir(Partido partido, Jugador yo, Jugador rival);

    public static String[] perfiles() {
        return new String[]{"Torpe", "Ofensiva", "Defensiva", "Experta"};
    }

    public static Maquina crear(String perfil) throws JuegoException {
        if (perfil != null) {
            String p = perfil.trim().toLowerCase();
            if (p.equals("torpe")) return new MaquinaTorpe();
            if (p.equals("ofensiva")) return new MaquinaOfensiva();
            if (p.equals("defensiva")) return new MaquinaDefensiva();
            if (p.equals("experta")) return new MaquinaExperta();
        }
        throw new JuegoException("El perfil de máquina \"" + perfil + "\" no existe.");
    }

    protected Balon balonDeInteres(Partido partido, Jugador yo) {
        if (yo.getEfecto() == Efecto.CONFUNDIDO) {
            ArrayList<Balon> todos = partido.getTodosLosBalones();
            int indice = (partido.getTicksPartido() / 30) % todos.size();
            return todos.get(indice);
        }
        return partido.getBalon();
    }

    protected void irHacia(Accion accion, Jugador yo, double destino) {
        if (yo.getX() < destino - 8) accion.setDerecha(true);
        else if (yo.getX() > destino + 8) accion.setIzquierda(true);
    }

    protected double predecirX(Balon balon, int ticks) {
        double x = balon.getX();
        double y = balon.getY();
        double vx = balon.getVx();
        double vy = balon.getVy();
        for (int i = 0; i < ticks; i++) {
            vy += Balon.GRAVEDAD;
            x += vx;
            y += vy;
            if (y > Cancha.SUELO - balon.getRadio()) {
                y = Cancha.SUELO - balon.getRadio();
                vy = -vy * Balon.REBOTE_SUELO;
            }
            if (x < 14 || x > Cancha.ANCHO - 14) vx = -vx;
        }
        return Math.max(40, Math.min(Cancha.ANCHO - 40, x));
    }

    protected boolean balonAlAlcance(Jugador yo, Balon balon) {
        double delante = (balon.getX() - yo.getX()) * yo.getDireccion();
        return delante > 10 && delante < 80 && Math.abs(balon.getY() - (yo.getY() - 16)) < 45;
    }

    protected double distanciaAMiArco(Jugador yo, Balon balon) {
        if (yo.getDireccion() == 1) return balon.getX();
        return Cancha.ANCHO - balon.getX();
    }
}
