package dominio;

public class PoderAuraAzul extends PoderEspecial {

    public PoderAuraAzul() {
        super("Aura Azul", 1.5, 40, Efecto.EMPUJE, "Tiro recto y rapido. Empuja al rival hacia su arco (1.5 s).");
    }

    public void lanzar(Balon balon, int direccion) {
        balon.setVelocidad(direccion * 19, 0);
    }

    public void aplicarEfecto(Jugador rival, int direccion) {
        super.aplicarEfecto(rival, direccion);
        rival.empujar(direccion * 14);
    }

    public double getFactorGravedad() { return 0; }
    public boolean seDetieneAlChocar() { return true; }
    public int getTicksVuelo() { return 100; }
}
