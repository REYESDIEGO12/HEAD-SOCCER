package dominio;

public class MaquinaExperta extends Maquina {
    private MaquinaOfensiva ataque = new MaquinaOfensiva();
    private MaquinaDefensiva defensa = new MaquinaDefensiva();

    public String getNombre() { return "Experta"; }

    public Accion decidir(Partido partido, Jugador yo, Jugador rival) {
        Balon balon = balonDeInteres(partido, yo);
        int diferencia = yo.getGoles() - rival.getGoles();
        boolean poco = !partido.isPorGoles() && !partido.isMuerteSubita() && partido.getSegundosRestantes() < 30;
        boolean ultimoGol = partido.isPorGoles() && rival.getGoles() == partido.getGolesParaGanar() - 1;
        boolean balonVieneAMiArco = balon.getVx() * yo.getDireccion() < -1 && distanciaAMiArco(yo, balon) < 350;

        boolean defender;
        if (diferencia > 0 && poco) defender = true;
        else if (diferencia < 0 && !ultimoGol) defender = false;
        else if (ultimoGol) defender = true;
        else defender = balonVieneAMiArco;

        Accion accion;
        if (defender) accion = defensa.decidir(partido, yo, rival);
        else accion = ataque.decidir(partido, yo, rival);

        if (yo.puedeActivarPoder()) {
            accion.setPoder(Math.abs(balon.getX() - yo.getX()) < 250);
        }
        return accion;
    }
}
