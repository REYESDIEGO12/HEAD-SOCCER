package dominio;

import java.io.Serializable;
import java.util.ArrayList;

public class Personaje implements Serializable {
    private final String pais;
    private final PoderEspecial poder;

    public Personaje(String pais, PoderEspecial poder) {
        this.pais = pais;
        this.poder = poder;
    }

    public static ArrayList<Personaje> catalogo() {
        ArrayList<Personaje> lista = new ArrayList<Personaje>();
        lista.add(new Personaje("Corea del Sur", new PoderAuraAzul()));
        lista.add(new Personaje("Camerún", new PoderRayo()));
        lista.add(new Personaje("Nigeria", new PoderTornado()));
        lista.add(new Personaje("Estados Unidos", new PoderIlusion()));
        return lista;
    }

    public static Personaje buscar(String pais) throws JuegoException {
        if (pais == null || pais.trim().isEmpty()) {
            throw new JuegoException("Debe seleccionar un personaje.");
        }
        String buscado = quitarTildes(pais.trim());
        for (Personaje p : catalogo()) {
            if (quitarTildes(p.getPais()).equalsIgnoreCase(buscado)) return p;
        }
        throw new JuegoException("El personaje \"" + pais + "\" no existe en el juego.");
    }

    private static String quitarTildes(String texto) {
        return java.text.Normalizer.normalize(texto, java.text.Normalizer.Form.NFD).replaceAll("[^\\p{ASCII}]", "");
    }

    public String getPais() { return pais; }
    public PoderEspecial getPoder() { return poder; }
}
