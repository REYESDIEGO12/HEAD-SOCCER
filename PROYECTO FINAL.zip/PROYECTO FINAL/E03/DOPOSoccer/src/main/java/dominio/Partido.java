package dominio;

import java.io.Serializable;
import java.util.ArrayList;

public class Partido implements Serializable {
    public static final int TICKS_POR_SEGUNDO = 60;
    public static final int TICKS_CELEBRACION = 120;
    public static final int PUNTOS_GANADOR = 100;
    public static final int PUNTOS_PERDEDOR = 25;
    public static final double FUERZA_PATADA = 13;

    private Jugador jugador1;
    private Jugador jugador2;
    private Balon balon;
    private ArrayList<Balon> senuelos = new ArrayList<Balon>();
    private int ticksSenuelos;
    private Cancha cancha;

    private boolean porGoles;
    private int objetivo;
    private int ticksRestantes;
    private boolean muerteSubita;
    private boolean terminado;
    private int ticksGol;
    private int ticksPartido;

    private String mensaje = "";
    private int ticksMensaje;
    private boolean puntosOtorgados;
    private int puntosGanados1;
    private int puntosGanados2;

    public Partido(Jugador jugador1, Jugador jugador2, Cancha cancha, boolean porGoles, int objetivo) {
        this.jugador1 = jugador1;
        this.jugador2 = jugador2;
        this.cancha = cancha;
        this.porGoles = porGoles;
        this.objetivo = objetivo;
        if (!porGoles) ticksRestantes = objetivo * 60 * TICKS_POR_SEGUNDO;
        jugador1.setDireccion(1);
        jugador2.setDireccion(-1);
        jugador1.prepararPartido();
        jugador2.prepararPartido();
        balon = new Balon(Cancha.ANCHO / 2.0, 110);
        reiniciarPosiciones();
    }

    public void avanzar(Accion accion1, Accion accion2) {
        if (terminado && ticksGol == 0) return;
        ticksPartido++;
        if (ticksMensaje > 0) ticksMensaje--;

        if (jugador1.esMaquina()) accion1 = jugador1.getMaquina().decidir(this, jugador1, jugador2);
        if (jugador2.esMaquina()) accion2 = jugador2.getMaquina().decidir(this, jugador2, jugador1);

        if (ticksGol > 0 || terminado) {
            accion1 = new Accion();
            accion2 = new Accion();
        } else {
            controlarTiempo();
        }

        jugador1.actualizar(accion1);
        jugador2.actualizar(accion2);
        if (ticksGol == 0 && !terminado) {
            activarPoderSiPide(jugador1, accion1);
            activarPoderSiPide(jugador2, accion2);
        }

        boolean primeroUno = ticksPartido % 2 == 0;
        if (primeroUno) {
            resolverPatada(jugador1, jugador2);
            resolverPatada(jugador2, jugador1);
        } else {
            resolverPatada(jugador2, jugador1);
            resolverPatada(jugador1, jugador2);
        }

        balon.mover();
        moverSenuelos();
        if (primeroUno) {
            tocarBalon(jugador1, jugador2);
            tocarBalon(jugador2, jugador1);
        } else {
            tocarBalon(jugador2, jugador1);
            tocarBalon(jugador1, jugador2);
        }

        if (ticksGol > 0) {
            ticksGol--;
            if (ticksGol == 0 && !terminado) reiniciarPosiciones();
        } else if (!terminado) {
            revisarGol();
        }
    }

    private void controlarTiempo() {
        if (porGoles || muerteSubita) return;
        ticksRestantes--;
        if (ticksRestantes <= 0) {
            ticksRestantes = 0;
            if (jugador1.getGoles() == jugador2.getGoles()) {
                muerteSubita = true;
                mensaje = "¡MUERTE SÚBITA!";
                ticksMensaje = 150;
            } else {
                terminado = true;
            }
        }
    }

    private void activarPoderSiPide(Jugador jugador, Accion accion) {
        if (accion.isPoder() && jugador.puedeActivarPoder()) {
            try {
                jugador.activarPoder();
            } catch (JuegoException e) {

            }
        }
    }

    private void moverSenuelos() {
        for (Balon falso : senuelos) falso.mover();
        if (ticksSenuelos > 0) {
            ticksSenuelos--;
            if (ticksSenuelos == 0) senuelos.clear();
        }
    }

    private void revisarGol() {
        if (balon.getY() <= Cancha.TRAVESANO_Y) return;
        if (balon.getX() < Cancha.LINEA_GOL) registrarGol(2);
        else if (balon.getX() > Cancha.ANCHO - Cancha.LINEA_GOL) registrarGol(1);
    }

    public void registrarGol(int numeroJugador) {
        if (terminado) return;
        Jugador anotador = numeroJugador == 1 ? jugador1 : jugador2;
        Jugador rival = numeroJugador == 1 ? jugador2 : jugador1;
        anotador.sumarGol();
        rival.recibirGol();
        mensaje = "¡GOL DE " + anotador.getNombre().toUpperCase() + "!";
        ticksMensaje = TICKS_CELEBRACION;
        ticksGol = TICKS_CELEBRACION;
        balon.terminarTiro();
        senuelos.clear();
        ticksSenuelos = 0;
        if (muerteSubita || (porGoles && anotador.getGoles() >= objetivo)) {
            terminado = true;
        }
    }

    private void tocarBalon(Jugador jugador, Jugador rival) {
        if (balon.getDueno() == jugador) return;
        double[][] partes = {
            {jugador.getX(), jugador.getCabezaY(), Jugador.RADIO_CABEZA},
            {jugador.getX(), jugador.getCuerpoY(), Jugador.RADIO_CUERPO}
        };
        for (double[] parte : partes) {
            if (!balon.estaChocando(parte[0], parte[1], parte[2])) continue;
            if (balon.getTiro() != null) {
                golpearConTiro(jugador);
            } else if (jugador.isPoderActivo() && ticksGol == 0 && !terminado) {
                lanzarTiro(jugador);
            } else {
                balon.chocarCirculo(parte[0], parte[1], parte[2], jugador.getVx(), jugador.getVy(), 0.55);
            }
            return;
        }
    }

    private void resolverPatada(Jugador jugador, Jugador rival) {
        if (!jugador.patadaPendiente() || ticksGol > 0 || terminado) return;
        double pieX = jugador.getPieX();
        double pieY = jugador.getPieY();

        if (balon.getDueno() != jugador && balon.estaChocando(pieX, pieY, Jugador.RADIO_PIE)) {

            if (balon.getTiro() != null) balon.terminarTiro();
            if (jugador.isPoderActivo()) {
                lanzarTiro(jugador);
            } else {
                balon.patear(jugador.getDireccion(), FUERZA_PATADA, 0.5, jugador.getVx());
            }
            jugador.resolverPatada();
            return;
        }

        boolean alcanzaCabeza = distancia(pieX, pieY, rival.getX(), rival.getCabezaY()) < Jugador.RADIO_PIE + Jugador.RADIO_CABEZA;
        boolean alcanzaCuerpo = distancia(pieX, pieY, rival.getX(), rival.getCuerpoY()) < Jugador.RADIO_PIE + Jugador.RADIO_CUERPO;
        if (alcanzaCabeza || alcanzaCuerpo) {
            rival.recibirDano(jugador.calcularDanoPatada());
            jugador.resolverPatada();
        }
    }

    private double distancia(double x1, double y1, double x2, double y2) {
        return Math.sqrt((x1 - x2) * (x1 - x2) + (y1 - y2) * (y1 - y2));
    }

    private void lanzarTiro(Jugador jugador) {
        PoderEspecial poder = jugador.getPersonaje().getPoder();
        int dir = jugador.getDireccion();
        jugador.usarPoder();
        balon.setPosicion(jugador.getX() + dir * (Jugador.RADIO_CABEZA + balon.getRadio() + 6), jugador.getY() - 45);
        balon.iniciarTiro(poder, jugador, dir);
        senuelos = poder.crearSenuelos(balon);
        ticksSenuelos = senuelos.isEmpty() ? 0 : poder.getTicksDuracion();
    }

    private void golpearConTiro(Jugador victima) {
        PoderEspecial tiro = balon.getTiro();
        Jugador lanzador = balon.getDueno();
        victima.recibirDano(lanzador.calcularDanoPoder(tiro));
        tiro.aplicarEfecto(victima, balon.getDireccionTiro());
        if (tiro.generaSenuelos()) ticksSenuelos = tiro.getTicksDuracion();
        balon.terminarTiro();
        balon.setVelocidad(balon.getVx() * 0.3, -4);
    }

    private void reiniciarPosiciones() {
        jugador1.ubicar(Cancha.ANCHO * 0.25);
        jugador2.ubicar(Cancha.ANCHO * 0.75);
        balon.reiniciar(Cancha.ANCHO / 2.0, 110);
        senuelos.clear();
        ticksSenuelos = 0;
    }

    public void terminarPartido() {
        terminado = true;
        ticksGol = 0;
    }

    public boolean estaTerminado() { return terminado; }

    public boolean mostrarResultado() { return terminado && ticksGol == 0; }

    public Jugador getGanador() {
        if (jugador1.getGoles() > jugador2.getGoles()) return jugador1;
        if (jugador2.getGoles() > jugador1.getGoles()) return jugador2;
        return null;
    }

    public String nombreGanador() {
        Jugador g = getGanador();
        if (g == null) return "Empate";
        return g.getNombre();
    }

    public void otorgarPuntos() {
        if (puntosOtorgados) return;
        puntosOtorgados = true;
        Jugador ganador = getGanador();
        if (ganador == null) {
            puntosGanados1 = PUNTOS_PERDEDOR;
            puntosGanados2 = PUNTOS_PERDEDOR;
        } else if (ganador == jugador1) {
            puntosGanados1 = PUNTOS_GANADOR;
            puntosGanados2 = PUNTOS_PERDEDOR;
        } else {
            puntosGanados1 = PUNTOS_PERDEDOR;
            puntosGanados2 = PUNTOS_GANADOR;
        }
        jugador1.agregarPuntos(puntosGanados1);
        jugador2.agregarPuntos(puntosGanados2);
    }

    public ArrayList<Balon> getTodosLosBalones() {
        ArrayList<Balon> todos = new ArrayList<Balon>();
        todos.add(balon);
        todos.addAll(senuelos);
        return todos;
    }

    public int getSegundosRestantes() {
        return (int) Math.ceil(ticksRestantes / (double) TICKS_POR_SEGUNDO);
    }

    public Jugador getJugador1() { return jugador1; }
    public Jugador getJugador2() { return jugador2; }
    public Balon getBalon() { return balon; }
    public ArrayList<Balon> getSenuelos() { return senuelos; }
    public Cancha getCancha() { return cancha; }
    public boolean isPorGoles() { return porGoles; }
    public int getObjetivo() { return objetivo; }
    public int getGolesParaGanar() { return porGoles ? objetivo : 0; }
    public boolean isMuerteSubita() { return muerteSubita; }
    public int getTicksGol() { return ticksGol; }
    public int getTicksPartido() { return ticksPartido; }
    public String getMensaje() { return mensaje; }
    public int getTicksMensaje() { return ticksMensaje; }
    public int getPuntosGanados1() { return puntosGanados1; }
    public int getPuntosGanados2() { return puntosGanados2; }
}
