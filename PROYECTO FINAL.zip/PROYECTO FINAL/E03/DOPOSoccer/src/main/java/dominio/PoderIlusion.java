package dominio;

import java.util.ArrayList;

public class PoderIlusion extends PoderEspecial {

    public PoderIlusion() {
        super("Ilusión", 2.5, 30, Efecto.CONFUNDIDO, "El balon se divide en 8 iguales (7 falsos). El rival se confunde (2.5 s).");
    }

    public void lanzar(Balon balon, int direccion) {
        balon.setVelocidad(direccion * 11, -4);
    }

    public ArrayList<Balon> crearSenuelos(Balon real) {
        ArrayList<Balon> falsos = new ArrayList<Balon>();
        int direccion = real.getVx() >= 0 ? 1 : -1;
        for (int i = 0; i < 7; i++) {
            double angulo = -1.0 + i * 0.3;
            double rapidez = 8 + (i % 3) * 2;
            Balon falso = new Balon(real.getX(), real.getY());
            falso.setFalso(true);
            falso.setVelocidad(direccion * rapidez * Math.cos(angulo), rapidez * Math.sin(angulo));
            falsos.add(falso);
        }
        return falsos;
    }

    public boolean generaSenuelos() { return true; }
}
