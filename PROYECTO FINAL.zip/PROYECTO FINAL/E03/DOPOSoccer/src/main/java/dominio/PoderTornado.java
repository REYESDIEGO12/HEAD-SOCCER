package dominio;

public class PoderTornado extends PoderEspecial {

    public PoderTornado() {
        super("Tornado", 3, 40, Efecto.INCONSCIENTE, "Remolino a ras de suelo. El rival sale volando y queda inconsciente (3 s).");
    }

    public void lanzar(Balon balon, int direccion) {
        balon.setPosicion(balon.getX(), Cancha.SUELO - balon.getRadio());
        balon.setVelocidad(direccion * 9, -6);
    }

    public void aplicarEfecto(Jugador rival, int direccion) {
        super.aplicarEfecto(rival, direccion);
        rival.lanzarAlAire(-14);
    }

    public double getFactorGravedad() { return 2.0; }
    public double getReboteSuelo() { return 0.95; }
    public double getImpulsoRebote() { return 6; }
    public boolean seDetieneAlChocar() { return true; }
}
