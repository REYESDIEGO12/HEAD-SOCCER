package dominio;

public class MaquinaTorpe extends Maquina {
    private Accion actual = new Accion();
    private int ticksRestantes;

    public String getNombre() { return "Torpe"; }

    public Accion decidir(Partido partido, Jugador yo, Jugador rival) {
        ticksRestantes--;
        if (ticksRestantes <= 0) {
            actual = new Accion();
            int opcion = azar.nextInt(6);
            if (opcion == 0) actual.setIzquierda(true);
            else if (opcion == 1) actual.setDerecha(true);
            else if (opcion == 2) actual.setSaltar(true);
            else if (opcion == 3) actual.setPatear(true);
            else if (opcion == 4) { actual.setDerecha(true); actual.setPatear(true); }
            ticksRestantes = 10 + azar.nextInt(25);
        }
        actual.setPoder(yo.puedeActivarPoder() && azar.nextInt(180) == 0);
        return actual;
    }
}
