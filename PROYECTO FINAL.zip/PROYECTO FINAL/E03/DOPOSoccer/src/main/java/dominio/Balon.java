package dominio;

import java.io.Serializable;

public class Balon implements Serializable {
    public static final double GRAVEDAD = 0.42;
    public static final double REBOTE_SUELO = 0.72;
    public static final double REBOTE_PARED = 0.80;
    public static final double REBOTE_RED = 0.15;
    public static final double REBOTE_TRAVESANO = 0.65;
    public static final double RESISTENCIA_AIRE = 0.9985;
    public static final double FRICCION_SUELO = 0.988;
    public static final double VELOCIDAD_MAX = 20;
    public static final int SUBPASOS = 3;

    private double x;
    private double y;
    private double vx;
    private double vy;
    private final double radio = 14;
    private double angulo;
    private double velAngular;
    private double impacto;

    private PoderEspecial tiro;
    private Jugador dueno;
    private int direccionTiro;
    private int ticksTiro;

    private boolean falso;

    public Balon(double x, double y) {
        this.x = x;
        this.y = y;
    }

    public void mover() {
        double factorGravedad = 1.0;
        if (tiro != null) factorGravedad = tiro.getFactorGravedad();

        for (int i = 0; i < SUBPASOS; i++) {
            vy += GRAVEDAD * factorGravedad / SUBPASOS;
            x += vx / SUBPASOS;
            y += vy / SUBPASOS;
            chocarConBordes();
            chocarConTravesanos();
        }

        vx *= RESISTENCIA_AIRE;
        if (enSuelo()) {
            if (tiro == null) vx *= FRICCION_SUELO;
            velAngular = vx / radio;
        } else {
            velAngular *= 0.997;
        }
        angulo += velAngular;
        impacto *= 0.8;

        if (tiro != null) {
            ticksTiro--;
            if (ticksTiro <= 0) terminarTiro();
        }
        limitarVelocidad();
    }

    private void chocarConBordes() {
        if (y + radio > Cancha.SUELO) {
            y = Cancha.SUELO - radio;
            if (vy > 0) {
                double e = REBOTE_SUELO;
                if (tiro != null) e = tiro.getReboteSuelo();
                impacto = Math.min(1, vy / 12);
                vy = -vy * e;
                if (tiro != null) vy = Math.min(vy, -tiro.getImpulsoRebote());
                else if (Math.abs(vy) < 1.3) vy = 0;
                vx += (velAngular * radio - vx) * 0.08;
                if (tiro != null && tiro.seDetieneAlChocar()) terminarTiro();
            }
        }
        if (y - radio < 0) {
            y = radio;
            if (vy < 0) vy = -vy * 0.6;
        }
        boolean enRed = y > Cancha.TRAVESANO_Y;
        double rebote = enRed ? REBOTE_RED : REBOTE_PARED;
        if (x - radio < 0) {
            x = radio;
            if (vx < 0) { vx = -vx * rebote; chocoPared(); }
        }
        if (x + radio > Cancha.ANCHO) {
            x = Cancha.ANCHO - radio;
            if (vx > 0) { vx = -vx * rebote; chocoPared(); }
        }
    }

    private void chocoPared() {
        impacto = 0.5;
        if (tiro != null && tiro.seDetieneAlChocar()) terminarTiro();
    }

    private void chocarConTravesanos() {
        int y1 = Cancha.TRAVESANO_Y;
        int y2 = Cancha.TRAVESANO_Y + Cancha.TRAVESANO_GROSOR;
        chocarConRectangulo(0, y1, Cancha.ARCO_ANCHO, y2);
        chocarConRectangulo(Cancha.ANCHO - Cancha.ARCO_ANCHO, y1, Cancha.ANCHO, y2);
    }

    private void chocarConRectangulo(double x1, double y1, double x2, double y2) {
        double cx = Math.max(x1, Math.min(x, x2));
        double cy = Math.max(y1, Math.min(y, y2));
        double dx = x - cx;
        double dy = y - cy;
        double d = Math.sqrt(dx * dx + dy * dy);
        if (d >= radio) return;
        double nx = 0;
        double ny = -1;
        if (d > 0.0001) { nx = dx / d; ny = dy / d; }
        x = cx + nx * radio;
        y = cy + ny * radio;
        double vn = vx * nx + vy * ny;
        if (vn < 0) {
            vx -= (1 + REBOTE_TRAVESANO) * vn * nx;
            vy -= (1 + REBOTE_TRAVESANO) * vn * ny;
            impacto = 0.5;
            if (tiro != null && tiro.seDetieneAlChocar()) terminarTiro();
        }
    }

    public boolean estaChocando(double cx, double cy, double r) {
        double dx = x - cx;
        double dy = y - cy;
        double minimo = radio + r;
        return dx * dx + dy * dy < minimo * minimo;
    }

    public void chocarCirculo(double cx, double cy, double r, double cvx, double cvy, double e) {
        double dx = x - cx;
        double dy = y - cy;
        double d = Math.sqrt(dx * dx + dy * dy);
        double nx = 0;
        double ny = -1;
        if (d > 0.0001) { nx = dx / d; ny = dy / d; }
        double minimo = radio + r;
        x = cx + nx * minimo;
        y = cy + ny * minimo;
        double rvx = vx - cvx;
        double rvy = vy - cvy;
        double vn = rvx * nx + rvy * ny;
        if (vn < 0) {
            vx -= (1 + e) * vn * nx;
            vy -= (1 + e) * vn * ny;
            double tangencial = rvx * (-ny) + rvy * nx;
            velAngular += tangencial * 0.02;
            impacto = Math.min(1, -vn / 10);
        }
        limitarVelocidad();
    }

    public void patear(int direccion, double fuerza, double anguloSalida, double velJugador) {
        vx = direccion * fuerza * Math.cos(anguloSalida) + velJugador * 0.4;
        vy = -fuerza * Math.sin(anguloSalida);
        velAngular = direccion * 0.35;
        impacto = 0.6;
    }

    public void iniciarTiro(PoderEspecial poder, Jugador lanzador, int direccion) {
        tiro = poder;
        dueno = lanzador;
        direccionTiro = direccion;
        ticksTiro = poder.getTicksVuelo();
        poder.lanzar(this, direccion);
    }

    public void terminarTiro() {
        tiro = null;
        dueno = null;
        ticksTiro = 0;
    }

    private void limitarVelocidad() {
        double v = Math.sqrt(vx * vx + vy * vy);
        if (tiro == null && v > VELOCIDAD_MAX) {
            vx = vx / v * VELOCIDAD_MAX;
            vy = vy / v * VELOCIDAD_MAX;
        }
    }

    public boolean enSuelo() { return y >= Cancha.SUELO - radio - 0.5; }

    public void reiniciar(double nuevoX, double nuevoY) {
        x = nuevoX;
        y = nuevoY;
        vx = 0;
        vy = 0;
        velAngular = 0;
        impacto = 0;
        terminarTiro();
    }

    public void setPosicion(double nuevoX, double nuevoY) { x = nuevoX; y = nuevoY; }
    public void setVelocidad(double nuevoVx, double nuevoVy) { vx = nuevoVx; vy = nuevoVy; }
    public void setFalso(boolean valor) { falso = valor; }

    public double getX() { return x; }
    public double getY() { return y; }
    public double getVx() { return vx; }
    public double getVy() { return vy; }
    public double getRadio() { return radio; }
    public double getAngulo() { return angulo; }
    public double getImpacto() { return impacto; }
    public boolean isFalso() { return falso; }
    public PoderEspecial getTiro() { return tiro; }
    public Jugador getDueno() { return dueno; }
    public int getDireccionTiro() { return direccionTiro; }
}
