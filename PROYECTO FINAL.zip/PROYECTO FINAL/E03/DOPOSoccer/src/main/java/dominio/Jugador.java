package dominio;

import java.io.Serializable;

public class Jugador implements Serializable {
    public static final double GRAVEDAD = 0.55;
    public static final double VELOCIDAD_BASE = 4.2;
    public static final double SALTO_BASE = 11.5;
    public static final int MAX_ESTADISTICA = 10;
    public static final int COSTO_BASE = 500;
    public static final int SEGUNDOS_BARRA = 10;
    public static final int TICKS_ATURDIMIENTO = 180;
    public static final int DURACION_PATADA = 14;
    public static final int ENFRIAMIENTO_PATADA = 26;
    public static final double RADIO_CABEZA = 28;
    public static final double RADIO_CUERPO = 18;
    public static final double RADIO_PIE = 20;
    public static final double MIN_X = 45;
    public static final double MAX_X = Cancha.ANCHO - 45;

    private String nombre;
    private Personaje personaje;
    private int goles;
    private int vida;
    private int vidaMax;
    private double barraPoder;
    private boolean poderActivo;
    private int speed = 1;
    private int kick = 1;
    private int jump = 1;
    private int survival = 1;
    private int puntos;

    private double x;
    private double y = Cancha.SUELO;
    private double vx;
    private double vy;
    private int direccion = 1;

    private Efecto efecto = Efecto.NINGUNO;
    private int ticksEfecto;
    private int ticksAturdido;
    private int ticksPatada;
    private int enfriamiento;
    private boolean patadaResuelta = true;

    private Maquina maquina;

    public Jugador(String nombre, Personaje personaje) {
        this.nombre = nombre;
        this.personaje = personaje;
        vidaMax = calcularVidaMax();
        vida = vidaMax;
    }

    public int calcularVidaMax() {
        return (int) Math.round(100 * (1 + 0.10 * (survival - 1)));
    }

    public double getMultiplicadorKick() {
        return 1 + 0.10 * (kick - 1);
    }

    public int calcularDanoPatada() {
        return (int) Math.round(10 * getMultiplicadorKick());
    }

    public int calcularDanoPoder(PoderEspecial poder) {
        return poder.calcularDano(kick);
    }

    public void actualizar(Accion accion) {
        if (ticksAturdido > 0) {
            ticksAturdido--;
            if (ticksAturdido == 0) vida = vidaMax;
        }
        if (ticksEfecto > 0) {
            ticksEfecto--;
            if (ticksEfecto == 0) efecto = Efecto.NINGUNO;
        }
        if (enfriamiento > 0) enfriamiento--;
        if (ticksPatada > 0) ticksPatada--;
        if (barraPoder < 100) {
            barraPoder = Math.min(100, barraPoder + 100.0 / (SEGUNDOS_BARRA * 60));
        }

        if (tieneControl()) {
            double velocidad = getVelocidadMovimiento();
            double objetivo = 0;
            if (accion.isIzquierda()) objetivo -= velocidad;
            if (accion.isDerecha()) objetivo += velocidad;
            vx += (objetivo - vx) * 0.4;
            if (accion.isSaltar() && enSuelo() && efecto != Efecto.ELECTROCUTADO) {
                vy = -getVelocidadSalto();
            }
            if (accion.isPatear() && enfriamiento == 0) {
                ticksPatada = DURACION_PATADA;
                enfriamiento = ENFRIAMIENTO_PATADA;
                patadaResuelta = false;
            }
        } else {
            vx *= 0.94;
        }

        vy += GRAVEDAD;
        x += vx;
        y += vy;
        if (y >= Cancha.SUELO) {
            y = Cancha.SUELO;
            vy = 0;
        }
        if (x < MIN_X) { x = MIN_X; vx = 0; }
        if (x > MAX_X) { x = MAX_X; vx = 0; }
    }

    public boolean tieneControl() {
        return !estaAturdido() && efecto != Efecto.INCONSCIENTE && efecto != Efecto.EMPUJE;
    }

    public double getVelocidadMovimiento() {
        double velocidad = VELOCIDAD_BASE * (1 + 0.10 * (speed - 1));
        if (efecto == Efecto.ELECTROCUTADO) velocidad = velocidad * 0.5;
        return velocidad;
    }

    public double getVelocidadSalto() {
        return SALTO_BASE * Math.sqrt(1 + 0.10 * (jump - 1));
    }

    public boolean enSuelo() { return y >= Cancha.SUELO - 0.01; }

    public void empujar(double velocidadX) { vx = velocidadX; }
    public void lanzarAlAire(double velocidadY) { vy = velocidadY; }

    public void ubicar(double nuevoX) {
        x = nuevoX;
        y = Cancha.SUELO;
        vx = 0;
        vy = 0;
        ticksPatada = 0;
        patadaResuelta = true;
        efecto = Efecto.NINGUNO;
        ticksEfecto = 0;
    }

    public double getProgresoPatada() {
        if (ticksPatada <= 0) return 0;
        return 1.0 - (double) ticksPatada / DURACION_PATADA;
    }

    public double getPieX() {
        double s = Math.sin(Math.PI * getProgresoPatada());
        return x + direccion * (20 + 30 * s);
    }

    public double getPieY() {
        double s = Math.sin(Math.PI * getProgresoPatada());
        return y - 14 - 6 * s;
    }

    public boolean estaPateando() { return ticksPatada > 0; }
    public boolean patadaPendiente() { return ticksPatada > 0 && !patadaResuelta; }
    public void resolverPatada() { patadaResuelta = true; }

    public void recibirDano(int dano) {
        if (estaAturdido()) return;
        vida -= dano;
        if (vida <= 0) {
            vida = 0;
            ticksAturdido = TICKS_ATURDIMIENTO;
        }
    }

    public boolean estaAturdido() { return ticksAturdido > 0; }

    public void recibirEfecto(Efecto nuevo, int ticks) {
        efecto = nuevo;
        ticksEfecto = ticks;
    }

    public void recibirGol() {
        barraPoder = Math.min(100, barraPoder + 25);
    }

    public boolean puedeActivarPoder() {
        return !poderActivo && barraPoder >= 100 && !estaAturdido();
    }

    public void activarPoder() throws JuegoException {
        if (poderActivo) throw new JuegoException("El poder ya está activo.");
        if (barraPoder < 100) throw new JuegoException("La barra de poder no está llena.");
        barraPoder = 0;
        poderActivo = true;
    }

    public void usarPoder() { poderActivo = false; }

    public void agregarPuntos(int cantidad) { puntos += cantidad; }

    public int getNivel(String estadistica) throws JuegoException {
        String e = estadistica == null ? "" : estadistica.trim().toLowerCase();
        if (e.equals("speed")) return speed;
        if (e.equals("kick")) return kick;
        if (e.equals("jump")) return jump;
        if (e.equals("survival")) return survival;
        throw new JuegoException("La estadística \"" + estadistica + "\" no existe. Use speed, kick, jump o survival.");
    }

    public int getCostoMejora(String estadistica) throws JuegoException {
        int nivel = getNivel(estadistica);
        if (nivel >= MAX_ESTADISTICA) {
            throw new JuegoException("La estadística " + estadistica + " ya está en el nivel máximo (" + MAX_ESTADISTICA + ").");
        }
        return COSTO_BASE * (int) Math.pow(2, nivel - 1);
    }

    public void mejorarEstadistica(String estadistica) throws JuegoException {
        int costo = getCostoMejora(estadistica);
        if (puntos < costo) {
            throw new JuegoException("No tienes puntos suficientes para mejorar " + estadistica
                    + ". Necesitas " + costo + " y tienes " + puntos + ".");
        }
        String e = estadistica.trim().toLowerCase();
        if (e.equals("speed")) speed++;
        else if (e.equals("kick")) kick++;
        else if (e.equals("jump")) jump++;
        else survival++;
        puntos -= costo;
        vidaMax = calcularVidaMax();
        vida = vidaMax;
    }

    public void setProgreso(int puntos, int speed, int kick, int jump, int survival) throws JuegoException {
        int[] niveles = {speed, kick, jump, survival};
        for (int n : niveles) {
            if (n < 1 || n > MAX_ESTADISTICA) {
                throw new JuegoException("El progreso guardado de " + nombre + " tiene un nivel inválido: " + n);
            }
        }
        if (puntos < 0) throw new JuegoException("El progreso guardado de " + nombre + " tiene puntos negativos.");
        this.puntos = puntos;
        this.speed = speed;
        this.kick = kick;
        this.jump = jump;
        this.survival = survival;
        vidaMax = calcularVidaMax();
        vida = vidaMax;
    }

    public void prepararPartido() {
        goles = 0;
        vidaMax = calcularVidaMax();
        vida = vidaMax;
        barraPoder = 0;
        poderActivo = false;
        ticksAturdido = 0;
        enfriamiento = 0;
    }

    public void sumarGol() { goles++; }
    public boolean esMaquina() { return maquina != null; }
    public void setMaquina(Maquina maquina) { this.maquina = maquina; }
    public Maquina getMaquina() { return maquina; }
    public void setDireccion(int direccion) { this.direccion = direccion; }

    public String getNombre() { return nombre; }
    public Personaje getPersonaje() { return personaje; }
    public String getPais() { return personaje.getPais(); }
    public int getGoles() { return goles; }
    public int getVida() { return vida; }
    public int getVidaMax() { return vidaMax; }
    public double getBarraPoder() { return barraPoder; }
    public boolean isPoderActivo() { return poderActivo; }
    public int getSpeed() { return speed; }
    public int getKick() { return kick; }
    public int getJump() { return jump; }
    public int getSurvival() { return survival; }
    public int getPuntos() { return puntos; }
    public double getX() { return x; }
    public double getY() { return y; }
    public double getVx() { return vx; }
    public double getVy() { return vy; }
    public int getDireccion() { return direccion; }
    public Efecto getEfecto() { return efecto; }
    public int getTicksEfecto() { return ticksEfecto; }
    public int getTicksAturdido() { return ticksAturdido; }
    public double getCabezaY() { return y - 52; }
    public double getCuerpoY() { return y - 18; }
}
