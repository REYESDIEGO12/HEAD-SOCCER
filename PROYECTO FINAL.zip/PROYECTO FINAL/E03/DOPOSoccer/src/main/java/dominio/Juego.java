package dominio;

public class Juego {
    private Partido partido;

    public void crearPartido(Jugador jugador1, Jugador jugador2, int anchoPantalla, int altoPantalla,
                             boolean porGoles, int objetivo) throws JuegoException {
        if (jugador1 == null || jugador2 == null) {
            throw new JuegoException("Debe seleccionar los dos jugadores.");
        }
        if (anchoPantalla <= 0 || altoPantalla <= 0) {
            throw new JuegoException("La resolución no es válida: " + anchoPantalla + "x" + altoPantalla + ".");
        }
        if (porGoles && (objetivo < 1 || objetivo > 20)) {
            throw new JuegoException("Los goles para ganar deben estar entre 1 y 20.");
        }
        if (!porGoles && (objetivo < 1 || objetivo > 30)) {
            throw new JuegoException("Los minutos del partido deben estar entre 1 y 30.");
        }
        partido = new Partido(jugador1, jugador2, new Cancha(anchoPantalla, altoPantalla), porGoles, objetivo);
    }

    public void setPartido(Partido partido) { this.partido = partido; }
    public Partido getPartido() { return partido; }
}
