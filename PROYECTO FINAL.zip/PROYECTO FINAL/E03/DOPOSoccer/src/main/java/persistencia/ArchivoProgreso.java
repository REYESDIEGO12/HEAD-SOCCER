package persistencia;

import dominio.Jugador;
import dominio.JuegoException;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Properties;

public class ArchivoProgreso {
    private final File archivo;
    private Properties datos = new Properties();

    public ArchivoProgreso() {
        this(new File("datos", "progreso.properties"));
    }

    public ArchivoProgreso(File archivo) {
        this.archivo = archivo;
        if (archivo.exists()) {
            try (FileInputStream entrada = new FileInputStream(archivo)) {
                datos.load(entrada);
            } catch (IOException e) {
                RegistroErrores.registrar("Leer progreso " + archivo.getPath(), e);
                datos = new Properties();
            }
        }
    }

    private String clave(String nombre, String campo) {
        return "perfil." + nombre.trim().replace('.', '_') + "." + campo;
    }

    private int leer(String nombre, String campo, int porDefecto) {
        String valor = datos.getProperty(clave(nombre, campo));
        if (valor == null) return porDefecto;
        try {
            return Integer.parseInt(valor.trim());
        } catch (NumberFormatException e) {
            RegistroErrores.registrar("Dato de progreso invalido: " + clave(nombre, campo), e);
            return porDefecto;
        }
    }

    public void cargarEn(Jugador jugador) throws JuegoException {
        String nombre = jugador.getNombre();
        jugador.setProgreso(leer(nombre, "puntos", 0), leer(nombre, "speed", 1), leer(nombre, "kick", 1),
                leer(nombre, "jump", 1), leer(nombre, "survival", 1));
    }

    public void guardarDe(Jugador jugador) throws JuegoException {
        String nombre = jugador.getNombre();
        datos.setProperty(clave(nombre, "puntos"), String.valueOf(jugador.getPuntos()));
        datos.setProperty(clave(nombre, "speed"), String.valueOf(jugador.getSpeed()));
        datos.setProperty(clave(nombre, "kick"), String.valueOf(jugador.getKick()));
        datos.setProperty(clave(nombre, "jump"), String.valueOf(jugador.getJump()));
        datos.setProperty(clave(nombre, "survival"), String.valueOf(jugador.getSurvival()));
        try {
            File carpeta = archivo.getParentFile();
            if (carpeta != null && !carpeta.exists()) carpeta.mkdirs();
            try (FileOutputStream salida = new FileOutputStream(archivo)) {
                datos.store(salida, "Progreso de DOPOSoccer");
            }
        } catch (IOException e) {
            RegistroErrores.registrar("Guardar progreso de " + nombre, e);
            throw new JuegoException("No se pudo guardar el progreso de " + nombre + " en " + archivo.getPath()
                    + ". Detalle: " + e.getMessage(), e);
        }
    }

    public ArrayList<String> nombresGuardados() {
        ArrayList<String> nombres = new ArrayList<String>();
        for (String llave : datos.stringPropertyNames()) {
            if (llave.startsWith("perfil.") && llave.endsWith(".puntos")) {
                nombres.add(llave.substring(7, llave.length() - 7));
            }
        }
        Collections.sort(nombres);
        return nombres;
    }
}
