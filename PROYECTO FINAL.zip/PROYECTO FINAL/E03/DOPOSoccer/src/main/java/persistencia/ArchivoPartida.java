package persistencia;

import dominio.JuegoException;
import dominio.Partido;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputFilter;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class ArchivoPartida {
    public static final String EXTENSION = ".dopo";

    public static void guardar(Partido partido, File archivo) throws JuegoException {
        if (partido == null) throw new JuegoException("No hay ningún partido para guardar.");
        try (ObjectOutputStream salida = new ObjectOutputStream(new FileOutputStream(archivo))) {
            salida.writeObject(partido);
        } catch (IOException e) {
            RegistroErrores.registrar("Guardar partida en " + archivo.getPath(), e);
            throw new JuegoException("No se pudo guardar la partida en \"" + archivo.getName()
                    + "\". Revise que la carpeta exista y que tenga permisos de escritura. Detalle: " + e.getMessage(), e);
        }
    }

    public static Partido abrir(File archivo) throws JuegoException {
        if (!archivo.exists()) {
            throw new JuegoException("El archivo \"" + archivo.getName() + "\" no existe.");
        }
        try (ObjectInputStream entrada = new ObjectInputStream(new FileInputStream(archivo))) {

            entrada.setObjectInputFilter(info -> {
                Class<?> clase = info.serialClass();
                if (clase == null) return ObjectInputFilter.Status.UNDECIDED;
                String nombre = clase.getName();
                if (nombre.startsWith("dominio.") || nombre.startsWith("java.util.")
                        || nombre.startsWith("java.lang.") || nombre.startsWith("[")) {
                    return ObjectInputFilter.Status.ALLOWED;
                }
                return ObjectInputFilter.Status.REJECTED;
            });
            Object objeto = entrada.readObject();
            if (!(objeto instanceof Partido)) {
                throw new JuegoException("El archivo \"" + archivo.getName() + "\" no contiene una partida de DOPOSoccer.");
            }
            return (Partido) objeto;
        } catch (IOException | ClassNotFoundException e) {
            RegistroErrores.registrar("Abrir partida " + archivo.getPath(), e);
            throw new JuegoException("No se pudo abrir \"" + archivo.getName()
                    + "\". El archivo está dañado o no es una partida de DOPOSoccer.", e);
        }
    }
}
