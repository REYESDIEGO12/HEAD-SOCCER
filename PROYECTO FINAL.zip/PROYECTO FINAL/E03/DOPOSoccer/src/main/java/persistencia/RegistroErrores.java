package persistencia;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDateTime;

public class RegistroErrores {
    private static final String ARCHIVO = "registro_errores.log";

    public static void registrar(String contexto, Throwable error) {
        try (PrintWriter escritor = new PrintWriter(new FileWriter(ARCHIVO, true))) {
            escritor.println("[" + LocalDateTime.now() + "] " + contexto);
            escritor.println("  " + error.getClass().getName() + ": " + error.getMessage());
            error.printStackTrace(escritor);
            escritor.println();
        } catch (IOException e) {
            System.err.println("No se pudo escribir el log de errores: " + e.getMessage());
        }
    }

    public static String getArchivo() { return ARCHIVO; }
}
