package persistencia;

import dominio.*;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;

import java.io.File;
import java.io.FileWriter;

import static org.junit.Assert.*;

public class PersistenciaTest {
    @Rule public TemporaryFolder carpeta = new TemporaryFolder();

    private Partido crearPartido() throws JuegoException {
        Jugador j1 = new Jugador("Ana", Personaje.buscar("Camerún"));
        Jugador j2 = new Jugador("Máquina", Personaje.buscar("Nigeria"));
        j2.setMaquina(Maquina.crear("Defensiva"));
        return new Partido(j1, j2, new Cancha(1000, 560), false, 2);
    }

    @Test public void guardarYAbrirConservaElEstadoDelPartido() throws Exception {
        Partido partido = crearPartido();
        partido.registrarGol(1);
        for (int i = 0; i < 300; i++) partido.avanzar(new Accion(), new Accion());
        File archivo = carpeta.newFile("partida.dopo");
        ArchivoPartida.guardar(partido, archivo);

        Partido abierto = ArchivoPartida.abrir(archivo);
        assertEquals(1, abierto.getJugador1().getGoles());
        assertEquals(partido.getSegundosRestantes(), abierto.getSegundosRestantes());
        assertEquals(partido.getBalon().getX(), abierto.getBalon().getX(), 0.0001);
        assertEquals("Camerún", abierto.getJugador1().getPais());
        assertTrue(abierto.getJugador2().esMaquina());
        assertEquals("Defensiva", abierto.getJugador2().getMaquina().getNombre());
        assertEquals(1000, abierto.getCancha().getAnchoPantalla());
        for (int i = 0; i < 100; i++) abierto.avanzar(new Accion(), new Accion());
    }

    @Test(expected = JuegoException.class)
    public void abrirArchivoQueNoExisteLanzaExcepcion() throws JuegoException {
        ArchivoPartida.abrir(new File(carpeta.getRoot(), "noexiste.dopo"));
    }

    @Test(expected = JuegoException.class)
    public void abrirArchivoQueNoEsUnaPartidaLanzaExcepcion() throws Exception {
        File falso = carpeta.newFile("falso.dopo");
        try (FileWriter escritor = new FileWriter(falso)) { escritor.write("esto no es una partida"); }
        ArchivoPartida.abrir(falso);
    }

    @Test public void elProgresoSeMantieneEntreEjecuciones() throws Exception {
        File archivo = new File(carpeta.getRoot(), "progreso.properties");
        ArchivoProgreso progreso = new ArchivoProgreso(archivo);
        Jugador ana = new Jugador("Ana", Personaje.buscar("Camerún"));
        ana.setProgreso(1500, 3, 2, 1, 4);
        progreso.guardarDe(ana);

        ArchivoProgreso otraVez = new ArchivoProgreso(archivo);
        Jugador nueva = new Jugador("Ana", Personaje.buscar("Nigeria"));
        otraVez.cargarEn(nueva);
        assertEquals(1500, nueva.getPuntos());
        assertEquals(3, nueva.getSpeed());
        assertEquals(2, nueva.getKick());
        assertEquals(4, nueva.getSurvival());
        assertTrue(otraVez.nombresGuardados().contains("Ana"));
    }

    @Test public void jugadorNuevoEmpiezaEnUno() throws Exception {
        ArchivoProgreso progreso = new ArchivoProgreso(new File(carpeta.getRoot(), "vacio.properties"));
        Jugador nuevo = new Jugador("Luis", Personaje.buscar("Camerún"));
        progreso.cargarEn(nuevo);
        assertEquals(1, nuevo.getSpeed());
        assertEquals(0, nuevo.getPuntos());
    }
}
