package dominio;

import org.junit.Test;
import static org.junit.Assert.*;

public class BalonTest {

    @Test public void caeYRebotaYQuedaEnElSuelo() {
        Balon balon = new Balon(400, 100);
        boolean reboto = false;
        double vyAnterior = 0;
        for (int i = 0; i < 400; i++) {
            balon.mover();
            assertTrue("El balón no puede hundirse en el suelo", balon.getY() <= Cancha.SUELO - balon.getRadio() + 0.01);
            if (balon.getVy() < 0 && vyAnterior > 0) reboto = true;
            vyAnterior = balon.getVy();
        }
        assertTrue(reboto);
        assertTrue(balon.enSuelo());
        assertEquals(0, balon.getVy(), 0.01);
    }

    @Test public void cadaReboteEsMasBajo() {
        Balon balon = new Balon(400, 50);
        double[] picos = new double[3];
        int n = 0;
        double vyAntes = 0;
        for (int i = 0; i < 600 && n < 3; i++) {
            balon.mover();
            if (vyAntes < 0 && balon.getVy() >= 0) picos[n++] = balon.getY();
            vyAntes = balon.getVy();
        }
        assertTrue(picos[1] > picos[0]);
        assertTrue(picos[2] > picos[1]);
    }

    @Test public void rodandoSeVaFrenando() {
        Balon balon = new Balon(400, Cancha.SUELO - 14);
        balon.setVelocidad(8, 0);
        for (int i = 0; i < 120; i++) balon.mover();
        assertTrue(balon.getVx() < 8 && balon.getVx() > 0);
        assertTrue(balon.getAngulo() > 0);
    }

    @Test public void rebotaEnLaParedLejanaPeroNoSale() {
        Balon balon = new Balon(700, 200);
        balon.setVelocidad(15, 0);
        for (int i = 0; i < 100; i++) {
            balon.mover();
            assertTrue(balon.getX() <= Cancha.ANCHO - balon.getRadio() + 0.01);
        }
    }

    @Test public void laRedDelArcoFrenaElBalon() {
        Balon balon = new Balon(60, Cancha.SUELO - 14);
        balon.setVelocidad(-12, 0);
        for (int i = 0; i < 10; i++) balon.mover();
        assertTrue(balon.getX() >= balon.getRadio() - 0.01);
        assertTrue(Math.abs(balon.getVx()) < 3);
    }

    @Test public void rebotaEnElTravesano() {
        Balon balon = new Balon(36, Cancha.TRAVESANO_Y - 40);
        balon.setVelocidad(0, 6);
        boolean subio = false;
        for (int i = 0; i < 40; i++) {
            balon.mover();
            assertTrue("No debe atravesar el travesaño", balon.getY() < Cancha.TRAVESANO_Y + 0.5);
            if (balon.getVy() < 0) subio = true;
        }
        assertTrue(subio);
    }

    @Test public void balonRapidoNoAtraviesaElTravesano() {
        Balon balon = new Balon(36, Cancha.TRAVESANO_Y - 60);
        balon.setVelocidad(0, 19);
        for (int i = 0; i < 6; i++) balon.mover();
        assertTrue(balon.getY() < Cancha.TRAVESANO_Y);
    }

    @Test public void pateadaSaleHaciaLaDireccionPedida() {
        Balon balon = new Balon(300, 300);
        balon.patear(-1, 13, 0.5, 0);
        assertTrue(balon.getVx() < 0);
        assertTrue(balon.getVy() < 0);
    }
}
