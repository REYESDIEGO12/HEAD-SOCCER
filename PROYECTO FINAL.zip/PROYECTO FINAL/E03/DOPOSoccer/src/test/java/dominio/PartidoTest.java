package dominio;

import org.junit.Test;
import static org.junit.Assert.*;

public class PartidoTest {

    private Jugador crear(String nombre, String pais) throws JuegoException {
        return new Jugador(nombre, Personaje.buscar(pais));
    }

    private Partido crearPartido(boolean porGoles, int objetivo) throws JuegoException {
        return new Partido(crear("Uno", "Corea del Sur"), crear("Dos", "Nigeria"), new Cancha(800, 450), porGoles, objetivo);
    }

    private void avanzarVacio(Partido partido, int ticks) {
        for (int i = 0; i < ticks; i++) partido.avanzar(new Accion(), new Accion());
    }

    @Test public void iniciaEnCeroACero() throws JuegoException {
        Partido partido = crearPartido(true, 3);
        assertEquals(0, partido.getJugador1().getGoles());
        assertEquals(0, partido.getJugador2().getGoles());
        assertEquals(0.0, partido.getJugador1().getBarraPoder(), 0.01);
        assertEquals(partido.getJugador1().getVidaMax(), partido.getJugador1().getVida());
    }

    @Test public void registraGolYCargaBarraDelRival() throws JuegoException {
        Partido partido = crearPartido(true, 3);
        partido.registrarGol(1);
        assertEquals(1, partido.getJugador1().getGoles());
        assertEquals(25.0, partido.getJugador2().getBarraPoder(), 0.01);
    }

    @Test public void ganaAlLlegarAGoles() throws JuegoException {
        Partido partido = crearPartido(true, 1);
        partido.registrarGol(1);
        assertTrue(partido.estaTerminado());
        assertEquals("Uno", partido.nombreGanador());
    }

    @Test public void despuesDeUnGolVuelvenAPosicionYBalonCaeDelCentro() throws JuegoException {
        Partido partido = crearPartido(true, 5);
        partido.registrarGol(1);
        avanzarVacio(partido, Partido.TICKS_CELEBRACION + 2);
        assertEquals(Cancha.ANCHO * 0.25, partido.getJugador1().getX(), 1);
        assertTrue(partido.getBalon().getY() < 200);
        assertEquals(400, partido.getBalon().getX(), 40);
    }

    @Test public void balonQueEntraAlArcoEsGol() throws JuegoException {
        Partido partido = crearPartido(true, 5);
        partido.getBalon().setPosicion(100, Cancha.SUELO - 14);
        partido.getBalon().setVelocidad(-12, 0);
        avanzarVacio(partido, 30);
        assertEquals(1, partido.getJugador2().getGoles());
    }

    @Test public void balonPorEncimaDelTravesanoNoEsGol() throws JuegoException {
        Partido partido = crearPartido(true, 5);
        partido.getBalon().setPosicion(100, Cancha.TRAVESANO_Y - 60);
        partido.getBalon().setVelocidad(-8, 0);
        avanzarVacio(partido, 20);
        assertEquals(0, partido.getJugador2().getGoles());
    }

    @Test public void partidoPorTiempoTerminaYGanaQuienTengaMasGoles() throws JuegoException {
        Partido partido = crearPartido(false, 1);
        partido.registrarGol(2);
        for (int i = 0; i < 20000 && !partido.mostrarResultado(); i++) partido.avanzar(new Accion(), new Accion());
        assertTrue(partido.estaTerminado());
        assertEquals("Dos", partido.nombreGanador());
    }

    @Test public void empateVaAMuerteSubitaYElPrimerGolGana() throws JuegoException {
        Partido partido = crearPartido(false, 1);
        for (int i = 0; i < 1 * 60 * 60 + 5; i++) partido.avanzar(new Accion(), new Accion());
        assertTrue(partido.isMuerteSubita());
        assertFalse(partido.estaTerminado());
        partido.registrarGol(1);
        assertTrue(partido.estaTerminado());
        assertEquals("Uno", partido.nombreGanador());
    }

    @Test public void puntosGanadorCienPerdedorVeinticinco() throws JuegoException {
        Partido partido = crearPartido(true, 1);
        partido.registrarGol(2);
        partido.otorgarPuntos();
        partido.otorgarPuntos();
        assertEquals(25, partido.getJugador1().getPuntos());
        assertEquals(100, partido.getJugador2().getPuntos());
    }

    @Test public void terminarManualmenteGanaQuienVa() throws JuegoException {
        Partido partido = crearPartido(false, 5);
        partido.registrarGol(1);
        partido.terminarPartido();
        assertTrue(partido.mostrarResultado());
        assertEquals("Uno", partido.nombreGanador());
    }

    @Test public void patadaQueTocaElBalonSoloLoImpulsa() throws JuegoException {
        Partido partido = crearPartido(true, 5);
        Jugador j1 = partido.getJugador1();
        Jugador j2 = partido.getJugador2();
        j1.ubicar(300);
        j2.ubicar(372);
        partido.getBalon().setPosicion(335, Cancha.SUELO - 20);
        partido.getBalon().setVelocidad(0, 0);
        Accion patear = new Accion();
        patear.setPatear(true);
        partido.avanzar(patear, new Accion());
        assertFalse(j1.patadaPendiente());
        avanzarVacio(partido, 20);
        assertEquals(j2.getVidaMax(), j2.getVida());
    }

    @Test public void patadaSinBalonDanaAlRivalAlAlcance() throws JuegoException {
        Partido partido = crearPartido(true, 5);
        Jugador j1 = partido.getJugador1();
        Jugador j2 = partido.getJugador2();
        j1.ubicar(300);
        j2.ubicar(360);
        partido.getBalon().setPosicion(600, 100);
        Accion patear = new Accion();
        patear.setPatear(true);
        partido.avanzar(patear, new Accion());
        avanzarVacio(partido, 20);
        assertEquals(j2.getVidaMax() - 10, j2.getVida());
    }

    @Test public void patadaLejosDelRivalNoHaceDano() throws JuegoException {
        Partido partido = crearPartido(true, 5);
        Jugador j2 = partido.getJugador2();
        partido.getJugador1().ubicar(200);
        j2.ubicar(600);
        partido.getBalon().setPosicion(400, 50);
        Accion patear = new Accion();
        patear.setPatear(true);
        partido.avanzar(patear, new Accion());
        avanzarVacio(partido, 20);
        assertEquals(j2.getVidaMax(), j2.getVida());
    }

    private Partido lanzarTiro(Jugador j1, Jugador j2, double xRival) throws JuegoException {
        Partido partido = new Partido(j1, j2, new Cancha(800, 450), true, 5);
        for (int i = 0; i < 4; i++) j1.recibirGol();
        j1.activarPoder();
        j1.ubicar(300);
        j2.ubicar(xRival);
        partido.getBalon().setPosicion(325, j1.getCabezaY());
        partido.getBalon().setVelocidad(0, 0);
        partido.avanzar(new Accion(), new Accion());
        return partido;
    }

    @Test public void alTocarElBalonConAuraSaleElTiroYDesapareceElAura() throws JuegoException {
        Jugador j1 = crear("Uno", "Camerún");
        Partido partido = lanzarTiro(j1, crear("Dos", "Nigeria"), 700);
        assertNotNull(partido.getBalon().getTiro());
        assertFalse(j1.isPoderActivo());
        assertTrue(partido.getBalon().getVx() > 10);
    }

    @Test public void rayoGolpeaAlRivalConDanoYElectrocucion() throws JuegoException {
        Jugador j1 = crear("Uno", "Camerún");
        j1.setProgreso(0, 1, 5, 1, 1);
        Jugador j2 = crear("Dos", "Nigeria");
        j2.setProgreso(0, 1, 1, 1, 3);
        Partido partido = lanzarTiro(j1, j2, 520);
        avanzarVacio(partido, 60);
        assertEquals(120 - 84, j2.getVida());
        assertEquals(Efecto.ELECTROCUTADO, j2.getEfecto());
        assertNull(partido.getBalon().getTiro());
    }

    @Test public void tiroQueEntraAlArcoSinTocarAlRivalCuentaGolSinDano() throws JuegoException {
        Jugador j1 = crear("Uno", "Camerún");
        Jugador j2 = crear("Dos", "Nigeria");
        Partido partido = lanzarTiro(j1, j2, 100);
        j2.ubicar(60);
        partido.getBalon().setPosicion(700, 340);
        partido.getBalon().iniciarTiro(j1.getPersonaje().getPoder(), j1, 1);
        avanzarVacio(partido, 30);
        assertEquals(1, j1.getGoles());
        assertEquals(j2.getVidaMax(), j2.getVida());
        assertEquals(Efecto.NINGUNO, j2.getEfecto());
    }

    @Test public void auraAzulEmpujaAlRivalHaciaSuPropioArco() throws JuegoException {
        Jugador j1 = crear("Uno", "Corea del Sur");
        Jugador j2 = crear("Dos", "Camerún");
        Partido partido = lanzarTiro(j1, j2, 520);
        double antes = j2.getX();
        avanzarVacio(partido, 40);
        assertEquals(Efecto.EMPUJE, j2.getEfecto());
        assertTrue(j2.getX() > antes + 20);
        assertEquals(j2.getVidaMax() - 40, j2.getVida());
    }

    @Test public void tornadoDejaAlRivalInconscienteEnElAire() throws JuegoException {
        Jugador j1 = crear("Uno", "Nigeria");
        Jugador j2 = crear("Dos", "Camerún");
        Partido partido = lanzarTiro(j1, j2, 480);
        for (int i = 0; i < 60 && j2.getEfecto() != Efecto.INCONSCIENTE; i++) partido.avanzar(new Accion(), new Accion());
        assertEquals(Efecto.INCONSCIENTE, j2.getEfecto());
        assertFalse(j2.tieneControl());
        assertEquals(j2.getVidaMax() - 40, j2.getVida());
    }

    @Test public void ilusionCreaSieteBalonesFalsosQueDesaparecen() throws JuegoException {
        Jugador j1 = crear("Uno", "Estados Unidos");
        Partido partido = lanzarTiro(j1, crear("Dos", "Nigeria"), 760);
        assertEquals(7, partido.getSenuelos().size());
        assertEquals(8, partido.getTodosLosBalones().size());
        for (Balon falso : partido.getSenuelos()) assertTrue(falso.isFalso());
        avanzarVacio(partido, 400);
        assertEquals(0, partido.getSenuelos().size());
    }

    @Test public void balonesFalsosNuncaCuentanGol() throws JuegoException {
        Jugador j1 = crear("Uno", "Estados Unidos");
        Partido partido = lanzarTiro(j1, crear("Dos", "Nigeria"), 400);
        for (Balon falso : partido.getSenuelos()) falso.setPosicion(30, 350);
        partido.getBalon().setPosicion(400, 100);
        partido.getBalon().setVelocidad(0, 0);
        partido.getBalon().terminarTiro();
        avanzarVacio(partido, 2);
        assertEquals(0, partido.getJugador2().getGoles());
    }
}
