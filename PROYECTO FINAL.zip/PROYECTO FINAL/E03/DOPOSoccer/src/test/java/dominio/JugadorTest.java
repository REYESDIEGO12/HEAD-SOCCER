package dominio;

import org.junit.Test;
import static org.junit.Assert.*;

public class JugadorTest {

    private Jugador crear(String pais) throws JuegoException {
        return new Jugador("Prueba", Personaje.buscar(pais));
    }

    @Test public void vidaSegunSurvival() throws JuegoException {
        Jugador jugador = crear("Camerún");
        assertEquals(100, jugador.getVidaMax());
        jugador.setProgreso(0, 1, 1, 1, 3);
        assertEquals(120, jugador.getVidaMax());
        jugador.setProgreso(0, 1, 1, 1, 10);
        assertEquals(190, jugador.getVidaMax());
    }

    @Test public void danoPatadaSegunKick() throws JuegoException {
        Jugador jugador = crear("Nigeria");
        assertEquals(10, jugador.calcularDanoPatada());
        jugador.setProgreso(0, 1, 5, 1, 1);
        assertEquals(14, jugador.calcularDanoPatada());
    }

    @Test public void ejemploDelEnunciadoCamerun() throws JuegoException {
        Jugador j1 = crear("Camerún");
        j1.setProgreso(0, 1, 5, 1, 1);
        Jugador j2 = crear("Nigeria");
        j2.setProgreso(0, 1, 1, 1, 3);
        assertEquals(84, j1.calcularDanoPoder(j1.getPersonaje().getPoder()));
        j2.recibirDano(84);
        assertEquals(36, j2.getVida());
    }

    @Test public void golAumentaBarraUnCuarto() throws JuegoException {
        Jugador jugador = crear("Corea del Sur");
        jugador.recibirGol();
        assertEquals(25.0, jugador.getBarraPoder(), 0.01);
    }

    @Test public void barraSeLlenaEnDiezSegundos() throws JuegoException {
        Jugador jugador = crear("Corea del Sur");
        for (int i = 0; i < 10 * 60; i++) jugador.actualizar(new Accion());
        assertEquals(100.0, jugador.getBarraPoder(), 0.01);
    }

    @Test public void poderNoSePuedeActivarSinBarra() throws JuegoException {
        Jugador jugador = crear("Estados Unidos");
        try {
            jugador.activarPoder();
            fail("Debía lanzar excepción");
        } catch (JuegoException e) {
            assertEquals("La barra de poder no está llena.", e.getMessage());
        }
    }

    @Test public void activarPoderVaciaLaBarraYNoSePuedeRepetir() throws JuegoException {
        Jugador jugador = crear("Corea del Sur");
        for (int i = 0; i < 4; i++) jugador.recibirGol();
        jugador.activarPoder();
        assertTrue(jugador.isPoderActivo());
        assertEquals(0.0, jugador.getBarraPoder(), 0.01);
        for (int i = 0; i < 4; i++) jugador.recibirGol();
        assertFalse(jugador.puedeActivarPoder());
    }

    @Test public void vidaEnCeroAturdeTresSegundosYLuegoSeRestaura() throws JuegoException {
        Jugador jugador = crear("Camerún");
        jugador.recibirDano(500);
        assertEquals(0, jugador.getVida());
        assertTrue(jugador.estaAturdido());
        for (int i = 0; i < Jugador.TICKS_ATURDIMIENTO; i++) jugador.actualizar(new Accion());
        assertFalse(jugador.estaAturdido());
        assertEquals(jugador.getVidaMax(), jugador.getVida());
    }

    @Test public void aturdidoNoPuedeSaltar() throws JuegoException {
        Jugador jugador = crear("Camerún");
        jugador.recibirDano(500);
        Accion saltar = new Accion();
        saltar.setSaltar(true);
        jugador.actualizar(saltar);
        assertTrue(jugador.enSuelo());
    }

    @Test public void nuevoEfectoReemplazaAlAnterior() throws JuegoException {
        Jugador jugador = crear("Camerún");
        jugador.recibirEfecto(Efecto.ELECTROCUTADO, 180);
        jugador.recibirEfecto(Efecto.CONFUNDIDO, 150);
        assertEquals(Efecto.CONFUNDIDO, jugador.getEfecto());
        assertEquals(150, jugador.getTicksEfecto());
    }

    @Test public void electrocutadoVaALaMitadYNoSalta() throws JuegoException {
        Jugador jugador = crear("Camerún");
        double normal = jugador.getVelocidadMovimiento();
        jugador.recibirEfecto(Efecto.ELECTROCUTADO, 180);
        assertEquals(normal / 2, jugador.getVelocidadMovimiento(), 0.001);
        Accion saltar = new Accion();
        saltar.setSaltar(true);
        jugador.actualizar(saltar);
        assertTrue(jugador.enSuelo());
    }

    @Test public void mejorasCuestanElDobleCadaVez() throws JuegoException {
        Jugador jugador = crear("Nigeria");
        jugador.setProgreso(10000, 1, 1, 1, 1);
        assertEquals(500, jugador.getCostoMejora("speed"));
        jugador.mejorarEstadistica("speed");
        assertEquals(1000, jugador.getCostoMejora("speed"));
        jugador.mejorarEstadistica("speed");
        assertEquals(2000, jugador.getCostoMejora("speed"));
        assertEquals(3, jugador.getSpeed());
        assertEquals(10000 - 500 - 1000, jugador.getPuntos());
    }

    @Test public void mejorarSinPuntosLanzaExcepcion() throws JuegoException {
        Jugador jugador = crear("Nigeria");
        try {
            jugador.mejorarEstadistica("kick");
            fail("Debía lanzar excepción");
        } catch (JuegoException e) {
            assertTrue(e.getMessage().contains("500"));
        }
        assertEquals(1, jugador.getKick());
    }

    @Test(expected = JuegoException.class)
    public void estadisticaInexistenteLanzaExcepcion() throws JuegoException {
        crear("Nigeria").mejorarEstadistica("magia");
    }

    @Test(expected = JuegoException.class)
    public void estadisticaNoPuedePasarDeDiez() throws JuegoException {
        Jugador jugador = crear("Nigeria");
        jugador.setProgreso(0, 10, 1, 1, 1);
        jugador.mejorarEstadistica("speed");
    }

    @Test(expected = JuegoException.class)
    public void personajeInexistenteLanzaExcepcion() throws JuegoException {
        Personaje.buscar("Narnia");
    }
}
