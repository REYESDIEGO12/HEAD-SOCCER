package dominio;

import org.junit.Test;
import static org.junit.Assert.*;

public class MaquinaTest {

    @Test public void seCreanLosCuatroPerfiles() throws JuegoException {
        for (String perfil : Maquina.perfiles()) {
            assertEquals(perfil, Maquina.crear(perfil).getNombre());
        }
    }

    @Test(expected = JuegoException.class)
    public void perfilInexistenteLanzaExcepcion() throws JuegoException {
        Maquina.crear("Genial");
    }

    @Test public void ofensivaVaHaciaElBalon() throws JuegoException {
        Jugador yo = new Jugador("Maq", Personaje.buscar("Nigeria"));
        Jugador rival = new Jugador("Hum", Personaje.buscar("Camerún"));
        Partido partido = new Partido(rival, yo, new Cancha(800, 450), true, 3);
        partido.getBalon().setPosicion(100, Cancha.SUELO - 14);
        Accion accion = new MaquinaOfensiva().decidir(partido, yo, rival);
        assertTrue(accion.isIzquierda());
    }

    @Test public void defensivaVuelveASuArcoSiElBalonEstaLejos() throws JuegoException {
        Jugador yo = new Jugador("Maq", Personaje.buscar("Nigeria"));
        Jugador rival = new Jugador("Hum", Personaje.buscar("Camerún"));
        Partido partido = new Partido(rival, yo, new Cancha(800, 450), true, 3);
        yo.ubicar(300);
        partido.getBalon().setPosicion(60, Cancha.SUELO - 14);
        Accion accion = new MaquinaDefensiva().decidir(partido, yo, rival);
        assertTrue(accion.isDerecha());
    }

    @Test public void torpeSiempreDevuelveUnaAccion() throws JuegoException {
        Jugador yo = new Jugador("Maq", Personaje.buscar("Nigeria"));
        Jugador rival = new Jugador("Hum", Personaje.buscar("Camerún"));
        Partido partido = new Partido(rival, yo, new Cancha(800, 450), true, 3);
        Maquina torpe = new MaquinaTorpe();
        for (int i = 0; i < 200; i++) assertNotNull(torpe.decidir(partido, yo, rival));
    }

    @Test public void partidoContraMaquinaAvanzaSinFallar() throws JuegoException {
        Jugador humano = new Jugador("Hum", Personaje.buscar("Camerún"));
        Jugador maquina = new Jugador("Maq", Personaje.buscar("Estados Unidos"));
        maquina.setMaquina(Maquina.crear("Experta"));
        Partido partido = new Partido(humano, maquina, new Cancha(800, 450), false, 1);
        for (int i = 0; i < 3000; i++) partido.avanzar(new Accion(), new Accion());
        assertFalse(Double.isNaN(partido.getBalon().getX()));
    }
}
