# DOPOSoccer – Versión 3

Fútbol 2D para dos jugadores en el mismo teclado (o jugador vs máquina). Java 17 + Swing, sin librerías externas.

## Cómo ejecutarlo
- Maven: `mvn compile exec:java -Dexec.mainClass=presentacion.ControladorJuego`  (o `mvn package` y `java -jar target/dopo-soccer-3.0.jar`)
- Sin Maven: `javac -encoding UTF-8 -d out $(find src/main/java -name "*.java")` y luego `java -cp out presentacion.ControladorJuego`
- Pruebas: `mvn test`

## Estructura (capas)
- `src/main/java/presentacion`: pantallas y dibujo (ControladorJuego, PanelMenu, PanelConfiguracion, PanelMejoras, PanelCancha, Dibujante, Estilo, BotonJuego)
- `src/main/java/dominio`: reglas del juego (Partido, Jugador, Balon, Cancha, Personaje, PoderEspecial y sus 4 subclases, Maquina y sus 4 perfiles, Efecto, Accion, Juego, JuegoException)
- `src/main/java/persistencia`: guardar/abrir partidas (.dopo), progreso de jugadores y log de errores (`registro_errores.log`)

## Controles
| | Jugador 1 | Jugador 2 |
|---|---|---|
| Mover | A / D | ← / → |
| Saltar | W | ↑ |
| Patear | F | L |
| Poder | G | K |
Pausa: P o Esc.

## Qué cambia en la versión 3
- Física del balón nueva: gravedad, rebotes que pierden energía, fricción al rodar, giro, red del arco, travesaños, choques con cabeza/cuerpo/pie y 3 subpasos por tick para que no atraviese nada.
- Tiros de poder completos (Aura Azul, Rayo, Tornado, Ilusión con 8 balones) con daño = DañoTiro × multiplicadorKick y su efecto.
- Daño de patada, aturdimiento de 3 s, muerte súbita y cronómetro.
- Máquinas Torpe, Ofensiva, Defensiva y Experta.
- Estadísticas con costo 500/1000/2000..., puntos 100/25, progreso guardado.
- Interfaz nueva: estadio, hinchada, HUD con vida/poder, auras y efectos visibles, partículas, cuenta regresiva.
- Resoluciones 800x450, 1000x560 y 1200x675 (la física es la misma en las tres).
